-- MySQL dump 10.13  Distrib 8.0.43, for Win64 (x86_64)
--
-- Host: localhost    Database: sistema_ventas
-- ------------------------------------------------------
-- Server version	8.0.43

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `alembic_version`
--

DROP TABLE IF EXISTS `alembic_version`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `alembic_version` (
  `version_num` varchar(32) NOT NULL,
  PRIMARY KEY (`version_num`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `alembic_version`
--

LOCK TABLES `alembic_version` WRITE;
/*!40000 ALTER TABLE `alembic_version` DISABLE KEYS */;
INSERT INTO `alembic_version` VALUES ('c2d3e4f5a6b7');
/*!40000 ALTER TABLE `alembic_version` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `branch`
--

DROP TABLE IF EXISTS `branch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `branch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_id` int NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_branch_company_id` (`company_id`),
  KEY `ix_branch_name` (`name`),
  CONSTRAINT `branch_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `branch`
--

LOCK TABLES `branch` WRITE;
/*!40000 ALTER TABLE `branch` DISABLE KEYS */;
INSERT INTO `branch` VALUES (1,2,'CASA MATRIZ','AVENIDA PRINCIPAL 123'),(2,1,'CASA MATRIZ','Jirón Huancayo 1005'),(3,1,'CASA DE LA NONA','Avenida Nicolas de Pierola 1002'),(4,3,'CASA MATRIZ','AVENIDA PRINCIPAL 321'),(5,4,'Casa Matriz',''),(6,1,'CASA DEL NONO','Avenida Nicolas de Pierola 1004'),(7,1,'CASA DE LA TÍA','Avenida Nicolas de Pierola 1003'),(8,1,'CASA DEL TÍO','Avenida Nicolas de Pierola 1006'),(9,1,'CASA MATRIZ 2','PUEYRREDON 863'),(10,5,'Casa Matriz',''),(16,1,'CASA MATRIZ 3','AVENIDA A225 RIMAC'),(17,11,'Sucursal A','Smoke branch'),(18,12,'Sucursal B','Smoke branch'),(19,13,'Sucursal A','Smoke branch'),(20,14,'Sucursal B','Smoke branch'),(21,15,'Sucursal A','Smoke branch'),(22,16,'Sucursal B','Smoke branch'),(23,17,'Sucursal A','Smoke branch'),(24,18,'Sucursal B','Smoke branch'),(25,19,'Sucursal A','Smoke branch'),(26,20,'Sucursal B','Smoke branch');
/*!40000 ALTER TABLE `branch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cashboxlog`
--

DROP TABLE IF EXISTS `cashboxlog`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cashboxlog` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timestamp` datetime DEFAULT NULL,
  `action` varchar(255) NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `quantity` decimal(10,4) DEFAULT NULL,
  `unit` varchar(255) NOT NULL,
  `cost` decimal(10,2) DEFAULT NULL,
  `notes` varchar(255) NOT NULL,
  `user_id` int DEFAULT NULL,
  `payment_method` varchar(255) DEFAULT NULL,
  `payment_method_id` int DEFAULT NULL,
  `sale_id` int DEFAULT NULL,
  `is_voided` tinyint(1) NOT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ix_cashboxlog_payment_method` (`payment_method`),
  KEY `ix_cashboxlog_action` (`action`),
  KEY `ix_cashboxlog_payment_method_id` (`payment_method_id`),
  KEY `ix_cashboxlog_timestamp` (`timestamp`),
  KEY `ix_cashboxlog_sale_id` (`sale_id`),
  KEY `ix_cashboxlog_is_voided` (`is_voided`),
  KEY `ix_cashboxlog_company_id` (`company_id`),
  KEY `ix_cashboxlog_branch_id` (`branch_id`),
  KEY `ix_cashboxlog_company_branch_timestamp` (`company_id`,`branch_id`,`timestamp`),
  CONSTRAINT `cashboxlog_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `cashboxlog_ibfk_2` FOREIGN KEY (`payment_method_id`) REFERENCES `paymentmethod` (`id`),
  CONSTRAINT `cashboxlog_ibfk_3` FOREIGN KEY (`sale_id`) REFERENCES `sale` (`id`),
  CONSTRAINT `cashboxlog_ibfk_4` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `fk_cashboxlog_company_id` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=349 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cashboxlog`
--

LOCK TABLES `cashboxlog` WRITE;
/*!40000 ALTER TABLE `cashboxlog` DISABLE KEYS */;
INSERT INTO `cashboxlog` VALUES (1,'2026-01-01 23:01:44','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,NULL,NULL,NULL,0,1,2),(2,'2026-01-03 20:51:48','Cobro de Cuota',12.80,1.0000,'Unidad',0.00,'Cuota 1 venta 15',NULL,NULL,NULL,NULL,0,1,2),(3,'2026-01-03 20:53:24','Cobro de Cuota',12.80,1.0000,'Unidad',0.00,'Cuota 2 venta 15',NULL,NULL,NULL,NULL,0,1,2),(4,'2026-01-03 22:08:30','Cobranza',12.80,1.0000,'Unidad',0.00,'Cobro Cuota 3 / Venta #15 - Cliente: Robert Oscorima',1,'Yape',NULL,NULL,0,1,2),(5,'2026-01-03 22:09:45','Cobranza',11.68,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #19 - Cliente: Hender Huamaní',1,'Plin',NULL,NULL,0,1,2),(6,'2026-01-03 22:15:46','Venta',2.70,1.0000,'Unidad',0.00,'Venta 20',1,'Efectivo',NULL,NULL,0,1,2),(7,'2026-01-03 22:17:14','Venta',35.70,1.0000,'Unidad',0.00,'Venta 22',1,'Yape',NULL,NULL,0,1,2),(8,'2026-01-03 22:20:40','Venta',35.70,1.0000,'Unidad',0.00,'Venta 24',1,'Pago Mixto',NULL,NULL,0,1,2),(9,'2026-01-03 22:25:28','Venta',55.70,1.0000,'Unidad',0.00,'Venta 26',1,'T. Débito',NULL,NULL,0,1,2),(10,'2026-01-04 00:03:35','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha  Día2 (2026-01-03 02:00 - 2026-01-03 03:00)',1,'Efectivo',NULL,NULL,0,1,2),(11,'2026-01-04 00:04:24','Venta',58.40,1.0000,'Unidad',0.00,'Venta 28',1,'Yape',NULL,NULL,0,1,2),(12,'2026-01-04 00:06:46','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha  Día2 (2026-01-03 03:00 - 2026-01-03 04:00)',1,'Efectivo',NULL,NULL,0,1,2),(13,'2026-01-04 00:08:11','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 1 Día (2026-01-03 04:00 - 2026-01-03 05:00)',1,'Efectivo',NULL,NULL,0,1,2),(14,'2026-01-04 00:09:57','Cobranza',11.68,1.0000,'Unidad',0.00,'Cobro Cuota 2 / Venta #19 - Cliente: Hender Huamaní',1,'Plin',NULL,NULL,0,1,2),(15,'2026-01-04 00:15:47','cierre',384.36,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-04',1,'Efectivo',NULL,NULL,0,1,2),(16,'2026-01-04 00:56:14','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(17,'2026-01-04 00:59:57','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-01-04 00:00 - 2026-01-04 01:00)',1,'Efectivo',NULL,NULL,0,1,2),(18,'2026-01-04 03:03:12','cierre',120.00,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-04',1,'Efectivo',NULL,NULL,0,1,2),(19,'2026-01-04 03:03:25','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(20,'2026-01-04 03:04:39','Venta',5.70,1.0000,'Unidad',0.00,'Venta 35',1,'Efectivo',NULL,NULL,0,1,2),(21,'2026-01-04 03:08:37','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha  Día2 (2026-01-04 00:00 - 2026-01-04 01:00)',1,'Efectivo',NULL,NULL,0,1,2),(22,'2026-01-04 03:09:59','Venta',52.70,1.0000,'Unidad',0.00,'Venta 37',1,'Plin',NULL,NULL,0,1,2),(23,'2026-01-04 03:12:48','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-01-04 01:00 - 2026-01-04 02:00)',1,'Efectivo',NULL,NULL,0,1,2),(24,'2026-01-04 03:13:41','Venta',58.40,1.0000,'Unidad',0.00,'Venta 39',1,'Pago Mixto',NULL,NULL,0,1,2),(25,'2026-01-04 03:15:54','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha  Día2 (2026-01-04 01:00 - 2026-01-04 02:00)',1,'Efectivo',NULL,NULL,0,1,2),(26,'2026-01-04 03:18:25','Inicial Credito',28.40,1.0000,'Unidad',0.00,'Adelanto Venta a Crédito #41 - Cliente Robert Oscorima',1,'Transferencia',NULL,NULL,0,1,2),(27,'2026-01-04 03:20:36','Cobranza',25.00,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #32 - Cliente: Robert Oscorima',1,'T. Credito',NULL,NULL,0,1,2),(28,'2026-01-04 03:59:05','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-01-04 02:00 - 2026-01-04 03:00)',1,'Efectivo',NULL,NULL,0,1,2),(29,'2026-01-04 04:05:39','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha  Día2 (2026-01-04 02:00 - 2026-01-04 03:00)',1,'Efectivo',NULL,NULL,0,1,2),(30,'2026-01-04 04:10:25','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha  Día2 (2026-01-04 03:00 - 2026-01-04 04:00)',1,'Efectivo',NULL,NULL,0,1,2),(31,'2026-01-04 05:00:14','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-01-04 03:00 - 2026-01-04 04:00)',1,'Efectivo',NULL,NULL,0,1,2),(32,'2026-01-04 05:01:53','Inicial Credito',28.40,1.0000,'Unidad',0.00,'Adelanto Venta a Crédito #48 - Cliente Hender Huamaní',1,'Efectivo',NULL,NULL,0,1,2),(33,'2026-01-04 05:07:45','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-01-04 04:00 - 2026-01-04 05:00)',1,'Efectivo',NULL,NULL,0,1,2),(34,'2026-01-04 05:09:05','Inicial Credito',28.40,1.0000,'Unidad',0.00,'Adelanto Venta a Crédito #50 - Cliente Hender Huamaní',1,'Efectivo',NULL,NULL,0,1,2),(35,'2026-01-04 07:49:42','Venta',2.70,1.0000,'Unidad',0.00,'Venta 51',1,'Plin',12,NULL,0,1,2),(36,'2026-01-04 07:50:42','Venta',5.70,1.0000,'Unidad',0.00,'Venta 52',1,'Yape',11,NULL,0,1,2),(37,'2026-01-04 07:51:07','Venta',5.70,1.0000,'Unidad',0.00,'Venta 53',1,'Yape',11,NULL,0,1,2),(38,'2026-01-04 07:51:29','Venta',8.40,1.0000,'Unidad',0.00,'Venta 54',1,'T. Crédito',NULL,NULL,0,1,2),(39,'2026-01-04 07:52:02','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha  Día2 (2026-01-04 04:00 - 2026-01-04 05:00)',1,'Efectivo',NULL,NULL,0,1,2),(40,'2026-01-04 07:53:43','Venta',58.40,1.0000,'Unidad',0.00,'Venta 56',1,'Pago Mixto',12,NULL,0,1,2),(41,'2026-01-04 07:56:55','Inicial Credito',28.40,1.0000,'Unidad',0.00,'Adelanto Venta a Crédito #57 - Cliente Mateo Oscorima',1,'Plin',12,NULL,0,1,2),(42,'2026-01-05 00:56:02','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-01-05 00:00 - 2026-01-05 01:00)',1,'Efectivo',NULL,NULL,0,1,2),(43,'2026-01-05 00:58:18','Venta',55.30,1.0000,'Unidad',0.00,'Venta 59',1,'Pago Mixto',12,NULL,0,1,2),(44,'2026-01-05 01:00:44','Venta',15.90,1.0000,'Unidad',0.00,'Venta 60',1,'Plin',12,NULL,0,1,2),(45,'2026-01-05 02:44:52','Venta',5.30,1.0000,'Unidad',0.00,'Venta 61',1,'Efectivo',8,NULL,0,1,2),(46,'2026-01-05 02:45:38','Venta',5.30,1.0000,'Unidad',0.00,'Venta 62',1,'Efectivo',8,NULL,0,1,2),(47,'2026-01-05 18:55:41','cierre',718.10,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-05',1,'Efectivo',NULL,NULL,0,1,2),(48,'2026-01-05 18:56:10','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(49,'2026-01-06 18:36:28','cierre',100.00,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-06',1,'Efectivo',NULL,NULL,0,1,2),(50,'2026-01-06 19:30:09','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(51,'2026-01-07 11:24:37','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 1 Día (2026-01-07 00:00 - 2026-01-07 01:00)',1,'Efectivo',NULL,NULL,0,1,2),(52,'2026-01-07 12:42:05','Venta',5.40,1.0000,'Unidad',0.00,'Venta 64',1,'Efectivo',8,NULL,0,1,2),(53,'2026-01-07 12:44:55','Venta',15.60,1.0000,'Unidad',0.00,'Venta 65',1,'Yape',11,NULL,0,1,2),(54,'2026-01-08 10:34:30','Venta',17.10,1.0000,'Unidad',0.00,'Venta 66',1,'Plin',12,NULL,0,1,2),(55,'2026-01-08 10:35:31','cierre',158.10,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-08',1,'Efectivo',NULL,NULL,0,1,2),(56,'2026-01-08 10:36:48','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(57,'2026-01-08 10:37:12','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 1 Día (2026-01-07 00:00 - 2026-01-07 01:00)',1,'Efectivo',NULL,NULL,0,1,2),(58,'2026-01-08 10:37:57','Venta',41.40,1.0000,'Unidad',0.00,'Venta 68',1,'Efectivo',8,NULL,0,1,2),(59,'2026-01-08 10:40:48','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 1 Día (2026-01-07 01:00 - 2026-01-07 02:00)',1,'Efectivo',NULL,NULL,0,1,2),(60,'2026-01-08 10:41:01','Venta',30.00,1.0000,'Unidad',0.00,'Venta 70',1,'Plin',12,NULL,0,1,2),(61,'2026-01-08 10:41:36','Venta',30.00,1.0000,'Unidad',0.00,'Venta 71',1,'Yape',11,NULL,0,1,2),(62,'2026-01-08 10:42:18','cierre',241.40,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-08',1,'Efectivo',NULL,NULL,0,1,2),(63,'2026-01-08 10:50:03','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(64,'2026-01-08 11:03:10','Venta',5.70,1.0000,'Unidad',0.00,'#72: Gatorade 1.5l (x1)',1,'Efectivo',8,NULL,0,1,2),(65,'2026-01-08 11:03:39','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-01-08 00:00 - 2026-01-08 01:00)',1,'Efectivo',NULL,NULL,0,1,2),(66,'2026-01-08 11:03:53','Venta',61.40,1.0000,'Unidad',0.00,'#74: Alquiler Cancha 2 Noche, Gatorade 1.5l (x2)',1,'Plin',12,NULL,0,1,2),(67,'2026-01-08 11:04:38','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 1 Día (2026-01-08 00:00 - 2026-01-08 01:00)',1,'Efectivo',NULL,NULL,0,1,2),(68,'2026-01-08 11:04:48','Venta',30.00,1.0000,'Unidad',0.00,'#76: Alquiler Cancha 1 Día',1,'Plin',12,NULL,0,1,2),(69,'2026-01-08 11:06:07','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 1 Día (2026-01-08 01:00 - 2026-01-08 02:00)',1,'Efectivo',NULL,NULL,0,1,2),(70,'2026-01-08 11:06:21','Venta',30.00,1.0000,'Unidad',0.00,'#78: Alquiler Cancha 1 Día',1,'Yape',11,NULL,0,1,2),(71,'2026-01-08 11:08:02','Cobranza',18.56,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #34 - Cliente: Robert Oscorima',1,'Yape',NULL,NULL,0,1,2),(72,'2026-01-08 11:08:40','Venta',5.70,1.0000,'Unidad',0.00,'#79: Gatorade 1.5l (x1)',1,'Transferencia',13,NULL,0,1,2),(73,'2026-01-08 11:10:32','Venta',5.40,1.0000,'Unidad',0.00,'#80: Coca Cola (x2)',1,'Transferencia',13,NULL,0,1,2),(74,'2026-01-08 11:11:32','cierre',316.76,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-08',1,'Efectivo',NULL,NULL,0,1,2),(75,'2026-01-08 11:12:23','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(76,'2026-01-09 16:12:50','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-01-09 00:00 - 2026-01-09 01:00)',1,'Efectivo',NULL,NULL,0,1,2),(77,'2026-01-11 20:23:54','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-01-10 06:00 - 2026-01-10 07:00)',1,'Efectivo',NULL,NULL,0,1,2),(78,'2026-01-11 23:41:05','Venta',2.70,1.0000,'Unidad',0.00,'#84: Coca Cola (x1)',1,'Yape',11,NULL,0,1,2),(79,'2026-01-11 23:41:23','cierre',142.70,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-11',1,'Efectivo',NULL,NULL,0,1,2),(80,'2026-01-11 23:41:58','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(81,'2026-01-11 23:47:57','Venta',55.70,1.0000,'Unidad',0.00,'#85: Alquiler Cancha 2 Noche, Gatorade 1.5l (x1)',1,'Efectivo',8,NULL,0,1,2),(82,'2026-01-11 23:48:26','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha  Día2 (2026-01-11 06:00 - 2026-01-11 07:00)',1,'Efectivo',NULL,NULL,0,1,2),(83,'2026-01-12 00:48:46','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-01-12 06:00 - 2026-01-12 07:00)',1,'Efectivo',NULL,NULL,0,1,2),(84,'2026-01-12 00:50:03','Inicial Credito',10.00,1.0000,'Unidad',0.00,'Inicial #89 (Alquiler Cancha 2 Noche, Coca Cola (x1), Gatorade 1.5l (x1)) - Cliente Robert Oscorima',1,'Efectivo',8,NULL,0,1,2),(85,'2026-01-12 01:41:58','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha  Día2 (2026-01-12 06:00 - 2026-01-12 07:00)',1,'Efectivo',NULL,NULL,0,1,2),(86,'2026-01-12 01:42:52','Venta',58.40,1.0000,'Unidad',0.00,'#91: Alquiler Cancha  Día2, Coca Cola (x1), Gatorade 1.5l (x1)',1,'Plin',12,NULL,0,1,2),(87,'2026-01-12 01:44:58','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha  Día2 (2026-01-12 07:00 - 2026-01-12 08:00)',1,'Efectivo',NULL,NULL,0,1,2),(88,'2026-01-12 01:45:58','Inicial Credito',10.00,1.0000,'Unidad',0.00,'Inicial #93 (Alquiler Cancha  Día2) - Cliente Mateo Oscorima',1,'Efectivo',8,NULL,0,1,2),(89,'2026-01-12 01:47:27','Cobranza',10.00,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #57 - Cliente: Mateo Oscorima',1,'Yape',NULL,NULL,0,1,2),(90,'2026-01-12 01:49:08','Cobranza',10.00,1.0000,'Unidad',0.00,'Cobro Cuota 2 / Venta #57 - Cliente: Mateo Oscorima',1,'Yape',NULL,NULL,0,1,2),(91,'2026-01-12 01:58:14','Cobranza',50.00,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #82 - Cliente: Robert Oscorima',1,'Plin',NULL,NULL,0,1,2),(92,'2026-01-12 11:26:18','Cobranza',27.85,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #87 - Cliente: Hender Huamaní',1,'T. Credito',NULL,NULL,0,1,2),(93,'2026-01-12 11:27:06','Cobranza',19.46,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #43 - Cliente: Hender Huamaní',1,'Plin',NULL,NULL,0,1,2),(94,'2026-01-12 11:38:05','Cobranza',10.00,1.0000,'Unidad',0.00,'Cobro Cuota 3 / Venta #57 - Cliente: Mateo Oscorima',1,'T. Credito',NULL,NULL,0,1,2),(95,'2026-01-12 11:45:02','Cobranza',19.47,1.0000,'Unidad',0.00,'Cobro Cuota 2 / Venta #43 - Cliente: Hender Huamaní',1,'Yape',NULL,NULL,0,1,2),(96,'2026-01-12 11:45:52','Cobranza',10.00,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #48 - Cliente: Hender Huamaní',1,'Yape',NULL,NULL,0,1,2),(97,'2026-01-12 11:46:14','cierre',470.88,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-12',1,'Efectivo',NULL,NULL,0,1,2),(98,'2026-01-12 11:46:34','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(99,'2026-01-12 11:48:16','Cobranza',11.68,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #17 - Cliente: Mateo Oscorima',1,'Efectivo',NULL,NULL,0,1,2),(100,'2026-01-12 11:49:19','Cobranza',10.00,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #31 - Cliente: Robert Oscorima',1,'Transferencia',NULL,NULL,0,1,2),(101,'2026-01-12 11:49:54','Cobranza',10.00,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #41 - Cliente: Robert Oscorima',1,'Yape',NULL,NULL,0,1,2),(102,'2026-01-12 11:50:19','Cobranza',24.20,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #89 - Cliente: Robert Oscorima',1,'Plin',NULL,NULL,0,1,2),(103,'2026-01-12 11:50:39','Cobranza',10.00,1.0000,'Unidad',0.00,'Cobro Cuota 2 / Venta #31 - Cliente: Robert Oscorima',1,'T. Debito',NULL,NULL,0,1,2),(104,'2026-01-12 11:51:08','Cobranza',25.00,1.0000,'Unidad',0.00,'Cobro Cuota 2 / Venta #32 - Cliente: Robert Oscorima',1,'T. Credito',NULL,NULL,0,1,2),(105,'2026-01-12 11:52:19','Cobranza',18.57,1.0000,'Unidad',0.00,'Cobro Cuota 2 / Venta #34 - Cliente: Robert Oscorima',1,'Pago Mixto',NULL,NULL,0,1,2),(106,'2026-01-12 12:01:46','cierre',209.45,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-12',1,'Efectivo',NULL,NULL,0,1,2),(107,'2026-01-12 12:03:55','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(108,'2026-01-12 12:04:38','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-01-12 08:00 - 2026-01-12 09:00)',1,'Efectivo',NULL,NULL,0,1,2),(109,'2026-01-12 14:36:49','cierre',120.00,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-12',1,'Efectivo',NULL,NULL,0,1,2),(110,'2026-01-12 14:36:58','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(111,'2026-01-12 14:39:55','Venta',5.70,1.0000,'Unidad',0.00,'#95: Gatorade 1.5l (x1)',1,'Yape',11,NULL,0,1,2),(112,'2026-01-12 18:27:22','gasto_caja_chica',50.00,10.0000,'Unidad',5.00,'Gasto para compras de Mercaderia',1,'Efectivo',NULL,NULL,0,1,2),(113,'2026-01-12 19:03:08','gasto_caja_chica',24.00,12.0000,'Unidad',2.00,'Compra de materiales',1,'Efectivo',NULL,NULL,0,1,2),(114,'2026-01-13 01:53:12','Venta',2.70,1.0000,'Unidad',0.00,'#96: Coca Cola (x1)',1,'Efectivo',8,NULL,0,1,2),(115,'2026-01-13 01:53:27','Venta',5.70,1.0000,'Unidad',0.00,'#97: Gatorade 1.5l (x1)',1,'Efectivo',8,NULL,0,1,2),(116,'2026-01-13 02:12:44','gasto_caja_chica',10.00,2.0000,'Unidad',5.00,'Compra de Papel Suave',1,'Efectivo',NULL,NULL,0,1,2),(117,'2026-01-13 02:19:54','cierre',198.10,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-13',1,'Efectivo',NULL,NULL,0,1,2),(118,'2026-01-16 16:00:38','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(119,'2026-01-16 16:01:04','Venta',70.00,1.0000,'Unidad',0.00,'#98: Alquiler Cancha 2 Noche',1,'Efectivo',8,NULL,0,1,2),(120,'2026-01-16 16:01:33','Venta',55.70,1.0000,'Unidad',0.00,'#99: Alquiler Cancha 2 Noche, Gatorade 1.5l (x1)',1,'Yape',11,NULL,0,1,2),(121,'2026-01-18 21:53:18','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-01-18 06:00 - 2026-01-18 07:00)',1,'Efectivo',NULL,NULL,0,1,2),(122,'2026-01-18 21:54:16','Venta',55.70,1.0000,'Unidad',0.00,'#101: Alquiler Cancha 2 Noche, Gatorade 1.5l (x1)',1,'Efectivo',8,NULL,0,1,2),(123,'2026-01-18 21:54:41','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 1 Día (2026-01-18 06:00 - 2026-01-18 07:00)',1,'Efectivo',NULL,NULL,0,1,2),(124,'2026-01-18 21:54:51','Venta',30.00,1.0000,'Unidad',0.00,'#103: Alquiler Cancha 1 Día',1,'Yape',11,NULL,0,1,2),(125,'2026-01-18 21:55:10','Venta',5.70,1.0000,'Unidad',0.00,'#104: Gatorade 1.5l (x1)',1,'Plin',12,NULL,0,1,2),(126,'2026-01-18 22:09:24','cierre',357.10,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-18',1,'Efectivo',NULL,NULL,0,1,2),(127,'2026-01-19 02:24:42','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(128,'2026-01-19 10:44:08','gasto_caja_chica',15.00,3.0000,'Unidad',5.00,'Compra de Materiales',1,'Efectivo',NULL,NULL,0,1,2),(129,'2026-01-19 10:48:05','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 1 Día (2026-01-19 06:00 - 2026-01-19 07:00)',1,'Efectivo',NULL,NULL,0,1,2),(130,'2026-01-19 10:48:28','Venta',35.70,1.0000,'Unidad',0.00,'#106: Alquiler Cancha 1 Día, Gatorade 1.5l (x1)',1,'Efectivo',8,NULL,0,1,2),(131,'2026-01-19 10:48:44','Venta',2.70,1.0000,'Unidad',0.00,'#107: Coca Cola (x1)',1,'Yape',11,NULL,0,1,2),(132,'2026-01-19 10:48:54','Venta',2.70,1.0000,'Unidad',0.00,'#108: Coca Cola (x1)',1,'Plin',12,NULL,0,1,2),(133,'2026-01-19 10:49:18','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha  Día2 (2026-01-19 06:00 - 2026-01-19 07:00)',1,'Efectivo',NULL,NULL,0,1,2),(134,'2026-01-19 10:49:31','Venta',50.00,1.0000,'Unidad',0.00,'#110: Alquiler Cancha  Día2',1,'T. Débito',NULL,NULL,0,1,2),(135,'2026-01-19 11:01:42','gasto_caja_chica',60.00,3.0000,'Unidad',20.00,'Compra de materiales varios',1,'Efectivo',NULL,NULL,0,1,2),(136,'2026-01-19 11:56:40','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-01-19 07:00 - 2026-01-19 08:00)',1,'Efectivo',NULL,NULL,0,1,2),(137,'2026-01-19 11:58:12','Venta',55.70,1.0000,'Unidad',0.00,'#112: Alquiler Cancha 2 Noche, Gatorade 1.5l (x1)',1,'Pago Mixto',11,NULL,0,1,2),(138,'2026-01-19 12:02:29','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha  Día2 (2026-01-19 07:00 - 2026-01-19 08:00)',1,'Efectivo',NULL,NULL,0,1,2),(139,'2026-01-19 12:02:59','Venta',52.70,1.0000,'Unidad',0.00,'#114: Alquiler Cancha  Día2, Coca Cola (x1)',1,'Pago Mixto',12,NULL,0,1,2),(140,'2026-01-19 12:20:16','Cobranza',10.00,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #50 - Cliente: Hender Huamaní',1,'Pago Mixto',NULL,NULL,0,1,2),(141,'2026-01-20 13:23:20','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha  Día2 (2026-01-20 06:00 - 2026-01-20 07:00)',1,'Efectivo',NULL,115,0,1,2),(142,'2026-01-21 02:21:32','Venta',2.70,1.0000,'Unidad',0.00,'#116: Coca Cola (x1)',1,'Plin',12,116,0,1,2),(143,'2026-01-21 06:45:50','Venta',5.70,1.0000,'Unidad',0.00,'#117: Gatorade 1.5l (x1)',1,'T. Crédito',10,117,0,1,2),(144,'2026-01-21 07:22:19','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 1 Día (2026-01-21 06:00 - 2026-01-21 07:00)',1,'Efectivo',NULL,118,0,1,2),(145,'2026-01-21 07:23:13','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha  Día2 (2026-01-21 06:00 - 2026-01-21 07:00)',1,'Yape',NULL,119,0,1,2),(146,'2026-01-21 07:24:01','Venta',30.00,1.0000,'Unidad',0.00,'#120: Alquiler Cancha 1 Día',1,'T. Débito',9,120,0,1,2),(147,'2026-01-21 07:24:23','Venta',50.00,1.0000,'Unidad',0.00,'#121: Alquiler Cancha  Día2',1,'Plin',12,121,0,1,2),(148,'2026-01-21 07:24:49','Venta',52.70,1.0000,'Unidad',0.00,'#122: Alquiler Cancha  Día2, Coca Cola (x1)',1,'T. Crédito',10,122,0,1,2),(149,'2026-01-21 07:28:30','cierre',515.60,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-21',1,'Efectivo',NULL,NULL,0,1,2),(150,'2026-01-21 07:28:46','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(151,'2026-01-21 07:30:44','Inicial Credito',20.00,1.0000,'Unidad',0.00,'Inicial #123 (Alquiler Cancha 2 Noche) - Cliente Robert Oscorima',1,'Efectivo',8,123,0,1,2),(152,'2026-01-21 07:38:46','cierre',120.00,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-21',1,'Efectivo',NULL,NULL,0,1,2),(153,'2026-01-22 18:15:50','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(154,'2026-01-22 18:20:27','Venta',5.70,1.0000,'Unidad',0.00,'#124: Gatorade 1.5l (x1)',1,'Yape',11,124,0,1,2),(155,'2026-01-23 20:47:10','Venta',2.90,1.0000,'Unidad',0.00,'#125: Coca Cola (x1)',1,'Efectivo',8,125,0,1,2),(156,'2026-01-23 20:57:13','Venta',2.70,1.0000,'Unidad',0.00,'#126: Coca Cola (x1)',1,'Efectivo',8,126,0,1,2),(157,'2026-01-26 11:11:46','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-01-26 06:00 - 2026-01-26 07:00)',1,'Efectivo',NULL,127,0,1,2),(158,'2026-01-26 12:22:55','Venta',63.60,1.0000,'Unidad',0.00,'#128: Alquiler Cancha 2 Noche, Coca Cola (x1), Gatorade 1.5l (x1), Agua mineral 1.5L (x1)',1,'Plin',12,128,0,1,2),(159,'2026-01-27 04:18:04','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 1 Día (2026-01-27 06:00 - 2026-01-27 07:00)',1,'Plin',NULL,129,0,1,2),(160,'2026-01-27 04:19:13','Venta',52.40,1.0000,'Unidad',0.00,'#130: Alquiler Cancha 1 Día, Gatorade 1.5l (x1), Coca Cola (x1), Agua mineral 1.5L (x1), Pasta Dental Kolynos (x1), Alcohol Medicinal (x1)',1,'Yape',11,130,0,1,2),(161,'2026-01-27 16:42:26','cierre',267.30,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-27',1,'Efectivo',NULL,NULL,0,1,2),(162,'2026-01-27 20:05:57','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(163,'2026-01-27 20:06:58','Venta',32.70,1.0000,'Unidad',0.00,'#131: Alquiler Cancha 1 Día, Coca Cola (x1)',1,'Efectivo',8,131,0,1,2),(164,'2026-01-31 15:21:13','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,3),(165,'2026-01-31 15:55:10','cierre',132.70,1.0000,'Unidad',0.00,'Cierre de caja 2026-01-31',1,'Efectivo',NULL,NULL,0,1,2),(166,'2026-02-02 02:30:59','Venta',4.50,1.0000,'Unidad',0.00,'#132: COCA COLA 5ML (x1)',1,'Efectivo',23,132,0,1,3),(167,'2026-02-02 02:35:19','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Campo 1 Dia (2026-02-02 06:00 - 2026-02-02 07:00)',1,'Efectivo',NULL,133,0,1,3),(168,'2026-02-02 02:36:09','Venta',34.50,1.0000,'Unidad',0.00,'#134: Alquiler Campo 1 Dia, COCA COLA 5ML (x1)',1,'Yape',28,134,0,1,3),(169,'2026-02-02 02:38:26','gasto_caja_chica',30.00,3.0000,'Unidad',10.00,'Comprademateriales',1,'Efectivo',NULL,NULL,0,1,3),(170,'2026-02-02 02:39:43','cierre',129.00,1.0000,'Unidad',0.00,'Cierre de caja 2026-02-02',1,'Efectivo',NULL,NULL,0,1,3),(171,'2026-02-02 02:45:36','Cobranza',10.00,1.0000,'Unidad',0.00,'Cobro Cuota 2 / Venta #48 - Cliente: Hender Huamaní',1,'Efectivo',NULL,48,0,1,2),(172,'2026-02-02 02:46:01','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(173,'2026-02-02 03:22:02','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 1 Día (2026-02-02 06:00 - 2026-02-02 07:00)',1,'Plin',NULL,135,0,1,2),(174,'2026-02-02 03:24:17','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,3),(175,'2026-02-02 03:50:56','cierre',100.00,1.0000,'Unidad',0.00,'Cierre de caja 2026-02-02',1,'Efectivo',NULL,NULL,0,1,3),(176,'2026-02-02 03:51:12','cierre',120.00,1.0000,'Unidad',0.00,'Cierre de caja 2026-02-02',1,'Efectivo',NULL,NULL,0,1,2),(177,'2026-02-02 15:57:53','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',11,'Efectivo',NULL,NULL,0,3,4),(178,'2026-02-02 17:13:53','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',9,'Efectivo',NULL,NULL,0,2,1),(179,'2026-02-02 19:05:32','Venta',100.00,1.0000,'Unidad',0.00,'#136: Zapatillas Deportivas Runner (39 Negro) (x1), Zapatillas Deportivas Runner (40 Negro) (x1)',11,'Efectivo',31,136,0,3,4),(180,'2026-02-02 19:18:15','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(181,'2026-02-03 04:47:07','Venta',400.00,1.0000,'Unidad',0.00,'#137: Zapatillas Deportivas Futbol (39 AZUL) (x1), Zapatillas Deportivas Futbol (40 AZUL) (x1)',11,'Yape',36,137,0,3,4),(182,'2026-02-03 04:59:16','Venta',400.00,1.0000,'Unidad',0.00,'#138: Zapatillas Deportivas Futbol (40 AZUL) (x1), Zapatillas Deportivas Futbol (39 AZUL) (x1)',11,'Yape',36,138,0,3,4),(183,'2026-02-03 05:12:13','Venta',200.00,1.0000,'Unidad',0.00,'#139: Zapatillas Deportivas Futbol (40 AZUL) (x1)',11,'Plin',37,139,0,3,4),(184,'2026-02-03 12:15:08','Venta',620.90,1.0000,'Unidad',0.00,'#140: Coca Cola 500ml (x1), Agua mineral 1.5L (x1), Alcohol Medicinal (x1), Gatorade 1.5l (x1), Paracetamol 500mg (x1), Zapatillas Runner (39 Naranja) (x1), Zapatillas de Futbol (39 Azul) (x1), Zapatillas de Futbol (40 Verde) (x1), Zapatillas Runner ',1,'T. Débito',9,140,0,1,2),(185,'2026-02-03 18:16:59','Venta',35000.00,1.0000,'Unidad',0.00,'#141: Pañuelitos (x5) | ANULADA: Venta equivocada por el monto ingresado',1,'Efectivo',8,141,1,1,2),(186,'2026-02-04 20:01:01','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-02-04 06:00 - 2026-02-04 07:00)',1,'Efectivo',NULL,142,0,1,2),(187,'2026-02-05 13:12:21','Venta',2.70,1.0000,'Unidad',0.00,'#143: Coca Cola 500ml (x1)',1,'Efectivo',8,143,0,1,2),(188,'2026-02-05 13:22:29','Venta',2.70,1.0000,'Unidad',0.00,'#144: Coca Cola 500ml (x1)',1,'Yape',11,144,0,1,2),(189,'2026-02-05 18:53:57','Venta',2.70,1.0000,'Unidad',0.00,'#145: Coca Cola 500ml (x1)',1,'Plin',12,145,0,1,2),(190,'2026-02-05 19:00:44','Venta',2.70,1.0000,'Unidad',0.00,'#146: Coca Cola 500ml (x1)',1,'Plin',12,146,0,1,2),(191,'2026-02-05 19:01:30','Venta',20.50,1.0000,'Unidad',0.00,'#147: Agua mineral 1.5L (x1), Alcohol Medicinal (x1), Gatorade 1.5l (x1), Gatorade 1.25ml (x1)',1,'Yape',11,147,0,1,2),(192,'2026-02-05 19:03:49','Venta',650.00,1.0000,'Unidad',0.00,'#148: Alquiler Cancha 2 Noche, Zapatillas de Futbol (40 Verde) (x1), Zapatillas de Futbol (39 Azul) (x1), Zapatillas Runner (40 Marron) (x1), Zapatillas Runner (39 Naranja) (x1)',1,'Efectivo',8,148,0,1,2),(193,'2026-02-05 19:11:02','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-02-05 06:00 - 2026-02-05 07:00)',1,'Efectivo',NULL,149,0,1,2),(194,'2026-02-05 19:21:57','Venta',70.50,1.0000,'Unidad',0.00,'#150: Alquiler Cancha 2 Noche, Alcohol Medicinal (x1), Agua mineral 1.5L (x1), Gatorade 1.5l (x1), Gatorade 1.25ml (x1)',1,'Yape',11,150,0,1,2),(195,'2026-02-05 19:33:28','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',8,'Efectivo',NULL,NULL,0,1,3),(196,'2026-02-05 19:40:03','cierre',100.00,1.0000,'Unidad',0.00,'Cierre de caja 2026-02-05',8,'Efectivo',NULL,NULL,0,1,3),(197,'2026-02-05 19:40:12','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',8,'Efectivo',NULL,NULL,0,1,2),(198,'2026-02-05 19:41:12','Venta',20.00,1.0000,'Unidad',0.00,'#151: Gatorade 1.5l (x4)',8,'T. Débito',9,151,0,1,2),(199,'2026-02-05 19:41:36','cierre',120.00,1.0000,'Unidad',0.00,'Cierre de caja 2026-02-05',8,'Efectivo',NULL,NULL,0,1,2),(200,'2026-02-06 15:27:51','Cobranza',19.46,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #45 - Cliente: Mateo Oscorima',1,'Plin',NULL,45,0,1,2),(201,'2026-02-06 19:21:51','Venta',150.00,1.0000,'Unidad',0.00,'#152: Zapatillas Runner (39 Naranja) (x1)',1,'Transferencia',13,152,0,1,2),(202,'2026-02-06 19:23:55','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-02-06 06:00 - 2026-02-06 07:00)',1,'Plin',NULL,153,0,1,2),(203,'2026-02-06 19:25:13','Venta',60.00,1.0000,'Unidad',0.00,'#154: Alquiler Cancha 2 Noche, Gatorade 1.25ml (x2)',1,'Yape',11,154,0,1,2),(204,'2026-02-06 19:29:25','cierre',1762.16,1.0000,'Unidad',0.00,'Cierre de caja 2026-02-06',1,'Efectivo',NULL,NULL,0,1,2),(205,'2026-02-06 19:35:52','apertura',100.00,1.0000,'Unidad',0.00,'Apertura de caja',1,'Efectivo',NULL,NULL,0,1,2),(206,'2026-02-06 20:09:03','Venta',25.00,1.0000,'Unidad',0.00,'#155: Gatorade 1.5l (x5)',1,'Yape',11,155,0,1,2),(207,'2026-02-06 20:12:29','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 1 Día (2026-02-06 06:00 - 2026-02-06 07:00)',1,'Yape',NULL,156,0,1,2),(208,'2026-02-06 20:13:35','Venta',30.00,1.0000,'Unidad',0.00,'#157: Alquiler Cancha 1 Día',1,'Yape',11,157,0,1,2),(209,'2026-02-06 20:15:11','Venta',30.00,1.0000,'Unidad',0.00,'#158: Alquiler Cancha 1 Día',1,'Yape',11,158,0,1,2),(210,'2026-02-06 20:33:00','Venta',25.00,1.0000,'Unidad',0.00,'#159: Gatorade 1.5l (x5)',1,'Transferencia',13,159,0,1,2),(211,'2026-02-07 00:36:33','Venta',150.00,1.0000,'Unidad',0.00,'#160: Zapatillas Runner (39 Naranja) (x1)',1,'Transferencia',13,160,0,1,2),(262,'2026-02-07 15:10:13','Venta',455.30,1.0000,'Unidad',0.00,'#211: Alcohol Medicinal (x1), Zapatillas Runner (39 Naranja) (x3)',1,'Transferencia',13,211,0,1,2),(263,'2026-02-07 15:16:00','gasto_caja_chica',50.00,1.0000,'Unidad',50.00,'Compra de Materiales de Limpieza',1,'Efectivo',NULL,NULL,0,1,2),(264,'2026-02-07 15:18:15','Cobranza',20.00,1.0000,'Unidad',0.00,'Cobro Cuota 1 / Venta #93 - Cliente: Mateo Oscorima',1,'Transferencia',NULL,93,0,1,2),(265,'2026-02-07 15:41:23','Adelanto',20.00,1.0000,'Unidad',0.00,'Adelanto Cancha 2 Noche (2026-02-07 09:00 - 2026-02-07 10:00)',1,'Transferencia',NULL,212,0,1,2),(266,'2026-02-07 15:42:00','Venta',50.00,1.0000,'Unidad',0.00,'#213: Alquiler Cancha 2 Noche',1,'Yape',11,213,0,1,2),(267,'2026-02-07 17:14:36','Venta',4.00,1.0000,'Unidad',0.00,'#214: Leche evaporada (x1)',1,'T. Débito',9,214,0,1,2),(268,'2026-01-02 01:10:25','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 1',1,'Efectivo',NULL,215,0,1,2),(269,'2026-01-02 01:30:15','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 2',1,'Efectivo',NULL,216,0,1,2),(270,'2026-01-02 13:51:15','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 3',1,'Efectivo',NULL,217,0,1,2),(271,'2026-01-02 15:47:22','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 4',1,'Efectivo',NULL,218,0,1,2),(272,'2026-01-02 16:41:41','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 5',1,'Efectivo',NULL,219,0,1,2),(273,'2026-01-02 16:53:49','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 6',1,'Efectivo',NULL,220,0,1,2),(274,'2026-01-03 19:37:56','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 7',1,'Efectivo',NULL,221,0,1,2),(275,'2026-01-03 20:44:50','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 8',1,'Efectivo',NULL,222,0,1,2),(276,'2026-01-03 20:47:52','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 9',1,'Efectivo',NULL,223,0,1,2),(277,'2026-01-03 22:16:27','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 10',1,'Efectivo',NULL,224,0,1,2),(278,'2026-01-03 22:19:25','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 11',1,'Efectivo',NULL,225,0,1,2),(279,'2026-01-03 22:25:01','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 12',1,'Efectivo',NULL,226,0,1,2),(280,'2026-01-04 00:03:35','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 13',1,'Efectivo',NULL,227,0,1,2),(281,'2026-01-04 00:06:46','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 14',1,'Efectivo',NULL,228,0,1,2),(282,'2026-01-04 00:08:11','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 15',1,'Efectivo',NULL,229,0,1,2),(283,'2026-01-04 00:59:57','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 16',1,'Efectivo',NULL,230,0,1,2),(284,'2026-01-04 03:08:37','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 17',1,'Efectivo',NULL,231,0,1,2),(285,'2026-01-04 03:12:48','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 18',1,'Efectivo',NULL,232,0,1,2),(286,'2026-01-04 03:15:54','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 19',1,'Efectivo',NULL,233,0,1,2),(287,'2026-01-04 03:59:05','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 20',1,'Efectivo',NULL,234,0,1,2),(288,'2026-01-04 04:05:39','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 21',1,'Efectivo',NULL,235,0,1,2),(289,'2026-01-04 04:10:25','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 22',1,'Efectivo',NULL,236,0,1,2),(290,'2026-01-04 05:00:14','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 23',1,'Efectivo',NULL,237,0,1,2),(291,'2026-01-04 05:07:45','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 24',1,'Efectivo',NULL,238,0,1,2),(292,'2026-01-04 07:52:02','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 25',1,'Efectivo',NULL,239,0,1,2),(293,'2026-01-05 00:56:02','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 26',1,'Efectivo',NULL,240,0,1,2),(294,'2026-01-07 11:24:37','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 27',1,'Efectivo',NULL,241,0,1,2),(295,'2026-01-08 10:37:12','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 28',1,'Efectivo',NULL,242,0,1,2),(296,'2026-01-08 10:40:48','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 29',1,'Efectivo',NULL,243,0,1,2),(297,'2026-01-08 11:03:39','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 30',1,'Efectivo',NULL,244,0,1,2),(298,'2026-01-08 11:04:38','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 31',1,'Efectivo',NULL,245,0,1,2),(299,'2026-01-08 11:06:07','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 32',1,'Efectivo',NULL,246,0,1,2),(300,'2026-01-09 16:12:50','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 33',1,'Efectivo',NULL,247,0,1,2),(301,'2026-01-11 20:23:46','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 34',1,'Efectivo',NULL,248,0,1,2),(302,'2026-01-11 23:48:26','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 35',1,'Efectivo',NULL,249,0,1,2),(303,'2026-01-12 00:48:46','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 36',1,'Efectivo',NULL,250,0,1,2),(304,'2026-01-12 01:41:58','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 37',1,'Efectivo',NULL,251,0,1,2),(305,'2026-01-12 01:44:58','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 38',1,'Efectivo',NULL,252,0,1,2),(306,'2026-01-12 11:59:52','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 39',1,'Efectivo',NULL,253,0,1,2),(307,'2026-01-12 12:04:38','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 40',1,'Efectivo',NULL,254,0,1,2),(308,'2026-01-18 21:53:18','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 41',1,'Efectivo',NULL,255,0,1,2),(309,'2026-01-18 21:54:41','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 42',1,'Efectivo',NULL,256,0,1,2),(310,'2026-01-19 10:48:05','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 43',1,'Efectivo',NULL,257,0,1,2),(311,'2026-01-19 10:49:18','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 44',1,'Efectivo',NULL,258,0,1,2),(312,'2026-01-19 11:56:40','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 45',1,'Efectivo',NULL,259,0,1,2),(313,'2026-01-19 12:02:29','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 46',1,'Efectivo',NULL,260,0,1,2),(314,'2026-01-20 13:23:20','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 47',1,'Efectivo',NULL,261,0,1,2),(315,'2026-01-21 07:22:19','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 48',1,'Efectivo',NULL,262,0,1,2),(316,'2026-01-21 07:23:13','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 49',1,'Efectivo',NULL,263,0,1,2),(317,'2026-01-21 07:29:36','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 50',1,'Efectivo',NULL,264,0,1,2),(318,'2026-01-26 11:11:46','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 51',1,'Efectivo',NULL,265,0,1,2),(319,'2026-01-27 04:18:04','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 52',1,'Efectivo',NULL,266,0,1,2),(320,'2026-01-27 20:05:44','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 53',1,'Efectivo',NULL,267,0,1,2),(321,'2026-02-02 02:35:19','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 54',1,'Efectivo',NULL,268,0,1,3),(322,'2026-02-02 03:22:02','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 55',1,'Efectivo',NULL,269,0,1,2),(323,'2026-02-02 03:23:19','Adelanto',20.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 56',1,'Efectivo',NULL,270,0,1,3),(324,'2026-02-04 20:01:01','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 57',1,'Efectivo',NULL,271,0,1,2),(325,'2026-02-05 19:11:02','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 58',1,'Efectivo',NULL,272,0,1,2),(326,'2026-02-06 19:23:55','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 59',1,'Efectivo',NULL,273,0,1,2),(327,'2026-02-06 20:12:29','Reserva',50.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 60',1,'Efectivo',NULL,274,0,1,2),(328,'2026-02-07 15:41:23','Reserva',70.00,1.0000,'Servicio',0.00,'Backfill histórico reserva 62',1,'Efectivo',NULL,275,0,1,2),(329,'2026-02-08 21:21:28','Reserva',100.00,1.0000,'Unidad',0.00,'Reserva reserva 63 - Cancha Smoke 1',15,'Efectivo',NULL,276,0,11,17),(330,'2026-02-08 21:21:28','Venta',30.00,1.0000,'Unidad',0.00,'#277: Producto Smoke 20260208212125 (x2)',15,'Efectivo',105,277,0,11,17),(331,'2026-02-08 21:21:28','Venta',80.00,1.0000,'Unidad',0.00,'#278: Alquiler Cancha Smoke 2',15,'Efectivo',105,278,0,11,17),(332,'2026-02-08 21:21:28','Venta',65.00,1.0000,'Unidad',0.00,'#279: Alquiler Cancha Smoke 3, Producto Smoke 20260208212125 (x1)',15,'Efectivo',105,279,0,11,17),(333,'2026-02-08 21:23:14','Reserva',100.00,1.0000,'Unidad',0.00,'Reserva reserva 66 - Cancha Smoke 1',17,'Efectivo',NULL,280,0,13,19),(334,'2026-02-08 21:23:14','Venta',30.00,1.0000,'Unidad',0.00,'#281: Producto Smoke 20260208212311 (x2)',17,'Efectivo',108,281,0,13,19),(335,'2026-02-08 21:23:14','Venta',80.00,1.0000,'Unidad',0.00,'#282: Alquiler Cancha Smoke 2',17,'Efectivo',108,282,0,13,19),(336,'2026-02-08 21:23:14','Venta',65.00,1.0000,'Unidad',0.00,'#283: Alquiler Cancha Smoke 3, Producto Smoke 20260208212311 (x1)',17,'Efectivo',108,283,0,13,19),(337,'2026-02-08 21:23:35','Reserva',100.00,1.0000,'Unidad',0.00,'Reserva reserva 69 - Cancha Smoke 1',19,'Efectivo',NULL,284,0,15,21),(338,'2026-02-08 21:23:35','Venta',30.00,1.0000,'Unidad',0.00,'#285: Producto Smoke 20260208212332 (x2)',19,'Efectivo',111,285,0,15,21),(339,'2026-02-08 21:23:35','Venta',80.00,1.0000,'Unidad',0.00,'#286: Alquiler Cancha Smoke 2',19,'Efectivo',111,286,0,15,21),(340,'2026-02-08 21:23:35','Venta',65.00,1.0000,'Unidad',0.00,'#287: Alquiler Cancha Smoke 3, Producto Smoke 20260208212332 (x1)',19,'Efectivo',111,287,0,15,21),(341,'2026-02-08 21:23:54','Reserva',100.00,1.0000,'Unidad',0.00,'Reserva reserva 72 - Cancha Smoke 1',21,'Efectivo',NULL,288,0,17,23),(342,'2026-02-08 21:23:54','Venta',30.00,1.0000,'Unidad',0.00,'#289: Producto Smoke 20260208212351 (x2)',21,'Efectivo',114,289,0,17,23),(343,'2026-02-08 21:23:54','Venta',80.00,1.0000,'Unidad',0.00,'#290: Alquiler Cancha Smoke 2',21,'Efectivo',114,290,0,17,23),(344,'2026-02-08 21:23:54','Venta',65.00,1.0000,'Unidad',0.00,'#291: Alquiler Cancha Smoke 3, Producto Smoke 20260208212351 (x1)',21,'Efectivo',114,291,0,17,23),(345,'2026-02-08 21:25:40','Reserva',100.00,1.0000,'Unidad',0.00,'Reserva reserva 75 - Cancha Smoke 1',23,'Efectivo',NULL,292,0,19,25),(346,'2026-02-08 21:25:40','Venta',30.00,1.0000,'Unidad',0.00,'#293: Producto Smoke 20260208212537 (x2)',23,'Efectivo',117,293,0,19,25),(347,'2026-02-08 21:25:40','Venta',80.00,1.0000,'Unidad',0.00,'#294: Alquiler Cancha Smoke 2',23,'Efectivo',117,294,0,19,25),(348,'2026-02-08 21:25:40','Venta',65.00,1.0000,'Unidad',0.00,'#295: Alquiler Cancha Smoke 3, Producto Smoke 20260208212537 (x1)',23,'Efectivo',117,295,0,19,25);
/*!40000 ALTER TABLE `cashboxlog` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `cashboxsession`
--

DROP TABLE IF EXISTS `cashboxsession`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `cashboxsession` (
  `id` int NOT NULL AUTO_INCREMENT,
  `opening_time` datetime DEFAULT NULL,
  `closing_time` datetime DEFAULT NULL,
  `opening_amount` decimal(10,2) DEFAULT NULL,
  `closing_amount` decimal(10,2) DEFAULT NULL,
  `is_open` tinyint(1) NOT NULL,
  `user_id` int DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ix_cashboxsession_company_id` (`company_id`),
  KEY `ix_cashboxsession_branch_id` (`branch_id`),
  CONSTRAINT `cashboxsession_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `cashboxsession_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `fk_cashboxsession_company_id` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cashboxsession`
--

LOCK TABLES `cashboxsession` WRITE;
/*!40000 ALTER TABLE `cashboxsession` DISABLE KEYS */;
INSERT INTO `cashboxsession` VALUES (1,'2026-01-01 23:01:44','2026-01-04 00:15:47',100.00,384.36,0,1,1,2),(2,'2026-01-04 00:56:14','2026-01-04 03:03:12',100.00,120.00,0,1,1,2),(3,'2026-01-04 03:03:25','2026-01-05 18:55:41',100.00,718.10,0,1,1,2),(4,'2026-01-05 18:56:10','2026-01-06 18:36:28',100.00,100.00,0,1,1,2),(5,'2026-01-06 19:30:09','2026-01-08 10:35:31',100.00,158.10,0,1,1,2),(6,'2026-01-08 10:36:48','2026-01-08 10:42:18',100.00,241.40,0,1,1,2),(7,'2026-01-08 10:50:03','2026-01-08 11:11:32',100.00,316.76,0,1,1,2),(8,'2026-01-08 11:12:23','2026-01-11 23:41:23',100.00,142.70,0,1,1,2),(9,'2026-01-11 23:41:58','2026-01-12 11:46:14',100.00,470.88,0,1,1,2),(10,'2026-01-12 11:46:34','2026-01-12 12:01:46',100.00,209.45,0,1,1,2),(11,'2026-01-12 12:03:55','2026-01-12 14:36:49',100.00,120.00,0,1,1,2),(12,'2026-01-12 14:36:58','2026-01-13 02:19:54',100.00,198.10,0,1,1,2),(13,'2026-01-16 16:00:38','2026-01-18 22:09:24',100.00,357.10,0,1,1,2),(14,'2026-01-19 02:24:42','2026-01-21 07:28:30',100.00,515.60,0,1,1,2),(15,'2026-01-21 07:28:46','2026-01-21 07:38:46',100.00,120.00,0,1,1,2),(16,'2026-01-22 18:15:50','2026-01-27 16:42:26',100.00,267.30,0,1,1,2),(17,'2026-01-27 20:05:57','2026-01-31 15:55:10',100.00,132.70,0,1,1,2),(18,'2026-01-31 15:21:13','2026-02-02 02:39:43',100.00,129.00,0,1,1,3),(19,'2026-02-02 02:46:01','2026-02-02 03:51:12',100.00,120.00,0,1,1,2),(20,'2026-02-02 03:24:17','2026-02-02 03:50:56',100.00,100.00,0,1,1,3),(21,'2026-02-02 15:57:53',NULL,100.00,0.00,1,11,3,4),(22,'2026-02-02 17:13:53',NULL,100.00,0.00,1,9,2,1),(23,'2026-02-02 19:18:15','2026-02-06 19:29:25',100.00,1762.16,0,1,1,2),(24,'2026-02-05 19:33:28','2026-02-05 19:40:03',100.00,100.00,0,8,1,3),(25,'2026-02-05 19:40:12','2026-02-05 19:41:36',100.00,120.00,0,8,1,2),(26,'2026-02-06 19:35:52',NULL,100.00,0.00,1,1,1,2);
/*!40000 ALTER TABLE `cashboxsession` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `category`
--

DROP TABLE IF EXISTS `category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `category` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_category_company_branch_name` (`company_id`,`branch_id`,`name`),
  KEY `ix_category_company_id` (`company_id`),
  KEY `ix_category_name` (`name`),
  KEY `ix_category_branch_id` (`branch_id`),
  CONSTRAINT `category_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `fk_category_company_id` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `category`
--

LOCK TABLES `category` WRITE;
/*!40000 ALTER TABLE `category` DISABLE KEYS */;
INSERT INTO `category` VALUES (1,'Bebidas',1,2),(8,'Lacteos',1,2),(2,'Medicina',1,2),(20,'Panadería',1,2),(15,'Zapatillas de Futbol',1,2),(14,'Zapatillas Runner',1,2),(5,'BEBIDAS',1,3),(4,'General',1,3),(16,'General',1,6),(17,'General',1,7),(18,'General',1,8),(19,'General',1,9),(22,'General',1,16),(3,'General',2,1),(6,'General',3,4),(10,'Golosinas',3,4),(12,'Medicamentos',3,4),(11,'Prendas de Vestir',3,4),(13,'Zapatillas Futbol',3,4),(9,'Zapatillas Runner',3,4),(7,'General',4,5),(21,'General',5,10);
/*!40000 ALTER TABLE `category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `client` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `dni` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `credit_limit` decimal(10,2) DEFAULT NULL,
  `current_debt` decimal(10,2) DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_client_company_branch_dni` (`company_id`,`branch_id`,`dni`),
  KEY `ix_client_name` (`name`),
  KEY `ix_client_company_id` (`company_id`),
  KEY `ix_client_dni` (`dni`),
  KEY `ix_client_branch_id` (`branch_id`),
  CONSTRAINT `client_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `fk_client_company_id` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,'Robert Oscorima','96311537','942136196','Pueyrredon 863',5000.00,122.77,1,2),(2,'Hender Huamaní','72075195','321456789','Jirón Conde S/N',6000.00,112.36,1,2),(3,'Mateo Oscorima','987456123','546879231','Pueyrredon 800',3000.00,105.66,1,2),(5,'Marvid Vivanco','123159753','123654789','Jiron Conde S/N',5000.00,0.00,1,2);
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `company`
--

DROP TABLE IF EXISTS `company`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `company` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `ruc` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `trial_ends_at` datetime DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `plan_type` varchar(255) NOT NULL,
  `max_branches` int NOT NULL,
  `max_users` int NOT NULL,
  `has_reservations_module` tinyint(1) NOT NULL,
  `has_electronic_billing` tinyint(1) NOT NULL,
  `subscription_status` varchar(255) NOT NULL,
  `subscription_ends_at` datetime DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_company_ruc` (`ruc`),
  KEY `ix_company_name` (`name`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `company`
--

LOCK TABLES `company` WRITE;
/*!40000 ALTER TABLE `company` DISABLE KEYS */;
INSERT INTO `company` VALUES (1,'Default Company','00000000000',1,'2026-02-13 14:28:12','2026-01-29 14:28:12','professional',10,-1,1,0,'active','2026-03-04 00:27:36'),(2,'Empresa Alpha S.A.','TEMPead67f67568',1,'2026-02-13 21:48:38','2026-01-29 21:48:38','standard',5,10,1,0,'active','2026-03-04 00:27:23'),(3,'Beta Alpha S.A.','TEMP524fa19bebd',1,'2026-02-17 01:56:11','2026-01-31 22:01:05','trial',2,3,1,0,'active',NULL),(4,'Omega SAC','TEMP395248bdb25',1,'2026-02-17 01:35:15','2026-02-02 01:35:15','trial',2,3,1,0,'active',NULL),(5,'Mi Tienda 456','TEMP2fe9066618c',1,'2026-02-22 03:20:02','2026-02-07 03:20:02','trial',2,3,1,0,'active',NULL),(11,'SMOKE-A-20260208212125','SMKA20260208212125',1,NULL,'2026-02-08 21:21:25','trial',2,3,1,0,'active',NULL),(12,'SMOKE-B-20260208212125','SMKB20260208212125',1,NULL,'2026-02-08 21:21:26','trial',2,3,1,0,'active',NULL),(13,'SMOKE-A-20260208212311','SMKA20260208212311',1,NULL,'2026-02-08 21:23:12','trial',2,3,1,0,'active',NULL),(14,'SMOKE-B-20260208212311','SMKB20260208212311',1,NULL,'2026-02-08 21:23:12','trial',2,3,1,0,'active',NULL),(15,'SMOKE-A-20260208212332','SMKA20260208212332',1,NULL,'2026-02-08 21:23:33','trial',2,3,1,0,'active',NULL),(16,'SMOKE-B-20260208212332','SMKB20260208212332',1,NULL,'2026-02-08 21:23:33','trial',2,3,1,0,'active',NULL),(17,'SMOKE-A-20260208212351','SMKA20260208212351',1,NULL,'2026-02-08 21:23:52','trial',2,3,1,0,'active',NULL),(18,'SMOKE-B-20260208212351','SMKB20260208212351',1,NULL,'2026-02-08 21:23:52','trial',2,3,1,0,'active',NULL),(19,'SMOKE-A-20260208212537','SMKA20260208212537',1,NULL,'2026-02-08 21:25:38','trial',2,3,1,0,'active',NULL),(20,'SMOKE-B-20260208212537','SMKB20260208212537',1,NULL,'2026-02-08 21:25:38','trial',2,3,1,0,'active',NULL);
/*!40000 ALTER TABLE `company` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `companysettings`
--

DROP TABLE IF EXISTS `companysettings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `companysettings` (
  `id` int NOT NULL AUTO_INCREMENT,
  `company_name` varchar(255) NOT NULL,
  `ruc` varchar(255) NOT NULL,
  `address` varchar(255) NOT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `footer_message` varchar(255) DEFAULT NULL,
  `receipt_paper` varchar(10) NOT NULL,
  `receipt_width` int DEFAULT NULL,
  `default_currency_code` varchar(10) NOT NULL DEFAULT 'PEN',
  `country_code` varchar(5) NOT NULL DEFAULT 'PE',
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `timezone` varchar(64) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_companysettings_company_branch` (`company_id`,`branch_id`),
  KEY `ix_companysettings_branch_id` (`branch_id`),
  KEY `ix_companysettings_company_id` (`company_id`),
  CONSTRAINT `companysettings_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `companysettings_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `companysettings`
--

LOCK TABLES `companysettings` WRITE;
/*!40000 ALTER TABLE `companysettings` DISABLE KEYS */;
INSERT INTO `companysettings` VALUES (1,'WAYKI S.A.C','72075195-5','AVENIDA PUEYRREDON 683','+5491168376517','¡GRACIAS POR SU PREFERENCIA!','80',NULL,'PEN','PE',1,2,NULL),(2,'WAYKI S.A.C','72075195-5','AVENIDA PUEYRREDON 683','+5491168376517','¡GRACIAS POR SU PREFERENCIA!','80',NULL,'PEN','PE',1,3,NULL),(3,'','','',NULL,NULL,'80',NULL,'ARS','PE',2,1,NULL),(4,'Omega SAC','TEMP395248bdb25','','+51954136196',NULL,'80',NULL,'PEN','PE',4,5,NULL),(5,'','','',NULL,NULL,'80',NULL,'PEN','PE',3,4,NULL),(6,'Mi Tienda 456','TEMP2fe9066618c','','954136196',NULL,'80',NULL,'PEN','PE',5,10,NULL);
/*!40000 ALTER TABLE `companysettings` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `currency`
--

DROP TABLE IF EXISTS `currency`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `currency` (
  `id` int NOT NULL AUTO_INCREMENT,
  `code` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `symbol` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_currency_code` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `currency`
--

LOCK TABLES `currency` WRITE;
/*!40000 ALTER TABLE `currency` DISABLE KEYS */;
INSERT INTO `currency` VALUES (1,'PEN','Sol peruano (PEN)','S/'),(2,'ARS','Peso argentino (ARS)','$'),(3,'USD','Dolar estadounidense (USD)','US$');
/*!40000 ALTER TABLE `currency` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldprice`
--

DROP TABLE IF EXISTS `fieldprice`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldprice` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sport` enum('futbol','voley') NOT NULL,
  `name` varchar(255) NOT NULL,
  `price` decimal(10,2) DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_fieldprice_branch_id` (`branch_id`),
  KEY `ix_fieldprice_company_id` (`company_id`),
  CONSTRAINT `fieldprice_ibfk_1` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `fieldprice_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldprice`
--

LOCK TABLES `fieldprice` WRITE;
/*!40000 ALTER TABLE `fieldprice` DISABLE KEYS */;
INSERT INTO `fieldprice` VALUES (1,'futbol','Cancha 1 Día',50.00,1,2),(2,'futbol','Cancha 2 Noche',70.00,1,2),(3,'voley','Cancha 1 Día',50.00,1,2),(4,'voley','Cancha  Día2',70.00,1,2),(5,'futbol','Campo 1 Dia',50.00,1,3);
/*!40000 ALTER TABLE `fieldprice` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `fieldreservation`
--

DROP TABLE IF EXISTS `fieldreservation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `fieldreservation` (
  `id` int NOT NULL AUTO_INCREMENT,
  `client_name` varchar(255) NOT NULL,
  `client_dni` varchar(255) DEFAULT NULL,
  `client_phone` varchar(255) DEFAULT NULL,
  `sport` enum('futbol','voley') NOT NULL,
  `field_name` varchar(255) NOT NULL,
  `start_datetime` datetime DEFAULT NULL,
  `end_datetime` datetime DEFAULT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `paid_amount` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','paid','cancelled','refunded') NOT NULL,
  `user_id` int DEFAULT NULL,
  `cancellation_reason` varchar(255) DEFAULT NULL,
  `delete_reason` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ix_fieldreservation_start_datetime` (`start_datetime`),
  KEY `ix_fieldreservation_branch_id` (`branch_id`),
  KEY `ix_fieldreservation_company_id` (`company_id`),
  KEY `ix_fieldreservation_company_branch_sport_start` (`company_id`,`branch_id`,`sport`,`start_datetime`),
  CONSTRAINT `fieldreservation_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `fieldreservation_ibfk_2` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `fieldreservation_ibfk_3` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `fieldreservation`
--

LOCK TABLES `fieldreservation` WRITE;
/*!40000 ALTER TABLE `fieldreservation` DISABLE KEYS */;
INSERT INTO `fieldreservation` VALUES (1,'Pablito','','','futbol','Cancha 1 Día','2026-01-02 00:00:00','2026-01-02 01:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-02 01:10:25',1,2),(2,'Susana','','','voley','Cancha 1 Día','2026-01-02 00:00:00','2026-01-02 01:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-02 01:30:15',1,2),(3,'Pablito','','','futbol','Cancha 1 Día','2026-01-02 01:00:00','2026-01-02 02:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-02 13:51:15',1,2),(4,'Susana 2','','','voley','Cancha 1 Día','2026-01-02 01:00:00','2026-01-02 02:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-02 15:47:22',1,2),(5,'Pablito Test','','','futbol','Cancha 2 Noche','2026-01-02 02:00:00','2026-01-02 03:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-02 16:41:41',1,2),(6,'Ximena','','','voley','Cancha  Día2','2026-01-02 02:00:00','2026-01-02 03:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-02 16:53:49',1,2),(7,'Pedrito','','123456789','futbol','Cancha 1 Día','2026-01-03 00:00:00','2026-01-03 01:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-03 19:37:56',1,2),(8,'Robert Oscorima','','1168376517','voley','Cancha  Día2','2026-01-03 00:00:00','2026-01-03 01:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-03 20:44:50',1,2),(9,'Susanita','','','voley','Cancha  Día2','2026-01-03 01:00:00','2026-01-03 02:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-03 20:47:52',1,2),(10,'Pablito Perez','','','futbol','Cancha 1 Día','2026-01-03 01:00:00','2026-01-03 02:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-03 22:16:27',1,2),(11,'Perez Carlitos','','','futbol','Cancha 1 Día','2026-01-03 02:00:00','2026-01-03 03:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-03 22:19:25',1,2),(12,'Carlitos Perez','','','futbol','Cancha 2 Noche','2026-01-03 03:00:00','2026-01-03 04:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-03 22:25:01',1,2),(13,'Ximena','','123456789','voley','Cancha  Día2','2026-01-03 02:00:00','2026-01-03 03:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-04 00:03:35',1,2),(14,'Maxima','','','voley','Cancha  Día2','2026-01-03 03:00:00','2026-01-03 04:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-04 00:06:46',1,2),(15,'Rossy','','','voley','Cancha 1 Día','2026-01-03 04:00:00','2026-01-03 05:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-04 00:08:11',1,2),(16,'Pedrito','','','futbol','Cancha 2 Noche','2026-01-04 00:00:00','2026-01-04 01:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-04 00:59:57',1,2),(17,'Susana','','','voley','Cancha  Día2','2026-01-04 00:00:00','2026-01-04 01:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-04 03:08:37',1,2),(18,'Pedrito','','123456789','futbol','Cancha 2 Noche','2026-01-04 01:00:00','2026-01-04 02:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-04 03:12:48',1,2),(19,'Ximena','','','voley','Cancha  Día2','2026-01-04 01:00:00','2026-01-04 02:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-04 03:15:54',1,2),(20,'Pablito Perez','','','futbol','Cancha 2 Noche','2026-01-04 02:00:00','2026-01-04 03:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-04 03:59:05',1,2),(21,'Rossy','','','voley','Cancha  Día2','2026-01-04 02:00:00','2026-01-04 03:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-04 04:05:39',1,2),(22,'Ximena','','','voley','Cancha  Día2','2026-01-04 03:00:00','2026-01-04 04:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-04 04:10:25',1,2),(23,'Pablito','','','futbol','Cancha 2 Noche','2026-01-04 03:00:00','2026-01-04 04:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-04 05:00:14',1,2),(24,'Robert','','','futbol','Cancha 2 Noche','2026-01-04 04:00:00','2026-01-04 05:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-04 05:07:45',1,2),(25,'Susanita Ludo','','','voley','Cancha  Día2','2026-01-04 04:00:00','2026-01-04 05:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-04 07:52:02',1,2),(26,'Robert','','','futbol','Cancha 2 Noche','2026-01-05 00:00:00','2026-01-05 01:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-05 00:56:02',1,2),(27,'Pedrito Prueba','','','futbol','Cancha 1 Día','2026-01-07 00:00:00','2026-01-07 01:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-07 11:24:37',1,2),(28,'Susana','','','voley','Cancha 1 Día','2026-01-07 00:00:00','2026-01-07 01:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-08 10:37:12',1,2),(29,'Pablito','','','futbol','Cancha 1 Día','2026-01-07 01:00:00','2026-01-07 02:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-08 10:40:48',1,2),(30,'Pablito','','','futbol','Cancha 2 Noche','2026-01-08 00:00:00','2026-01-08 01:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-08 11:03:39',1,2),(31,'Susana','','','voley','Cancha 1 Día','2026-01-08 00:00:00','2026-01-08 01:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-08 11:04:38',1,2),(32,'Pedrito','','','futbol','Cancha 1 Día','2026-01-08 01:00:00','2026-01-08 02:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-08 11:06:07',1,2),(33,'Pedrito','','','futbol','Cancha 2 Noche','2026-01-09 00:00:00','2026-01-09 01:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-09 16:12:50',1,2),(34,'Pedrio','','','futbol','Cancha 2 Noche','2026-01-10 06:00:00','2026-01-10 07:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-11 20:23:46',1,2),(35,'Susana','','','voley','Cancha  Día2','2026-01-11 06:00:00','2026-01-11 07:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-11 23:48:26',1,2),(36,'Pablito Perez','','','futbol','Cancha 2 Noche','2026-01-12 06:00:00','2026-01-12 07:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-12 00:48:46',1,2),(37,'Ximena','','','voley','Cancha  Día2','2026-01-12 06:00:00','2026-01-12 07:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-12 01:41:58',1,2),(38,'Mateo Oscorima','','','voley','Cancha  Día2','2026-01-12 07:00:00','2026-01-12 08:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-12 01:44:58',1,2),(39,'Robert Oscorima','','','futbol','Cancha 2 Noche','2026-01-12 07:00:00','2026-01-12 08:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-12 11:59:52',1,2),(40,'Mateo Oscorima','','','futbol','Cancha 2 Noche','2026-01-12 08:00:00','2026-01-12 09:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-12 12:04:38',1,2),(41,'Pedrito Prueba','','','futbol','Cancha 2 Noche','2026-01-18 06:00:00','2026-01-18 07:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-18 21:53:18',1,2),(42,'Susana Prueba','','','voley','Cancha 1 Día','2026-01-18 06:00:00','2026-01-18 07:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-18 21:54:41',1,2),(43,'Pedrito Prueba','','','futbol','Cancha 1 Día','2026-01-19 06:00:00','2026-01-19 07:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-19 10:48:05',1,2),(44,'Ximena Prueba','','','voley','Cancha  Día2','2026-01-19 06:00:00','2026-01-19 07:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-19 10:49:18',1,2),(45,'Pablito Prueba 2','','','futbol','Cancha 2 Noche','2026-01-19 07:00:00','2026-01-19 08:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-19 11:56:40',1,2),(46,'Rossy Prueba','','','voley','Cancha  Día2','2026-01-19 07:00:00','2026-01-19 08:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-19 12:02:29',1,2),(47,'Susana','','','voley','Cancha  Día2','2026-01-20 06:00:00','2026-01-20 07:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-20 13:23:20',1,2),(48,'Pablito','','','futbol','Cancha 1 Día','2026-01-21 06:00:00','2026-01-21 07:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-21 07:22:19',1,2),(49,'Ximena','','','voley','Cancha  Día2','2026-01-21 06:00:00','2026-01-21 07:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-21 07:23:13',1,2),(50,'Pablito Prueba','','','futbol','Cancha 2 Noche','2026-01-21 07:00:00','2026-01-21 08:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-21 07:29:36',1,2),(51,'Pedrito Prueba','','','futbol','Cancha 2 Noche','2026-01-26 06:00:00','2026-01-26 07:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-01-26 11:11:46',1,2),(52,'Pedrito','','','futbol','Cancha 1 Día','2026-01-27 06:00:00','2026-01-27 07:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-27 04:18:04',1,2),(53,'Pablito Prueba','','','futbol','Cancha 1 Día','2026-01-27 07:00:00','2026-01-27 08:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-01-27 20:05:44',1,2),(54,'Pedrito Pablo','','123456789','futbol','Campo 1 Dia','2026-02-02 06:00:00','2026-02-02 07:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-02-02 02:35:19',1,3),(55,'Pablito Prueba','','','voley','Cancha 1 Día','2026-02-02 06:00:00','2026-02-02 07:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-02-02 03:22:02',1,2),(56,'Pablito Test','','','futbol','Campo 1 Dia','2026-02-02 07:00:00','2026-02-02 08:00:00',50.00,20.00,'pending',1,NULL,NULL,'2026-02-02 03:23:19',1,3),(57,'Pablito Prueba','','','futbol','Cancha 2 Noche','2026-02-04 06:00:00','2026-02-04 07:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-02-04 20:01:01',1,2),(58,'Pedrito prueba','','','futbol','Cancha 2 Noche','2026-02-05 06:00:00','2026-02-05 07:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-02-05 19:11:02',1,2),(59,'Pablito Perez','','','futbol','Cancha 2 Noche','2026-02-06 06:00:00','2026-02-06 07:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-02-06 19:23:55',1,2),(60,'Susanita','','','voley','Cancha 1 Día','2026-02-06 06:00:00','2026-02-06 07:00:00',50.00,50.00,'paid',1,NULL,NULL,'2026-02-06 20:12:29',1,2),(62,'Pablito Perez','','','futbol','Cancha 2 Noche','2026-02-07 09:00:00','2026-02-07 10:00:00',70.00,70.00,'paid',1,NULL,NULL,'2026-02-07 15:41:23',1,2),(63,'Cliente Smoke Servicios 20260208212125','10000001','900000001','futbol','Cancha Smoke 1','2026-02-08 23:21:00','2026-02-09 00:21:00',120.00,120.00,'paid',15,NULL,NULL,'2026-02-08 21:21:26',11,17),(64,'Cliente Smoke Venta Reserva 20260208212125','10000002','900000002','futbol','Cancha Smoke 2','2026-02-09 01:21:00','2026-02-09 02:21:00',80.00,80.00,'paid',15,NULL,NULL,'2026-02-08 21:21:26',11,17),(65,'Cliente Smoke Combo 20260208212125','10000003','900000003','futbol','Cancha Smoke 3','2026-02-09 03:21:00','2026-02-09 04:21:00',60.00,60.00,'paid',15,NULL,NULL,'2026-02-08 21:21:26',11,17),(66,'Cliente Smoke Servicios 20260208212311','10000001','900000001','futbol','Cancha Smoke 1','2026-02-08 23:23:00','2026-02-09 00:23:00',120.00,120.00,'paid',17,NULL,NULL,'2026-02-08 21:23:13',13,19),(67,'Cliente Smoke Venta Reserva 20260208212311','10000002','900000002','futbol','Cancha Smoke 2','2026-02-09 01:23:00','2026-02-09 02:23:00',80.00,80.00,'paid',17,NULL,NULL,'2026-02-08 21:23:13',13,19),(68,'Cliente Smoke Combo 20260208212311','10000003','900000003','futbol','Cancha Smoke 3','2026-02-09 03:23:00','2026-02-09 04:23:00',60.00,60.00,'paid',17,NULL,NULL,'2026-02-08 21:23:13',13,19),(69,'Cliente Smoke Servicios 20260208212332','10000001','900000001','futbol','Cancha Smoke 1','2026-02-08 23:23:00','2026-02-09 00:23:00',120.00,120.00,'paid',19,NULL,NULL,'2026-02-08 21:23:34',15,21),(70,'Cliente Smoke Venta Reserva 20260208212332','10000002','900000002','futbol','Cancha Smoke 2','2026-02-09 01:23:00','2026-02-09 02:23:00',80.00,80.00,'paid',19,NULL,NULL,'2026-02-08 21:23:34',15,21),(71,'Cliente Smoke Combo 20260208212332','10000003','900000003','futbol','Cancha Smoke 3','2026-02-09 03:23:00','2026-02-09 04:23:00',60.00,60.00,'paid',19,NULL,NULL,'2026-02-08 21:23:34',15,21),(72,'Cliente Smoke Servicios 20260208212351','10000001','900000001','futbol','Cancha Smoke 1','2026-02-08 23:23:00','2026-02-09 00:23:00',120.00,120.00,'paid',21,NULL,NULL,'2026-02-08 21:23:52',17,23),(73,'Cliente Smoke Venta Reserva 20260208212351','10000002','900000002','futbol','Cancha Smoke 2','2026-02-09 01:23:00','2026-02-09 02:23:00',80.00,80.00,'paid',21,NULL,NULL,'2026-02-08 21:23:52',17,23),(74,'Cliente Smoke Combo 20260208212351','10000003','900000003','futbol','Cancha Smoke 3','2026-02-09 03:23:00','2026-02-09 04:23:00',60.00,60.00,'paid',21,NULL,NULL,'2026-02-08 21:23:52',17,23),(75,'Cliente Smoke Servicios 20260208212537','10000001','900000001','futbol','Cancha Smoke 1','2026-02-08 23:25:00','2026-02-09 00:25:00',120.00,120.00,'paid',23,NULL,NULL,'2026-02-08 21:25:39',19,25),(76,'Cliente Smoke Venta Reserva 20260208212537','10000002','900000002','futbol','Cancha Smoke 2','2026-02-09 01:25:00','2026-02-09 02:25:00',80.00,80.00,'paid',23,NULL,NULL,'2026-02-08 21:25:39',19,25),(77,'Cliente Smoke Combo 20260208212537','10000003','900000003','futbol','Cancha Smoke 3','2026-02-09 03:25:00','2026-02-09 04:25:00',60.00,60.00,'paid',23,NULL,NULL,'2026-02-08 21:25:39',19,25);
/*!40000 ALTER TABLE `fieldreservation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `paymentmethod`
--

DROP TABLE IF EXISTS `paymentmethod`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `paymentmethod` (
  `id` int NOT NULL AUTO_INCREMENT,
  `method_id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `kind` enum('cash','debit','credit','yape','plin','transfer','mixed','other','card','wallet') NOT NULL,
  `enabled` tinyint(1) NOT NULL,
  `code` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `allows_change` tinyint(1) NOT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_paymentmethod_company_branch_code` (`company_id`,`branch_id`,`code`),
  UNIQUE KEY `uq_paymentmethod_company_branch_method_id` (`company_id`,`branch_id`,`method_id`),
  KEY `ix_paymentmethod_company_id` (`company_id`),
  KEY `ix_paymentmethod_code` (`code`),
  KEY `ix_paymentmethod_method_id` (`method_id`),
  KEY `ix_paymentmethod_branch_id` (`branch_id`),
  CONSTRAINT `fk_paymentmethod_company_id` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `paymentmethod_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=120 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `paymentmethod`
--

LOCK TABLES `paymentmethod` WRITE;
/*!40000 ALTER TABLE `paymentmethod` DISABLE KEYS */;
INSERT INTO `paymentmethod` VALUES (8,'cash','Efectivo','Billetes, Monedas','cash',1,'cash',1,1,1,2),(9,'debit_card','T. Débito','Pago con tarjeta débito','debit',1,'debit_card',1,0,1,2),(10,'credit_card','T. Crédito','Pago con tarjeta crédito','credit',1,'credit_card',1,0,1,2),(11,'yape','Yape','Pago con Yape','yape',1,'yape',1,0,1,2),(12,'plin','Plin','Pago con Plin','plin',1,'plin',1,0,1,2),(13,'transfer','Transferencia','Transferencia','transfer',1,'transfer',1,0,1,2),(14,'mixed','Pago Mixto','Combinacion','mixed',0,'mixed',0,0,1,2),(15,'cash','Efectivo','Billetes, Monedas','cash',1,'cash',1,1,2,1),(16,'transfer','Transferencia','Transferencia bancaria','transfer',1,'transfer',1,0,2,1),(17,'credit_card','Tarjeta de Crédito','Pago con tarjeta crédito','credit',1,'credit_card',1,0,2,1),(18,'debit_card','Tarjeta de Débito','Pago con tarjeta débito','debit',1,'debit_card',1,0,2,1),(20,'yape','Yape','Pago con Yape (BCP)','yape',1,'yape',1,0,2,1),(21,'plin','Plin','Pago con Plin','plin',1,'plin',1,0,2,1),(22,'mixed','Pago Mixto','Combinacion','mixed',1,'mixed',1,0,2,1),(23,'cash','Efectivo','Billetes, Monedas','cash',1,'cash',1,1,1,3),(24,'transfer','Transferencia','Transferencia bancaria','transfer',1,'transfer',1,0,1,3),(25,'credit_card','Tarjeta de Crédito','Pago con tarjeta crédito','credit',1,'credit_card',1,0,1,3),(26,'debit_card','Tarjeta de Débito','Pago con tarjeta débito','debit',1,'debit_card',1,0,1,3),(28,'yape','Yape','Pago con Yape (BCP)','yape',1,'yape',1,0,1,3),(29,'plin','Plin','Pago con Plin','plin',1,'plin',1,0,1,3),(30,'mixed','Pago Mixto','Combinacion','mixed',1,'mixed',1,0,1,3),(31,'cash','Efectivo','Billetes, Monedas','cash',1,'cash',1,1,3,4),(32,'transfer','Transferencia','Transferencia bancaria','transfer',1,'transfer',1,0,3,4),(33,'credit_card','Tarjeta de Crédito','Pago con tarjeta crédito','credit',1,'credit_card',1,0,3,4),(34,'debit_card','Tarjeta de Débito','Pago con tarjeta débito','debit',1,'debit_card',1,0,3,4),(36,'yape','Yape','Pago con Yape (BCP)','yape',1,'yape',1,0,3,4),(37,'plin','Plin','Pago con Plin','plin',1,'plin',1,0,3,4),(38,'mixed','Pago Mixto','Combinacion','mixed',1,'mixed',1,0,3,4),(39,'cash','Efectivo','Billetes, Monedas','cash',1,'cash',1,1,4,5),(40,'transfer','Transferencia','Transferencia bancaria','transfer',1,'transfer',1,0,4,5),(41,'credit_card','Tarjeta de Crédito','Pago con tarjeta crédito','credit',1,'credit_card',1,0,4,5),(42,'debit_card','Tarjeta de Débito','Pago con tarjeta débito','debit',1,'debit_card',1,0,4,5),(43,'credit_sale','Crédito / Fiado','Venta al crédito','credit',1,'credit_sale',1,0,4,5),(44,'yape','Yape','Pago con Yape (BCP)','yape',1,'yape',1,0,4,5),(45,'plin','Plin','Pago con Plin','plin',1,'plin',1,0,4,5),(46,'mixed','Pago Mixto','Combinacion','mixed',1,'mixed',1,0,4,5),(48,'cash','Efectivo','Billetes, Monedas','cash',1,'cash',1,1,1,6),(49,'transfer','Transferencia','Transferencia bancaria','transfer',1,'transfer',1,0,1,6),(50,'credit_card','Tarjeta de Crédito','Pago con tarjeta crédito','credit',1,'credit_card',1,0,1,6),(51,'debit_card','Tarjeta de Débito','Pago con tarjeta débito','debit',1,'debit_card',1,0,1,6),(52,'credit_sale','Crédito / Fiado','Venta al crédito','credit',1,'credit_sale',1,0,1,6),(53,'yape','Yape','Pago con Yape (BCP)','yape',1,'yape',1,0,1,6),(54,'plin','Plin','Pago con Plin','plin',1,'plin',1,0,1,6),(55,'cash','Efectivo','Billetes, Monedas','cash',1,'cash',1,1,1,7),(56,'transfer','Transferencia','Transferencia bancaria','transfer',1,'transfer',1,0,1,7),(57,'credit_card','Tarjeta de Crédito','Pago con tarjeta crédito','credit',1,'credit_card',1,0,1,7),(58,'debit_card','Tarjeta de Débito','Pago con tarjeta débito','debit',1,'debit_card',1,0,1,7),(59,'credit_sale','Crédito / Fiado','Venta al crédito','credit',1,'credit_sale',1,0,1,7),(60,'yape','Yape','Pago con Yape (BCP)','yape',1,'yape',1,0,1,7),(61,'plin','Plin','Pago con Plin','plin',1,'plin',1,0,1,7),(62,'cash','Efectivo','Billetes, Monedas','cash',1,'cash',1,1,1,8),(63,'transfer','Transferencia','Transferencia bancaria','transfer',1,'transfer',1,0,1,8),(64,'credit_card','Tarjeta de Crédito','Pago con tarjeta crédito','credit',1,'credit_card',1,0,1,8),(65,'debit_card','Tarjeta de Débito','Pago con tarjeta débito','debit',1,'debit_card',1,0,1,8),(66,'credit_sale','Crédito / Fiado','Venta al crédito','credit',1,'credit_sale',1,0,1,8),(67,'yape','Yape','Pago con Yape (BCP)','yape',1,'yape',1,0,1,8),(68,'plin','Plin','Pago con Plin','plin',1,'plin',1,0,1,8),(69,'cash','Efectivo','Billetes, Monedas','cash',1,'cash',1,1,1,9),(70,'transfer','Transferencia','Transferencia bancaria','transfer',1,'transfer',1,0,1,9),(71,'credit_card','Tarjeta de Crédito','Pago con tarjeta crédito','credit',1,'credit_card',1,0,1,9),(72,'debit_card','Tarjeta de Débito','Pago con tarjeta débito','debit',1,'debit_card',1,0,1,9),(73,'credit_sale','Crédito / Fiado','Venta al crédito','credit',1,'credit_sale',1,0,1,9),(74,'yape','Yape','Pago con Yape (BCP)','yape',1,'yape',1,0,1,9),(75,'plin','Plin','Pago con Plin','plin',1,'plin',1,0,1,9),(76,'mixed','Pago Mixto','Combinacion','mixed',1,'mixed',1,0,1,7),(77,'cash','Efectivo','Billetes, Monedas','cash',1,'cash',1,1,5,10),(78,'transfer','Transferencia','Transferencia bancaria','transfer',1,'transfer',1,0,5,10),(79,'credit_card','Tarjeta de Crédito','Pago con tarjeta crédito','credit',1,'credit_card',1,0,5,10),(80,'debit_card','Tarjeta de Débito','Pago con tarjeta débito','debit',1,'debit_card',1,0,5,10),(81,'credit_sale','Crédito / Fiado','Venta al crédito','credit',1,'credit_sale',1,0,5,10),(82,'yape','Yape','Pago con Yape (BCP)','yape',1,'yape',1,0,5,10),(83,'plin','Plin','Pago con Plin','plin',1,'plin',1,0,5,10),(84,'mixed','Pago Mixto','Combinacion','mixed',1,'mixed',1,0,5,10),(97,'cash','Efectivo','Billetes, Monedas','cash',1,'cash',1,1,1,16),(98,'transfer','Transferencia','Transferencia bancaria','transfer',1,'transfer',1,0,1,16),(99,'credit_card','Tarjeta de Crédito','Pago con tarjeta crédito','credit',1,'credit_card',1,0,1,16),(100,'debit_card','Tarjeta de Débito','Pago con tarjeta débito','debit',1,'debit_card',1,0,1,16),(101,'credit_sale','Crédito / Fiado','Venta al crédito','credit',1,'credit_sale',1,0,1,16),(102,'yape','Yape','Pago con Yape (BCP)','yape',1,'yape',1,0,1,16),(103,'plin','Plin','Pago con Plin','plin',1,'plin',1,0,1,16),(104,'mixed','Pago Mixto','Combinacion','mixed',1,'mixed',1,0,1,16),(105,'SMK-CASH-20260208212125','Efectivo','Smoke cash','cash',1,'cash',1,1,11,17),(106,'SMK-DEBIT-20260208212125','Tarjeta Debito','Smoke debit','debit',1,'debit_card',1,0,11,17),(107,'SMK-CREDIT-20260208212125','Tarjeta Credito','Smoke credit','credit',1,'credit_card',1,0,11,17),(108,'SMK-CASH-20260208212311','Efectivo','Smoke cash','cash',1,'cash',1,1,13,19),(109,'SMK-DEBIT-20260208212311','Tarjeta Debito','Smoke debit','debit',1,'debit_card',1,0,13,19),(110,'SMK-CREDIT-20260208212311','Tarjeta Credito','Smoke credit','credit',1,'credit_card',1,0,13,19),(111,'SMK-CASH-20260208212332','Efectivo','Smoke cash','cash',1,'cash',1,1,15,21),(112,'SMK-DEBIT-20260208212332','Tarjeta Debito','Smoke debit','debit',1,'debit_card',1,0,15,21),(113,'SMK-CREDIT-20260208212332','Tarjeta Credito','Smoke credit','credit',1,'credit_card',1,0,15,21),(114,'SMK-CASH-20260208212351','Efectivo','Smoke cash','cash',1,'cash',1,1,17,23),(115,'SMK-DEBIT-20260208212351','Tarjeta Debito','Smoke debit','debit',1,'debit_card',1,0,17,23),(116,'SMK-CREDIT-20260208212351','Tarjeta Credito','Smoke credit','credit',1,'credit_card',1,0,17,23),(117,'SMK-CASH-20260208212537','Efectivo','Smoke cash','cash',1,'cash',1,1,19,25),(118,'SMK-DEBIT-20260208212537','Tarjeta Debito','Smoke debit','debit',1,'debit_card',1,0,19,25),(119,'SMK-CREDIT-20260208212537','Tarjeta Credito','Smoke credit','credit',1,'credit_card',1,0,19,25);
/*!40000 ALTER TABLE `paymentmethod` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `codename` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `ix_permission_codename` (`codename`)
) ENGINE=InnoDB AUTO_INCREMENT=1552 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
INSERT INTO `permission` VALUES (1,'view_ingresos',''),(2,'create_ingresos',''),(3,'view_ventas',''),(4,'create_ventas',''),(5,'view_inventario',''),(6,'edit_inventario',''),(7,'view_historial',''),(8,'export_data',''),(9,'view_cashbox',''),(10,'manage_cashbox',''),(11,'delete_sales',''),(12,'manage_users',''),(13,'view_servicios',''),(14,'manage_reservations',''),(15,'manage_config',''),(16,'view_clientes',''),(17,'manage_clientes',''),(18,'view_cuentas',''),(19,'manage_cuentas',''),(1550,'view_compras',''),(1551,'manage_proveedores','');
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pricetier`
--

DROP TABLE IF EXISTS `pricetier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `pricetier` (
  `id` int NOT NULL AUTO_INCREMENT,
  `min_quantity` int NOT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `product_variant_id` int DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_pricetier_company_branch_product_minqty` (`company_id`,`branch_id`,`product_id`,`product_variant_id`,`min_quantity`),
  KEY `product_id` (`product_id`),
  KEY `product_variant_id` (`product_variant_id`),
  KEY `ix_pricetier_company_id` (`company_id`),
  KEY `ix_pricetier_branch_id` (`branch_id`),
  CONSTRAINT `pricetier_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `pricetier_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `pricetier_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `pricetier_ibfk_4` FOREIGN KEY (`product_variant_id`) REFERENCES `productvariant` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pricetier`
--

LOCK TABLES `pricetier` WRITE;
/*!40000 ALTER TABLE `pricetier` DISABLE KEYS */;
INSERT INTO `pricetier` VALUES (1,10,1.50,10,NULL,1,1),(4,10,4.50,2,NULL,1,2),(7,10,2.50,14,NULL,3,4);
/*!40000 ALTER TABLE `pricetier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `id` int NOT NULL AUTO_INCREMENT,
  `barcode` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `stock` decimal(10,4) DEFAULT NULL,
  `unit` varchar(255) NOT NULL,
  `purchase_price` decimal(10,2) DEFAULT NULL,
  `sale_price` decimal(10,2) DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `location` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_product_company_branch_barcode` (`company_id`,`branch_id`,`barcode`),
  KEY `ix_product_category` (`category`),
  KEY `ix_product_description` (`description`),
  KEY `ix_product_company_id` (`company_id`),
  KEY `ix_product_barcode` (`barcode`),
  KEY `ix_product_branch_id` (`branch_id`),
  CONSTRAINT `fk_product_company_id` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `product_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (1,'7791720003862','Coca Cola 500ml','Bebidas',10.0000,'Unidad',1.70,2.70,1,2,NULL),(2,'7790895011221','Gatorade 1.5l','Bebidas',50.0000,'Unidad',3.00,5.00,1,2,NULL),(3,'7790139003616','Alcohol Medicinal','Medicina',15.0000,'Unidad',3.50,5.30,1,2,NULL),(4,'7798113301611','Agua mineral 1.5L','Bebidas',15.0000,'Unidad',3.20,5.20,1,2,NULL),(5,'7509546686509','Pasta Dental Kolynos','Medicina',23.0000,'Unidad',2.50,3.50,1,2,NULL),(6,'111222333444555','COCA COLA 5ML','BEBIDAS',10.0000,'unidad',3.50,4.50,1,3,NULL),(7,'111222333444555','Leche evaporada','Lacteos',11.0000,'unidad',2.70,4.00,1,2,NULL),(8,'CAMISA-BASE','Camisa Polo Premium','General',25.0000,'Unidad',0.00,20.00,3,1,NULL),(9,'IBUPROFENO','Ibuprofeno 400mg (Caja)','General',150.0000,'Unidad',0.00,5.00,3,1,NULL),(10,'CHOCOLATE','Chocolate Barra 100g','General',500.0000,'Unidad',0.00,2.00,3,1,NULL),(12,'CAMISA-BASE','Camisa Polo Premium','Prendas de Vestir',25.0000,'Unidad',15.70,20.00,3,4,NULL),(13,'IBUPROFENO','Ibuprofeno 400mg (Caja)','Medicamentos',150.0000,'Unidad',2.50,5.00,3,4,NULL),(14,'CHOCOLATE','Chocolate Barra 100g','Golosinas',500.0000,'Unidad',2.00,3.00,3,4,NULL),(15,'123456789','Zapatillas Deportivas Runner','Zapatillas Runner',15.0000,'',50.00,60.00,3,4,NULL),(16,'7792170110551','Gatorade 1.25ml','Bebidas',20.0000,'unidad',3.00,5.00,1,2,NULL),(17,'7790895650833','Zapatillas Deportivas Futbol','Zapatillas Futbol',48.0000,'Unidad',150.00,200.00,3,4,NULL),(18,'7790895650833','Paracetamol 500mg','Medicina',23.0000,'unidad',1.50,2.70,1,2,NULL),(19,'123654789456','Zapatillas de Futbol','Zapatillas de Futbol',47.0000,'',120.00,150.00,1,2,NULL),(20,'123654789654','Zapatillas Runner','Zapatillas Runner',50.0000,'',110.00,150.00,1,2,NULL),(21,'7790250000358','Pañuelitos','Medicina',20.0000,'unidad',5.00,7.00,1,2,NULL),(24,'SMK-PROD-20260208212125','Producto Smoke 20260208212125','Smoke',97.0000,'Unidad',8.00,15.00,11,17,NULL),(25,'SMK-PROD-20260208212311','Producto Smoke 20260208212311','Smoke',97.0000,'Unidad',8.00,15.00,13,19,NULL),(26,'SMK-PROD-20260208212332','Producto Smoke 20260208212332','Smoke',97.0000,'Unidad',8.00,15.00,15,21,NULL),(27,'SMK-PROD-20260208212351','Producto Smoke 20260208212351','Smoke',97.0000,'Unidad',8.00,15.00,17,23,NULL),(28,'SMK-PROD-20260208212537','Producto Smoke 20260208212537','Smoke',97.0000,'Unidad',8.00,15.00,19,25,NULL);
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productbatch`
--

DROP TABLE IF EXISTS `productbatch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productbatch` (
  `id` int NOT NULL AUTO_INCREMENT,
  `batch_number` varchar(255) NOT NULL,
  `expiration_date` datetime DEFAULT NULL,
  `stock` decimal(10,4) DEFAULT NULL,
  `product_id` int DEFAULT NULL,
  `product_variant_id` int DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_productbatch_company_branch_product_batch` (`company_id`,`branch_id`,`product_id`,`product_variant_id`,`batch_number`),
  KEY `product_id` (`product_id`),
  KEY `product_variant_id` (`product_variant_id`),
  KEY `ix_productbatch_batch_number` (`batch_number`),
  KEY `ix_productbatch_company_id` (`company_id`),
  KEY `ix_productbatch_branch_id` (`branch_id`),
  CONSTRAINT `productbatch_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `productbatch_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `productbatch_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `productbatch_ibfk_4` FOREIGN KEY (`product_variant_id`) REFERENCES `productvariant` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productbatch`
--

LOCK TABLES `productbatch` WRITE;
/*!40000 ALTER TABLE `productbatch` DISABLE KEYS */;
INSERT INTO `productbatch` VALUES (1,'LOTE-VIEJO','2026-02-03 15:52:47',50.0000,9,NULL,1,1),(2,'LOTE-NUEVO','2027-02-02 15:52:47',100.0000,9,NULL,1,1),(3,'LOTE-VIEJO','2026-02-03 17:20:40',50.0000,13,NULL,3,4),(4,'LOTE-NUEVO','2027-02-02 17:20:40',100.0000,13,NULL,3,4),(5,'09/2023','2027-08-20 00:00:00',23.0000,18,NULL,1,2);
/*!40000 ALTER TABLE `productbatch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productkit`
--

DROP TABLE IF EXISTS `productkit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productkit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `kit_product_id` int NOT NULL,
  `component_product_id` int NOT NULL,
  `quantity` decimal(10,4) DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_productkit_company_branch_component` (`company_id`,`branch_id`,`kit_product_id`,`component_product_id`),
  KEY `ix_productkit_kit_product_id` (`kit_product_id`),
  KEY `ix_productkit_component_product_id` (`component_product_id`),
  KEY `ix_productkit_company_id` (`company_id`),
  KEY `ix_productkit_branch_id` (`branch_id`),
  CONSTRAINT `productkit_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `productkit_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `productkit_ibfk_3` FOREIGN KEY (`kit_product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `productkit_ibfk_4` FOREIGN KEY (`component_product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productkit`
--

LOCK TABLES `productkit` WRITE;
/*!40000 ALTER TABLE `productkit` DISABLE KEYS */;
/*!40000 ALTER TABLE `productkit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `productvariant`
--

DROP TABLE IF EXISTS `productvariant`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `productvariant` (
  `id` int NOT NULL AUTO_INCREMENT,
  `product_id` int NOT NULL,
  `sku` varchar(255) NOT NULL,
  `size` varchar(255) DEFAULT NULL,
  `color` varchar(255) DEFAULT NULL,
  `stock` decimal(10,4) DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_productvariant_company_branch_sku` (`company_id`,`branch_id`,`sku`),
  KEY `ix_productvariant_product_id` (`product_id`),
  KEY `ix_productvariant_sku` (`sku`),
  KEY `ix_productvariant_company_id` (`company_id`),
  KEY `ix_productvariant_branch_id` (`branch_id`),
  CONSTRAINT `productvariant_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `productvariant_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `productvariant_ibfk_3` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=26 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `productvariant`
--

LOCK TABLES `productvariant` WRITE;
/*!40000 ALTER TABLE `productvariant` DISABLE KEYS */;
INSERT INTO `productvariant` VALUES (1,8,'POLO-S','S','Azul',10.0000,1,1),(2,8,'POLO-M','M','Azul',15.0000,1,1),(14,15,'7792170110551','39','Negro',10.0000,3,4),(15,15,'7798420160116','40','Negro',5.0000,3,4),(18,12,'POLO-S','S','Azul',10.0000,3,4),(19,12,'POLO-M','M','Azul',15.0000,3,4),(20,17,'7790580602000','39','AZUL',24.0000,3,4),(21,17,'7791720033630','40','AZUL',24.0000,3,4),(22,19,'7791720033630','39','Azul',24.0000,1,2),(23,19,'7790580602000','40','Verde',23.0000,1,2),(24,20,'7798420160116','39','Naranja',27.0000,1,2),(25,20,'7798033337257','40','Marron',23.0000,1,2);
/*!40000 ALTER TABLE `productvariant` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchase`
--

DROP TABLE IF EXISTS `purchase`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchase` (
  `id` int NOT NULL AUTO_INCREMENT,
  `doc_type` varchar(255) NOT NULL,
  `series` varchar(255) NOT NULL,
  `number` varchar(255) NOT NULL,
  `issue_date` datetime NOT NULL,
  `total_amount` decimal(10,2) DEFAULT NULL,
  `currency_code` varchar(255) NOT NULL,
  `notes` varchar(255) NOT NULL,
  `supplier_id` int NOT NULL,
  `user_id` int DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_purchase_company_branch_supplier_doc` (`company_id`,`branch_id`,`supplier_id`,`doc_type`,`series`,`number`),
  KEY `user_id` (`user_id`),
  KEY `ix_purchase_doc_type` (`doc_type`),
  KEY `ix_purchase_series` (`series`),
  KEY `ix_purchase_number` (`number`),
  KEY `ix_purchase_supplier_id` (`supplier_id`),
  KEY `ix_purchase_currency_code` (`currency_code`),
  KEY `ix_purchase_branch_id` (`branch_id`),
  KEY `ix_purchase_company_id` (`company_id`),
  CONSTRAINT `purchase_ibfk_1` FOREIGN KEY (`supplier_id`) REFERENCES `supplier` (`id`),
  CONSTRAINT `purchase_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `purchase_ibfk_3` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `purchase_ibfk_4` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchase`
--

LOCK TABLES `purchase` WRITE;
/*!40000 ALTER TABLE `purchase` DISABLE KEYS */;
INSERT INTO `purchase` VALUES (2,'boleta','B001','B0002','2026-01-26 00:00:00',42.00,'PEN','',1,1,'2026-01-26 08:20:16',1,2),(3,'boleta','B002','B00003','2026-01-26 00:00:00',19.20,'PEN','',1,1,'2026-01-26 08:21:13',1,2),(5,'boleta','B001','0000001','2026-01-31 00:00:00',42.00,'PEN','',2,1,'2026-01-31 15:54:19',1,3),(6,'factura','F001','000003','2026-01-31 00:00:00',32.40,'PEN','',1,1,'2026-02-02 02:19:37',1,2),(7,'boleta','002','B000053','2026-02-02 00:00:00',3.00,'PEN','',1,1,'2026-02-02 19:17:21',1,2),(8,'boleta','B002','00003','2026-02-02 00:00:00',6.00,'PEN','',1,1,'2026-02-02 19:37:58',1,2),(9,'boleta','F001','000023','2026-02-03 00:00:00',7500.00,'PEN','',3,11,'2026-02-03 04:44:24',3,4),(10,'boleta','F001','00023','2026-02-03 00:00:00',36.00,'PEN','',1,1,'2026-02-03 12:03:45',1,2),(11,'boleta','F001','000034','2026-02-03 00:00:00',11500.00,'PEN','',1,1,'2026-02-03 12:09:53',1,2),(12,'boleta','B001','00023','2026-02-03 00:00:00',100000.00,'PEN','',1,1,'2026-02-03 18:13:04',1,2),(13,'boleta','B001','000456','2026-02-05 00:00:00',230.00,'PEN','',1,1,'2026-02-05 03:11:58',1,2),(14,'boleta','F001','00025','2026-02-06 00:00:00',110.00,'PEN','',1,1,'2026-02-06 15:32:24',1,2),(15,'factura','F001','00027','2026-02-06 00:00:00',220.00,'PEN','',1,1,'2026-02-06 18:27:28',1,2),(16,'boleta','F001','00024','2026-02-06 00:00:00',330.00,'PEN','',1,1,'2026-02-06 19:17:55',1,2),(17,'boleta','F001','00030','2026-02-07 00:00:00',220.00,'PEN','',1,1,'2026-02-07 15:09:03',1,2);
/*!40000 ALTER TABLE `purchase` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `purchaseitem`
--

DROP TABLE IF EXISTS `purchaseitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `purchaseitem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `purchase_id` int NOT NULL,
  `product_id` int DEFAULT NULL,
  `description_snapshot` varchar(255) NOT NULL,
  `barcode_snapshot` varchar(255) NOT NULL,
  `category_snapshot` varchar(255) NOT NULL,
  `quantity` decimal(10,4) DEFAULT NULL,
  `unit` varchar(255) NOT NULL,
  `unit_cost` decimal(10,2) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_purchaseitem_purchase_id` (`purchase_id`),
  KEY `ix_purchaseitem_product_id` (`product_id`),
  KEY `ix_purchaseitem_branch_id` (`branch_id`),
  KEY `ix_purchaseitem_company_id` (`company_id`),
  CONSTRAINT `purchaseitem_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `purchaseitem_ibfk_2` FOREIGN KEY (`purchase_id`) REFERENCES `purchase` (`id`),
  CONSTRAINT `purchaseitem_ibfk_3` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `purchaseitem_ibfk_4` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `purchaseitem`
--

LOCK TABLES `purchaseitem` WRITE;
/*!40000 ALTER TABLE `purchaseitem` DISABLE KEYS */;
INSERT INTO `purchaseitem` VALUES (2,2,1,'Coca Cola','7791720003862','Bebidas',5.0000,'Unidad',1.70,8.50,1,2),(3,2,2,'Gatorade 1.5l','7790895011221','Bebidas',5.0000,'Unidad',3.50,17.50,1,2),(4,2,4,'Agua mineral 1.5L','7798113301611','Bebidas',5.0000,'Unidad',3.20,16.00,1,2),(5,3,4,'Agua mineral 1.5L','7798113301611','Bebidas',6.0000,'Unidad',3.20,19.20,1,2),(7,5,6,'COCA COLA 5ML','111222333444555','BEBIDAS',12.0000,'unidad',3.50,42.00,1,3),(8,6,7,'Leche evaporada','111222333444555','Lacteos',12.0000,'unidad',2.70,32.40,1,2),(9,7,2,'Gatorade 1.25L','7790895011221','Bebidas',1.0000,'unidad',3.00,3.00,1,2),(10,8,16,'Gatorade 1.25ml','7792170110551','Bebidas',2.0000,'unidad',3.00,6.00,1,2),(11,9,17,'Zapatillas Deportivas Futbol','7790895650833','Zapatillas Futbol',50.0000,'Unidad',150.00,7500.00,3,4),(12,10,18,'Paracetamol 500mg','7790895650833','Medicina',24.0000,'unidad',1.50,36.00,1,2),(13,11,19,'Zapatillas de Futbol','123654789456','Zapatillas de Futbol',50.0000,'Unidad',120.00,6000.00,1,2),(14,11,20,'Zapatillas Runner','123654789654','Zapatillas Runner',50.0000,'Unidad',110.00,5500.00,1,2),(15,12,21,'Pañuelitos','7790250000358','Medicina',20.0000,'unidad',5000.00,100000.00,1,2),(16,13,19,'Zapatillas de Futbol (39 Azul (7791720033630))','7791720033630','Zapatillas de Futbol',1.0000,'Unidad',120.00,120.00,1,2),(17,13,20,'Zapatillas Runner (39 Naranja (7798420160116))','7798420160116','Zapatillas Runner',1.0000,'Unidad',110.00,110.00,1,2),(18,14,20,'Zapatillas Runner (39 Naranja (7798420160116))','7798420160116','Zapatillas Runner',1.0000,'Unidad',110.00,110.00,1,2),(19,15,20,'Zapatillas Runner (39 Naranja (7798420160116))','7798420160116','Zapatillas Runner',2.0000,'Unidad',110.00,220.00,1,2),(20,16,20,'Zapatillas Runner (39 Naranja (7798420160116))','7798420160116','Zapatillas Runner',3.0000,'unidad',110.00,330.00,1,2),(21,17,20,'Zapatillas Runner (39 Naranja (7798420160116))','7798420160116','Zapatillas Runner',2.0000,'Unidad',110.00,220.00,1,2);
/*!40000 ALTER TABLE `purchaseitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) NOT NULL,
  `company_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_role_company_name` (`company_id`,`name`),
  KEY `ix_role_company_id` (`company_id`),
  KEY `ix_role_name` (`name`),
  CONSTRAINT `fk_role_company_id` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=60 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (6,'Superadmin','',1),(7,'Administrador','',2),(8,'Administrador','',3),(9,'Administrador','',4),(10,'Administrador','',5),(11,'Cajero','',1),(12,'Supervisor','',1),(13,'Superadmin','',11),(14,'Administrador','',11),(15,'Usuario','',11),(16,'Cajero','',11),(17,'Superadmin','',12),(18,'Administrador','',12),(19,'Usuario','',12),(20,'Cajero','',12),(21,'SMOKE_ROLE_20260208212125','',11),(22,'Superadmin','',13),(23,'Administrador','',13),(24,'Usuario','',13),(25,'Cajero','',13),(26,'Superadmin','',14),(27,'Administrador','',14),(28,'Usuario','',14),(29,'Cajero','',14),(30,'SMOKE_ROLE_20260208212311','',13),(31,'Superadmin','',15),(32,'Administrador','',15),(33,'Usuario','',15),(34,'Cajero','',15),(35,'Superadmin','',16),(36,'Administrador','',16),(37,'Usuario','',16),(38,'Cajero','',16),(39,'SMOKE_ROLE_20260208212332','',15),(40,'Superadmin','',17),(41,'Administrador','',17),(42,'Usuario','',17),(43,'Cajero','',17),(44,'Superadmin','',18),(45,'Administrador','',18),(46,'Usuario','',18),(47,'Cajero','',18),(48,'SMOKE_ROLE_20260208212351','',17),(49,'Superadmin','',19),(50,'Administrador','',19),(51,'Usuario','',19),(52,'Cajero','',19),(53,'Superadmin','',20),(54,'Administrador','',20),(55,'Usuario','',20),(56,'Cajero','',20),(57,'SMOKE_ROLE_20260208212537','',19),(58,'Administrador','',1),(59,'Usuario','',1);
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rolepermission`
--

DROP TABLE IF EXISTS `rolepermission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `rolepermission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `permission_id` (`permission_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `rolepermission_ibfk_1` FOREIGN KEY (`permission_id`) REFERENCES `permission` (`id`),
  CONSTRAINT `rolepermission_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=984 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rolepermission`
--

LOCK TABLES `rolepermission` WRITE;
/*!40000 ALTER TABLE `rolepermission` DISABLE KEYS */;
INSERT INTO `rolepermission` VALUES (77,6,2),(78,6,14),(79,6,9),(80,6,6),(81,6,8),(82,6,15),(83,6,10),(84,6,3),(85,6,1),(86,6,7),(87,6,11),(88,6,4),(89,6,5),(90,6,12),(91,6,13),(92,7,2),(93,7,14),(94,7,9),(95,7,6),(96,7,8),(97,7,15),(98,7,10),(99,7,3),(100,7,1),(101,7,7),(102,7,11),(103,7,4),(104,7,5),(105,7,12),(106,7,13),(107,7,1550),(108,7,17),(109,7,18),(110,7,16),(111,7,1551),(112,7,19),(113,8,2),(114,8,14),(115,8,9),(116,8,6),(117,8,8),(118,8,15),(119,8,10),(120,8,3),(121,8,1),(122,8,7),(123,8,11),(124,8,4),(125,8,5),(126,8,12),(127,8,13),(128,8,1550),(129,8,17),(130,8,18),(131,8,16),(132,8,1551),(133,8,19),(134,9,2),(135,9,14),(136,9,9),(137,9,6),(138,9,8),(139,9,15),(140,9,10),(141,9,3),(142,9,1),(143,9,7),(144,9,11),(145,9,4),(146,9,5),(147,9,12),(148,9,13),(149,9,1550),(150,9,17),(151,9,18),(152,9,16),(153,9,1551),(154,9,19),(155,10,2),(156,10,14),(157,10,9),(158,10,6),(159,10,8),(160,10,15),(161,10,10),(162,10,3),(163,10,1),(164,10,7),(165,10,11),(166,10,4),(167,10,5),(168,10,12),(169,10,13),(170,10,1550),(171,10,17),(172,10,18),(173,10,16),(174,10,1551),(175,10,19),(176,11,9),(177,11,10),(178,11,3),(179,11,4),(180,11,11),(181,12,7),(182,12,9),(183,12,6),(184,12,10),(185,12,13),(186,12,4),(187,12,1),(188,12,2),(189,12,3),(190,12,5),(191,12,14),(192,13,10),(193,13,11),(194,13,12),(195,13,13),(196,13,14),(197,13,15),(198,13,16),(199,13,17),(200,13,18),(201,13,19),(202,13,1550),(203,13,1551),(204,13,1),(205,13,2),(206,13,3),(207,13,4),(208,13,5),(209,13,6),(210,13,7),(211,13,8),(212,13,9),(213,14,10),(214,14,11),(215,14,12),(216,14,13),(217,14,14),(218,14,15),(219,14,16),(220,14,17),(221,14,18),(222,14,19),(223,14,1550),(224,14,1551),(225,14,1),(226,14,2),(227,14,3),(228,14,4),(229,14,5),(230,14,6),(231,14,7),(232,14,8),(233,14,9),(234,15,10),(235,15,1551),(236,15,5),(237,15,16),(238,15,6),(239,15,1),(240,15,17),(241,15,1550),(242,15,7),(243,15,2),(244,15,18),(245,15,13),(246,15,3),(247,15,14),(248,15,9),(249,15,4),(250,16,10),(251,16,5),(252,16,16),(253,16,17),(254,16,3),(255,16,9),(256,16,4),(257,17,1),(258,17,1550),(259,17,1551),(260,17,15),(261,17,13),(262,17,14),(263,17,8),(264,17,10),(265,17,12),(266,17,6),(267,17,16),(268,17,5),(269,17,9),(270,17,7),(271,17,17),(272,17,11),(273,17,4),(274,17,18),(275,17,3),(276,17,19),(277,17,2),(278,18,1),(279,18,1550),(280,18,1551),(281,18,15),(282,18,13),(283,18,14),(284,18,8),(285,18,10),(286,18,6),(287,18,12),(288,18,16),(289,18,5),(290,18,9),(291,18,7),(292,18,17),(293,18,11),(294,18,4),(295,18,18),(296,18,3),(297,18,19),(298,18,2),(299,19,1550),(300,19,17),(301,19,2),(302,19,10),(303,19,1551),(304,19,1),(305,19,4),(306,19,6),(307,19,18),(308,19,16),(309,19,3),(310,19,5),(311,19,13),(312,19,9),(313,19,14),(314,19,7),(315,20,17),(316,20,10),(317,20,4),(318,20,16),(319,20,3),(320,20,5),(321,20,9),(322,21,16),(323,21,17),(324,21,18),(325,21,19),(326,21,1550),(327,21,15),(328,21,14),(329,21,1551),(330,21,1),(331,21,2),(332,21,3),(333,21,4),(334,21,5),(335,21,6),(336,21,7),(337,21,8),(338,21,9),(339,21,10),(340,21,11),(341,21,12),(342,21,13),(343,22,9),(344,22,10),(345,22,11),(346,22,12),(347,22,13),(348,22,14),(349,22,15),(350,22,16),(351,22,17),(352,22,18),(353,22,19),(354,22,1550),(355,22,1551),(356,22,1),(357,22,2),(358,22,3),(359,22,4),(360,22,5),(361,22,6),(362,22,7),(363,22,8),(364,23,9),(365,23,10),(366,23,11),(367,23,12),(368,23,13),(369,23,14),(370,23,15),(371,23,16),(372,23,17),(373,23,18),(374,23,19),(375,23,1550),(376,23,1551),(377,23,1),(378,23,2),(379,23,3),(380,23,4),(381,23,5),(382,23,6),(383,23,7),(384,23,8),(385,24,14),(386,24,9),(387,24,1550),(388,24,4),(389,24,10),(390,24,1551),(391,24,5),(392,24,16),(393,24,18),(394,24,6),(395,24,1),(396,24,17),(397,24,7),(398,24,2),(399,24,13),(400,24,3),(401,25,9),(402,25,4),(403,25,10),(404,25,5),(405,25,16),(406,25,17),(407,25,3),(408,26,1551),(409,26,1),(410,26,19),(411,26,1550),(412,26,15),(413,26,13),(414,26,14),(415,26,8),(416,26,6),(417,26,10),(418,26,12),(419,26,5),(420,26,16),(421,26,9),(422,26,7),(423,26,17),(424,26,4),(425,26,11),(426,26,3),(427,26,18),(428,26,2),(429,27,1551),(430,27,1),(431,27,19),(432,27,1550),(433,27,15),(434,27,13),(435,27,14),(436,27,8),(437,27,10),(438,27,6),(439,27,5),(440,27,12),(441,27,16),(442,27,9),(443,27,7),(444,27,17),(445,27,4),(446,27,11),(447,27,3),(448,27,18),(449,27,2),(450,28,13),(451,28,2),(452,28,9),(453,28,1551),(454,28,14),(455,28,7),(456,28,1550),(457,28,1),(458,28,17),(459,28,4),(460,28,10),(461,28,6),(462,28,3),(463,28,5),(464,28,18),(465,28,16),(466,29,9),(467,29,17),(468,29,4),(469,29,10),(470,29,3),(471,29,5),(472,29,16),(473,30,12),(474,30,13),(475,30,14),(476,30,15),(477,30,16),(478,30,17),(479,30,18),(480,30,19),(481,30,1550),(482,30,11),(483,30,10),(484,30,1551),(485,30,1),(486,30,2),(487,30,3),(488,30,4),(489,30,5),(490,30,6),(491,30,7),(492,30,8),(493,30,9),(494,31,7),(495,31,8),(496,31,9),(497,31,10),(498,31,11),(499,31,12),(500,31,13),(501,31,14),(502,31,15),(503,31,16),(504,31,17),(505,31,18),(506,31,19),(507,31,1550),(508,31,1551),(509,31,1),(510,31,2),(511,31,3),(512,31,4),(513,31,5),(514,31,6),(515,32,7),(516,32,8),(517,32,9),(518,32,10),(519,32,11),(520,32,12),(521,32,13),(522,32,14),(523,32,15),(524,32,16),(525,32,17),(526,32,18),(527,32,19),(528,32,1550),(529,32,1551),(530,32,1),(531,32,2),(532,32,3),(533,32,4),(534,32,5),(535,32,6),(536,33,7),(537,33,5),(538,33,18),(539,33,2),(540,33,13),(541,33,3),(542,33,14),(543,33,17),(544,33,9),(545,33,1550),(546,33,4),(547,33,10),(548,33,1551),(549,33,16),(550,33,6),(551,33,1),(552,34,3),(553,34,9),(554,34,4),(555,34,10),(556,34,5),(557,34,16),(558,34,17),(559,35,4),(560,35,1550),(561,35,3),(562,35,1551),(563,35,19),(564,35,2),(565,35,1),(566,35,18),(567,35,15),(568,35,13),(569,35,14),(570,35,9),(571,35,12),(572,35,7),(573,35,16),(574,35,6),(575,35,10),(576,35,8),(577,35,17),(578,35,11),(579,35,5),(580,36,4),(581,36,1550),(582,36,3),(583,36,1551),(584,36,19),(585,36,2),(586,36,1),(587,36,18),(588,36,15),(589,36,13),(590,36,14),(591,36,9),(592,36,7),(593,36,12),(594,36,16),(595,36,6),(596,36,10),(597,36,8),(598,36,17),(599,36,11),(600,36,5),(601,37,1),(602,37,4),(603,37,16),(604,37,18),(605,37,1550),(606,37,6),(607,37,3),(608,37,10),(609,37,1551),(610,37,13),(611,37,14),(612,37,17),(613,37,9),(614,37,2),(615,37,5),(616,37,7),(617,38,4),(618,38,16),(619,38,3),(620,38,10),(621,38,17),(622,38,9),(623,38,5),(624,39,12),(625,39,13),(626,39,14),(627,39,15),(628,39,16),(629,39,17),(630,39,18),(631,39,19),(632,39,1550),(633,39,11),(634,39,10),(635,39,1551),(636,39,1),(637,39,2),(638,39,3),(639,39,4),(640,39,5),(641,39,6),(642,39,7),(643,39,8),(644,39,9),(645,40,3),(646,40,4),(647,40,5),(648,40,6),(649,40,7),(650,40,8),(651,40,9),(652,40,10),(653,40,11),(654,40,12),(655,40,13),(656,40,14),(657,40,15),(658,40,16),(659,40,17),(660,40,18),(661,40,19),(662,40,1550),(663,40,1551),(664,40,1),(665,40,2),(666,41,3),(667,41,4),(668,41,5),(669,41,6),(670,41,7),(671,41,8),(672,41,9),(673,41,10),(674,41,11),(675,41,12),(676,41,13),(677,41,14),(678,41,15),(679,41,16),(680,41,17),(681,41,18),(682,41,19),(683,41,1550),(684,41,1551),(685,41,1),(686,41,2),(687,42,2),(688,42,3),(689,42,1),(690,42,14),(691,42,9),(692,42,4),(693,42,1550),(694,42,10),(695,42,5),(696,42,1551),(697,42,16),(698,42,6),(699,42,17),(700,42,7),(701,42,18),(702,42,13),(703,43,3),(704,43,9),(705,43,4),(706,43,10),(707,43,5),(708,43,16),(709,43,17),(710,44,16),(711,44,17),(712,44,18),(713,44,4),(714,44,19),(715,44,3),(716,44,1550),(717,44,2),(718,44,1551),(719,44,9),(720,44,1),(721,44,14),(722,44,15),(723,44,12),(724,44,10),(725,44,11),(726,44,7),(727,44,8),(728,44,6),(729,44,13),(730,44,5),(731,45,16),(732,45,17),(733,45,18),(734,45,4),(735,45,19),(736,45,3),(737,45,1550),(738,45,2),(739,45,1551),(740,45,9),(741,45,1),(742,45,14),(743,45,15),(744,45,12),(745,45,10),(746,45,11),(747,45,7),(748,45,8),(749,45,6),(750,45,13),(751,45,5),(752,46,2),(753,46,5),(754,46,1551),(755,46,16),(756,46,13),(757,46,14),(758,46,17),(759,46,7),(760,46,9),(761,46,18),(762,46,1),(763,46,4),(764,46,6),(765,46,3),(766,46,1550),(767,46,10),(768,47,16),(769,47,17),(770,47,4),(771,47,9),(772,47,3),(773,47,5),(774,47,10),(775,48,10),(776,48,11),(777,48,12),(778,48,13),(779,48,14),(780,48,15),(781,48,16),(782,48,17),(783,48,18),(784,48,19),(785,48,9),(786,48,8),(787,48,1550),(788,48,7),(789,48,1551),(790,48,1),(791,48,2),(792,48,3),(793,48,4),(794,48,5),(795,48,6),(796,49,5),(797,49,6),(798,49,7),(799,49,8),(800,49,9),(801,49,10),(802,49,11),(803,49,12),(804,49,13),(805,49,14),(806,49,15),(807,49,16),(808,49,17),(809,49,18),(810,49,19),(811,49,1550),(812,49,1551),(813,49,1),(814,49,2),(815,49,3),(816,49,4),(817,50,5),(818,50,6),(819,50,7),(820,50,8),(821,50,9),(822,50,10),(823,50,11),(824,50,12),(825,50,13),(826,50,14),(827,50,15),(828,50,16),(829,50,17),(830,50,18),(831,50,19),(832,50,1550),(833,50,1551),(834,50,1),(835,50,2),(836,50,3),(837,50,4),(838,51,10),(839,51,4),(840,51,5),(841,51,1551),(842,51,16),(843,51,6),(844,51,17),(845,51,1),(846,51,7),(847,51,18),(848,51,2),(849,51,13),(850,51,3),(851,51,14),(852,51,9),(853,51,1550),(854,52,10),(855,52,5),(856,52,16),(857,52,17),(858,52,3),(859,52,9),(860,52,4),(861,53,17),(862,53,4),(863,53,18),(864,53,3),(865,53,19),(866,53,2),(867,53,1550),(868,53,1551),(869,53,1),(870,53,15),(871,53,16),(872,53,13),(873,53,11),(874,53,12),(875,53,8),(876,53,6),(877,53,9),(878,53,5),(879,53,10),(880,53,14),(881,53,7),(882,54,17),(883,54,4),(884,54,18),(885,54,3),(886,54,19),(887,54,2),(888,54,1550),(889,54,1551),(890,54,1),(891,54,15),(892,54,16),(893,54,13),(894,54,11),(895,54,12),(896,54,8),(897,54,9),(898,54,6),(899,54,10),(900,54,5),(901,54,14),(902,54,7),(903,55,16),(904,55,17),(905,55,1),(906,55,4),(907,55,18),(908,55,9),(909,55,6),(910,55,3),(911,55,10),(912,55,5),(913,55,13),(914,55,2),(915,55,14),(916,55,1550),(917,55,7),(918,55,1551),(919,56,16),(920,56,17),(921,56,4),(922,56,9),(923,56,3),(924,56,10),(925,56,5),(926,57,10),(927,57,11),(928,57,12),(929,57,13),(930,57,14),(931,57,15),(932,57,16),(933,57,17),(934,57,18),(935,57,19),(936,57,9),(937,57,1550),(938,57,8),(939,57,1551),(940,57,1),(941,57,2),(942,57,3),(943,57,4),(944,57,5),(945,57,6),(946,57,7),(947,58,10),(948,58,11),(949,58,4),(950,58,5),(951,58,15),(952,58,12),(953,58,17),(954,58,13),(955,58,18),(956,58,19),(957,58,1550),(958,58,1),(959,58,1551),(960,58,2),(961,58,9),(962,58,6),(963,58,3),(964,58,8),(965,58,7),(966,58,14),(967,58,16),(968,59,1550),(969,59,7),(970,59,10),(971,59,1),(972,59,3),(973,59,4),(974,59,5),(975,59,1551),(976,59,14),(977,59,2),(978,59,17),(979,59,9),(980,59,13),(981,59,16),(982,59,18),(983,59,6);
/*!40000 ALTER TABLE `rolepermission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `sale`
--

DROP TABLE IF EXISTS `sale`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `sale` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timestamp` datetime DEFAULT (now()),
  `total_amount` decimal(10,2) DEFAULT NULL,
  `status` enum('pending','completed','cancelled') NOT NULL,
  `delete_reason` varchar(255) DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `payment_condition` varchar(255) NOT NULL,
  `client_id` int DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `user_id` (`user_id`),
  KEY `ix_sale_client_id` (`client_id`),
  KEY `ix_sale_timestamp` (`timestamp`),
  KEY `ix_sale_company_id` (`company_id`),
  KEY `ix_sale_branch_id` (`branch_id`),
  KEY `ix_sale_company_branch_timestamp` (`company_id`,`branch_id`,`timestamp`),
  CONSTRAINT `fk_sale_company_id` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `sale_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `sale_ibfk_2` FOREIGN KEY (`client_id`) REFERENCES `client` (`id`),
  CONSTRAINT `sale_ibfk_3` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=296 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sale`
--

LOCK TABLES `sale` WRITE;
/*!40000 ALTER TABLE `sale` DISABLE KEYS */;
INSERT INTO `sale` VALUES (1,'2026-01-02 01:10:25',20.00,'completed',NULL,1,'',NULL,1,2),(2,'2026-01-02 01:14:17',32.70,'completed',NULL,1,'',NULL,1,2),(3,'2026-01-02 01:30:15',20.00,'completed',NULL,1,'',NULL,1,2),(4,'2026-01-02 01:30:28',30.00,'completed',NULL,1,'',NULL,1,2),(5,'2026-01-02 01:30:53',2.70,'completed',NULL,1,'',NULL,1,2),(6,'2026-01-02 13:51:15',20.00,'completed',NULL,1,'',NULL,1,2),(7,'2026-01-02 13:51:47',32.70,'completed',NULL,1,'',NULL,1,2),(8,'2026-01-02 15:47:22',20.00,'completed',NULL,1,'',NULL,1,2),(9,'2026-01-02 15:47:57',32.70,'completed',NULL,1,'',NULL,1,2),(10,'2026-01-02 16:41:41',20.00,'completed',NULL,1,'',NULL,1,2),(11,'2026-01-02 16:52:48',52.70,'completed',NULL,1,'',NULL,1,2),(12,'2026-01-02 16:53:49',20.00,'completed',NULL,1,'',NULL,1,2),(13,'2026-01-02 16:54:08',52.70,'completed',NULL,1,'',NULL,1,2),(14,'2026-01-03 19:37:56',20.00,'completed',NULL,1,'contado',NULL,1,2),(15,'2026-01-03 20:13:28',38.40,'completed',NULL,1,'credito',1,1,2),(16,'2026-01-03 20:44:50',20.00,'completed',NULL,1,'contado',NULL,1,2),(17,'2026-01-03 20:46:42',58.40,'completed',NULL,1,'credito',3,1,2),(18,'2026-01-03 20:47:52',20.00,'completed',NULL,1,'contado',NULL,1,2),(19,'2026-01-03 20:49:02',58.40,'completed',NULL,1,'credito',2,1,2),(20,'2026-01-03 22:15:46',2.70,'completed',NULL,1,'contado',NULL,1,2),(21,'2026-01-03 22:16:27',20.00,'completed',NULL,1,'contado',NULL,1,2),(22,'2026-01-03 22:17:14',35.70,'completed',NULL,1,'contado',NULL,1,2),(23,'2026-01-03 22:19:25',20.00,'completed',NULL,1,'contado',NULL,1,2),(24,'2026-01-03 22:20:40',35.70,'completed',NULL,1,'contado',NULL,1,2),(25,'2026-01-03 22:25:02',20.00,'completed',NULL,1,'contado',NULL,1,2),(26,'2026-01-03 22:25:28',55.70,'completed',NULL,1,'contado',NULL,1,2),(27,'2026-01-04 00:03:35',20.00,'completed',NULL,1,'contado',NULL,1,2),(28,'2026-01-04 00:04:24',58.40,'completed',NULL,1,'contado',NULL,1,2),(29,'2026-01-04 00:06:46',20.00,'completed',NULL,1,'contado',NULL,1,2),(30,'2026-01-04 00:08:11',20.00,'completed',NULL,1,'contado',NULL,1,2),(31,'2026-01-04 00:12:17',30.00,'completed',NULL,1,'credito',1,1,2),(32,'2026-01-04 00:14:51',50.00,'completed',NULL,1,'credito',1,1,2),(33,'2026-01-04 00:59:57',20.00,'completed',NULL,1,'contado',NULL,1,2),(34,'2026-01-04 01:00:50',55.70,'completed',NULL,1,'credito',1,1,2),(35,'2026-01-04 03:04:39',5.70,'completed',NULL,1,'contado',NULL,1,2),(36,'2026-01-04 03:08:37',20.00,'completed',NULL,1,'contado',NULL,1,2),(37,'2026-01-04 03:09:59',52.70,'completed',NULL,1,'contado',NULL,1,2),(38,'2026-01-04 03:12:48',20.00,'completed',NULL,1,'contado',NULL,1,2),(39,'2026-01-04 03:13:41',58.40,'completed',NULL,1,'contado',NULL,1,2),(40,'2026-01-04 03:15:54',20.00,'completed',NULL,1,'contado',NULL,1,2),(41,'2026-01-04 03:18:25',58.40,'completed',NULL,1,'credito',1,1,2),(42,'2026-01-04 03:59:05',20.00,'completed',NULL,1,'contado',NULL,1,2),(43,'2026-01-04 04:01:07',58.40,'completed',NULL,1,'credito',2,1,2),(44,'2026-01-04 04:05:39',20.00,'completed',NULL,1,'contado',NULL,1,2),(45,'2026-01-04 04:08:31',58.40,'completed',NULL,1,'credito',3,1,2),(46,'2026-01-04 04:10:25',20.00,'completed',NULL,1,'contado',NULL,1,2),(47,'2026-01-04 05:00:14',20.00,'completed',NULL,1,'contado',NULL,1,2),(48,'2026-01-04 05:01:53',58.40,'completed',NULL,1,'credito',2,1,2),(49,'2026-01-04 05:07:45',20.00,'completed',NULL,1,'contado',NULL,1,2),(50,'2026-01-04 05:09:05',58.40,'completed',NULL,1,'credito',2,1,2),(51,'2026-01-04 07:49:42',2.70,'completed',NULL,1,'contado',NULL,1,2),(52,'2026-01-04 07:50:42',5.70,'completed',NULL,1,'contado',NULL,1,2),(53,'2026-01-04 07:51:07',5.70,'completed',NULL,1,'contado',NULL,1,2),(54,'2026-01-04 07:51:29',8.40,'completed',NULL,1,'contado',NULL,1,2),(55,'2026-01-04 07:52:02',20.00,'completed',NULL,1,'contado',NULL,1,2),(56,'2026-01-04 07:53:43',58.40,'completed',NULL,1,'contado',NULL,1,2),(57,'2026-01-04 07:56:55',58.40,'completed',NULL,1,'credito',3,1,2),(58,'2026-01-05 00:56:02',20.00,'completed',NULL,1,'contado',NULL,1,2),(59,'2026-01-05 00:58:18',55.30,'completed',NULL,1,'contado',NULL,1,2),(60,'2026-01-05 01:00:44',15.90,'completed',NULL,1,'contado',NULL,1,2),(61,'2026-01-05 02:44:52',5.30,'completed',NULL,1,'contado',NULL,1,2),(62,'2026-01-05 02:45:38',5.30,'completed',NULL,1,'contado',NULL,1,2),(63,'2026-01-07 11:24:37',20.00,'completed',NULL,1,'contado',NULL,1,2),(64,'2026-01-07 12:42:05',5.40,'completed',NULL,1,'contado',NULL,1,2),(65,'2026-01-07 12:44:55',15.60,'completed',NULL,1,'contado',NULL,1,2),(66,'2026-01-08 10:34:30',17.10,'completed',NULL,1,'contado',NULL,1,2),(67,'2026-01-08 10:37:12',20.00,'completed',NULL,1,'contado',NULL,1,2),(68,'2026-01-08 10:37:57',41.40,'completed',NULL,1,'contado',NULL,1,2),(69,'2026-01-08 10:40:48',20.00,'completed',NULL,1,'contado',NULL,1,2),(70,'2026-01-08 10:41:01',30.00,'completed',NULL,1,'contado',NULL,1,2),(71,'2026-01-08 10:41:36',30.00,'completed',NULL,1,'contado',NULL,1,2),(72,'2026-01-08 11:03:10',5.70,'completed',NULL,1,'contado',NULL,1,2),(73,'2026-01-08 11:03:39',20.00,'completed',NULL,1,'contado',NULL,1,2),(74,'2026-01-08 11:03:53',61.40,'completed',NULL,1,'contado',NULL,1,2),(75,'2026-01-08 11:04:38',20.00,'completed',NULL,1,'contado',NULL,1,2),(76,'2026-01-08 11:04:48',30.00,'completed',NULL,1,'contado',NULL,1,2),(77,'2026-01-08 11:06:07',20.00,'completed',NULL,1,'contado',NULL,1,2),(78,'2026-01-08 11:06:21',30.00,'completed',NULL,1,'contado',NULL,1,2),(79,'2026-01-08 11:08:40',5.70,'completed',NULL,1,'contado',NULL,1,2),(80,'2026-01-08 11:10:32',5.40,'completed',NULL,1,'contado',NULL,1,2),(81,'2026-01-09 16:12:50',20.00,'completed',NULL,1,'contado',NULL,1,2),(82,'2026-01-10 05:36:44',50.00,'completed',NULL,1,'credito',1,1,2),(83,'2026-01-11 20:23:54',20.00,'completed',NULL,1,'contado',NULL,1,2),(84,'2026-01-11 23:41:05',2.70,'completed',NULL,1,'contado',NULL,1,2),(85,'2026-01-11 23:47:57',55.70,'completed',NULL,1,'contado',NULL,1,2),(86,'2026-01-11 23:48:26',20.00,'completed',NULL,1,'contado',NULL,1,2),(87,'2026-01-11 23:51:47',55.70,'completed',NULL,1,'credito',2,1,2),(88,'2026-01-12 00:48:46',20.00,'completed',NULL,1,'contado',NULL,1,2),(89,'2026-01-12 00:50:03',58.40,'completed',NULL,1,'credito',1,1,2),(90,'2026-01-12 01:41:58',20.00,'completed',NULL,1,'contado',NULL,1,2),(91,'2026-01-12 01:42:52',58.40,'completed',NULL,1,'contado',NULL,1,2),(92,'2026-01-12 01:44:58',20.00,'completed',NULL,1,'contado',NULL,1,2),(93,'2026-01-12 01:45:58',50.00,'completed',NULL,1,'credito',3,1,2),(94,'2026-01-12 12:04:38',20.00,'completed',NULL,1,'contado',NULL,1,2),(95,'2026-01-12 14:39:55',5.70,'completed',NULL,1,'contado',NULL,1,2),(96,'2026-01-13 01:53:12',2.70,'completed',NULL,1,'contado',NULL,1,2),(97,'2026-01-13 01:53:27',5.70,'completed',NULL,1,'contado',NULL,1,2),(98,'2026-01-16 16:01:04',70.00,'completed',NULL,1,'contado',NULL,1,2),(99,'2026-01-16 16:01:33',55.70,'completed',NULL,1,'contado',NULL,1,2),(100,'2026-01-18 21:53:18',20.00,'completed',NULL,1,'contado',NULL,1,2),(101,'2026-01-18 21:54:16',55.70,'completed',NULL,1,'contado',NULL,1,2),(102,'2026-01-18 21:54:41',20.00,'completed',NULL,1,'contado',NULL,1,2),(103,'2026-01-18 21:54:51',30.00,'completed',NULL,1,'contado',NULL,1,2),(104,'2026-01-18 21:55:10',5.70,'completed',NULL,1,'contado',NULL,1,2),(105,'2026-01-19 10:48:05',20.00,'completed',NULL,1,'contado',NULL,1,2),(106,'2026-01-19 10:48:28',35.70,'completed',NULL,1,'contado',NULL,1,2),(107,'2026-01-19 10:48:44',2.70,'completed',NULL,1,'contado',NULL,1,2),(108,'2026-01-19 10:48:54',2.70,'completed',NULL,1,'contado',NULL,1,2),(109,'2026-01-19 10:49:18',20.00,'completed',NULL,1,'contado',NULL,1,2),(110,'2026-01-19 10:49:31',50.00,'completed',NULL,1,'contado',NULL,1,2),(111,'2026-01-19 11:56:40',20.00,'completed',NULL,1,'contado',NULL,1,2),(112,'2026-01-19 11:58:12',55.70,'completed',NULL,1,'contado',NULL,1,2),(113,'2026-01-19 12:02:29',20.00,'completed',NULL,1,'contado',NULL,1,2),(114,'2026-01-19 12:02:59',52.70,'completed',NULL,1,'contado',NULL,1,2),(115,'2026-01-20 13:23:20',20.00,'completed',NULL,1,'contado',NULL,1,2),(116,'2026-01-21 02:21:32',2.70,'completed',NULL,1,'contado',NULL,1,2),(117,'2026-01-21 06:45:50',5.70,'completed',NULL,1,'contado',NULL,1,2),(118,'2026-01-21 07:22:19',20.00,'completed',NULL,1,'contado',NULL,1,2),(119,'2026-01-21 07:23:13',20.00,'completed',NULL,1,'contado',NULL,1,2),(120,'2026-01-21 07:24:01',30.00,'completed',NULL,1,'contado',NULL,1,2),(121,'2026-01-21 07:24:23',50.00,'completed',NULL,1,'contado',NULL,1,2),(122,'2026-01-21 07:24:49',52.70,'completed',NULL,1,'contado',NULL,1,2),(123,'2026-01-21 07:30:44',70.00,'completed',NULL,1,'credito',1,1,2),(124,'2026-01-22 18:20:27',5.70,'completed',NULL,1,'contado',NULL,1,2),(125,'2026-01-23 20:47:10',2.90,'completed',NULL,1,'contado',NULL,1,2),(126,'2026-01-23 20:57:13',2.70,'completed',NULL,1,'contado',NULL,1,2),(127,'2026-01-26 11:11:46',20.00,'completed',NULL,1,'contado',NULL,1,2),(128,'2026-01-26 12:22:55',63.60,'completed',NULL,1,'contado',NULL,1,2),(129,'2026-01-27 04:18:04',20.00,'completed',NULL,1,'contado',NULL,1,2),(130,'2026-01-27 04:19:13',52.40,'completed',NULL,1,'contado',NULL,1,2),(131,'2026-01-27 20:06:58',32.70,'completed',NULL,1,'contado',NULL,1,2),(132,'2026-02-02 02:30:59',4.50,'completed',NULL,1,'contado',NULL,1,3),(133,'2026-02-02 02:35:19',20.00,'completed',NULL,1,'contado',NULL,1,3),(134,'2026-02-02 02:36:09',34.50,'completed',NULL,1,'contado',NULL,1,3),(135,'2026-02-02 03:22:02',20.00,'completed',NULL,1,'contado',NULL,1,2),(136,'2026-02-02 19:05:32',100.00,'completed',NULL,11,'contado',NULL,3,4),(137,'2026-02-03 04:47:07',400.00,'completed',NULL,11,'contado',NULL,3,4),(138,'2026-02-03 04:59:16',400.00,'completed',NULL,11,'contado',NULL,3,4),(139,'2026-02-03 05:12:13',200.00,'completed',NULL,11,'contado',NULL,3,4),(140,'2026-02-03 12:15:08',620.90,'completed',NULL,1,'contado',NULL,1,2),(141,'2026-02-03 18:16:59',35000.00,'cancelled','Venta equivocada por el monto ingresado',1,'contado',NULL,1,2),(142,'2026-02-04 20:01:01',20.00,'completed',NULL,1,'contado',NULL,1,2),(143,'2026-02-05 13:12:21',2.70,'completed',NULL,1,'contado',NULL,1,2),(144,'2026-02-05 13:22:29',2.70,'completed',NULL,1,'contado',NULL,1,2),(145,'2026-02-05 18:53:57',2.70,'completed',NULL,1,'contado',NULL,1,2),(146,'2026-02-05 19:00:44',2.70,'completed',NULL,1,'contado',NULL,1,2),(147,'2026-02-05 19:01:30',20.50,'completed',NULL,1,'contado',NULL,1,2),(148,'2026-02-05 19:03:49',650.00,'completed',NULL,1,'contado',NULL,1,2),(149,'2026-02-05 19:11:02',20.00,'completed',NULL,1,'contado',NULL,1,2),(150,'2026-02-05 19:21:57',70.50,'completed',NULL,1,'contado',NULL,1,2),(151,'2026-02-05 19:41:12',20.00,'completed',NULL,8,'contado',NULL,1,2),(152,'2026-02-06 19:21:51',150.00,'completed',NULL,1,'contado',NULL,1,2),(153,'2026-02-06 19:23:55',20.00,'completed',NULL,1,'contado',NULL,1,2),(154,'2026-02-06 19:25:13',60.00,'completed',NULL,1,'contado',NULL,1,2),(155,'2026-02-06 20:09:03',25.00,'completed',NULL,1,'contado',NULL,1,2),(156,'2026-02-06 20:12:29',20.00,'completed',NULL,1,'contado',NULL,1,2),(157,'2026-02-06 20:13:35',30.00,'completed',NULL,1,'contado',NULL,1,2),(158,'2026-02-06 20:15:11',30.00,'completed',NULL,1,'contado',NULL,1,2),(159,'2026-02-06 20:33:00',25.00,'completed',NULL,1,'contado',NULL,1,2),(160,'2026-02-07 00:36:33',150.00,'completed',NULL,1,'contado',NULL,1,2),(211,'2026-02-07 15:10:13',455.30,'completed',NULL,1,'contado',NULL,1,2),(212,'2026-02-07 15:41:23',20.00,'completed',NULL,1,'contado',NULL,1,2),(213,'2026-02-07 15:42:00',50.00,'completed',NULL,1,'contado',NULL,1,2),(214,'2026-02-07 17:14:36',4.00,'completed',NULL,1,'contado',NULL,1,2),(215,'2026-01-02 01:10:25',50.00,'completed',NULL,1,'contado',NULL,1,2),(216,'2026-01-02 01:30:15',50.00,'completed',NULL,1,'contado',NULL,1,2),(217,'2026-01-02 13:51:15',50.00,'completed',NULL,1,'contado',NULL,1,2),(218,'2026-01-02 15:47:22',50.00,'completed',NULL,1,'contado',NULL,1,2),(219,'2026-01-02 16:41:41',70.00,'completed',NULL,1,'contado',NULL,1,2),(220,'2026-01-02 16:53:49',70.00,'completed',NULL,1,'contado',NULL,1,2),(221,'2026-01-03 19:37:56',50.00,'completed',NULL,1,'contado',NULL,1,2),(222,'2026-01-03 20:44:50',70.00,'completed',NULL,1,'contado',NULL,1,2),(223,'2026-01-03 20:47:52',70.00,'completed',NULL,1,'contado',NULL,1,2),(224,'2026-01-03 22:16:27',50.00,'completed',NULL,1,'contado',NULL,1,2),(225,'2026-01-03 22:19:25',50.00,'completed',NULL,1,'contado',NULL,1,2),(226,'2026-01-03 22:25:01',70.00,'completed',NULL,1,'contado',NULL,1,2),(227,'2026-01-04 00:03:35',70.00,'completed',NULL,1,'contado',NULL,1,2),(228,'2026-01-04 00:06:46',70.00,'completed',NULL,1,'contado',NULL,1,2),(229,'2026-01-04 00:08:11',50.00,'completed',NULL,1,'contado',NULL,1,2),(230,'2026-01-04 00:59:57',70.00,'completed',NULL,1,'contado',NULL,1,2),(231,'2026-01-04 03:08:37',70.00,'completed',NULL,1,'contado',NULL,1,2),(232,'2026-01-04 03:12:48',70.00,'completed',NULL,1,'contado',NULL,1,2),(233,'2026-01-04 03:15:54',70.00,'completed',NULL,1,'contado',NULL,1,2),(234,'2026-01-04 03:59:05',70.00,'completed',NULL,1,'contado',NULL,1,2),(235,'2026-01-04 04:05:39',70.00,'completed',NULL,1,'contado',NULL,1,2),(236,'2026-01-04 04:10:25',70.00,'completed',NULL,1,'contado',NULL,1,2),(237,'2026-01-04 05:00:14',70.00,'completed',NULL,1,'contado',NULL,1,2),(238,'2026-01-04 05:07:45',70.00,'completed',NULL,1,'contado',NULL,1,2),(239,'2026-01-04 07:52:02',70.00,'completed',NULL,1,'contado',NULL,1,2),(240,'2026-01-05 00:56:02',70.00,'completed',NULL,1,'contado',NULL,1,2),(241,'2026-01-07 11:24:37',50.00,'completed',NULL,1,'contado',NULL,1,2),(242,'2026-01-08 10:37:12',50.00,'completed',NULL,1,'contado',NULL,1,2),(243,'2026-01-08 10:40:48',50.00,'completed',NULL,1,'contado',NULL,1,2),(244,'2026-01-08 11:03:39',70.00,'completed',NULL,1,'contado',NULL,1,2),(245,'2026-01-08 11:04:38',50.00,'completed',NULL,1,'contado',NULL,1,2),(246,'2026-01-08 11:06:07',50.00,'completed',NULL,1,'contado',NULL,1,2),(247,'2026-01-09 16:12:50',70.00,'completed',NULL,1,'contado',NULL,1,2),(248,'2026-01-11 20:23:46',70.00,'completed',NULL,1,'contado',NULL,1,2),(249,'2026-01-11 23:48:26',70.00,'completed',NULL,1,'contado',NULL,1,2),(250,'2026-01-12 00:48:46',70.00,'completed',NULL,1,'contado',NULL,1,2),(251,'2026-01-12 01:41:58',70.00,'completed',NULL,1,'contado',NULL,1,2),(252,'2026-01-12 01:44:58',70.00,'completed',NULL,1,'contado',NULL,1,2),(253,'2026-01-12 11:59:52',70.00,'completed',NULL,1,'contado',NULL,1,2),(254,'2026-01-12 12:04:38',70.00,'completed',NULL,1,'contado',NULL,1,2),(255,'2026-01-18 21:53:18',70.00,'completed',NULL,1,'contado',NULL,1,2),(256,'2026-01-18 21:54:41',50.00,'completed',NULL,1,'contado',NULL,1,2),(257,'2026-01-19 10:48:05',50.00,'completed',NULL,1,'contado',NULL,1,2),(258,'2026-01-19 10:49:18',70.00,'completed',NULL,1,'contado',NULL,1,2),(259,'2026-01-19 11:56:40',70.00,'completed',NULL,1,'contado',NULL,1,2),(260,'2026-01-19 12:02:29',70.00,'completed',NULL,1,'contado',NULL,1,2),(261,'2026-01-20 13:23:20',70.00,'completed',NULL,1,'contado',NULL,1,2),(262,'2026-01-21 07:22:19',50.00,'completed',NULL,1,'contado',NULL,1,2),(263,'2026-01-21 07:23:13',70.00,'completed',NULL,1,'contado',NULL,1,2),(264,'2026-01-21 07:29:36',70.00,'completed',NULL,1,'contado',NULL,1,2),(265,'2026-01-26 11:11:46',70.00,'completed',NULL,1,'contado',NULL,1,2),(266,'2026-01-27 04:18:04',50.00,'completed',NULL,1,'contado',NULL,1,2),(267,'2026-01-27 20:05:44',50.00,'completed',NULL,1,'contado',NULL,1,2),(268,'2026-02-02 02:35:19',50.00,'completed',NULL,1,'contado',NULL,1,3),(269,'2026-02-02 03:22:02',50.00,'completed',NULL,1,'contado',NULL,1,2),(270,'2026-02-02 03:23:19',20.00,'completed',NULL,1,'contado',NULL,1,3),(271,'2026-02-04 20:01:01',70.00,'completed',NULL,1,'contado',NULL,1,2),(272,'2026-02-05 19:11:02',70.00,'completed',NULL,1,'contado',NULL,1,2),(273,'2026-02-06 19:23:55',70.00,'completed',NULL,1,'contado',NULL,1,2),(274,'2026-02-06 20:12:29',50.00,'completed',NULL,1,'contado',NULL,1,2),(275,'2026-02-07 15:41:23',70.00,'completed',NULL,1,'contado',NULL,1,2),(276,'2026-02-08 21:21:28',100.00,'completed',NULL,15,'contado',NULL,11,17),(277,'2026-02-08 21:21:28',30.00,'completed',NULL,15,'contado',NULL,11,17),(278,'2026-02-08 21:21:28',80.00,'completed',NULL,15,'contado',NULL,11,17),(279,'2026-02-08 21:21:28',65.00,'completed',NULL,15,'contado',NULL,11,17),(280,'2026-02-08 21:23:14',100.00,'completed',NULL,17,'contado',NULL,13,19),(281,'2026-02-08 21:23:14',30.00,'completed',NULL,17,'contado',NULL,13,19),(282,'2026-02-08 21:23:14',80.00,'completed',NULL,17,'contado',NULL,13,19),(283,'2026-02-08 21:23:14',65.00,'completed',NULL,17,'contado',NULL,13,19),(284,'2026-02-08 21:23:35',100.00,'completed',NULL,19,'contado',NULL,15,21),(285,'2026-02-08 21:23:35',30.00,'completed',NULL,19,'contado',NULL,15,21),(286,'2026-02-08 21:23:35',80.00,'completed',NULL,19,'contado',NULL,15,21),(287,'2026-02-08 21:23:35',65.00,'completed',NULL,19,'contado',NULL,15,21),(288,'2026-02-08 21:23:54',100.00,'completed',NULL,21,'contado',NULL,17,23),(289,'2026-02-08 21:23:54',30.00,'completed',NULL,21,'contado',NULL,17,23),(290,'2026-02-08 21:23:54',80.00,'completed',NULL,21,'contado',NULL,17,23),(291,'2026-02-08 21:23:54',65.00,'completed',NULL,21,'contado',NULL,17,23),(292,'2026-02-08 21:25:40',100.00,'completed',NULL,23,'contado',NULL,19,25),(293,'2026-02-08 21:25:40',30.00,'completed',NULL,23,'contado',NULL,19,25),(294,'2026-02-08 21:25:40',80.00,'completed',NULL,23,'contado',NULL,19,25),(295,'2026-02-08 21:25:40',65.00,'completed',NULL,23,'contado',NULL,19,25);
/*!40000 ALTER TABLE `sale` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saleinstallment`
--

DROP TABLE IF EXISTS `saleinstallment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `saleinstallment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sale_id` int NOT NULL,
  `number` int NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `due_date` datetime DEFAULT NULL,
  `status` varchar(255) NOT NULL,
  `paid_amount` decimal(10,2) DEFAULT NULL,
  `payment_date` datetime DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `ix_saleinstallment_status` (`status`),
  KEY `ix_saleinstallment_due_date` (`due_date`),
  KEY `ix_saleinstallment_sale_status` (`sale_id`,`status`),
  KEY `ix_saleinstallment_branch_id` (`branch_id`),
  KEY `ix_saleinstallment_company_id` (`company_id`),
  CONSTRAINT `saleinstallment_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sale` (`id`),
  CONSTRAINT `saleinstallment_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `saleinstallment_ibfk_3` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=49 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saleinstallment`
--

LOCK TABLES `saleinstallment` WRITE;
/*!40000 ALTER TABLE `saleinstallment` DISABLE KEYS */;
INSERT INTO `saleinstallment` VALUES (1,15,1,12.80,'2026-02-02 20:13:28','paid',12.80,'2026-01-03 20:51:48',1,2),(2,15,2,12.80,'2026-03-04 20:13:28','paid',12.80,'2026-01-03 20:53:24',1,2),(3,15,3,12.80,'2026-04-03 20:13:28','paid',12.80,'2026-01-03 22:08:30',1,2),(4,17,1,11.68,'2026-02-02 20:46:42','paid',11.68,'2026-01-12 11:48:16',1,2),(5,17,2,11.68,'2026-03-04 20:46:42','pending',0.00,NULL,1,2),(6,17,3,11.68,'2026-04-03 20:46:42','pending',0.00,NULL,1,2),(7,17,4,11.68,'2026-05-03 20:46:42','pending',0.00,NULL,1,2),(8,17,5,11.68,'2026-06-02 20:46:42','pending',0.00,NULL,1,2),(9,19,1,11.68,'2026-02-02 20:49:02','paid',11.68,'2026-01-03 22:09:45',1,2),(10,19,2,11.68,'2026-03-04 20:49:02','paid',11.68,'2026-01-04 00:09:57',1,2),(11,19,3,11.68,'2026-04-03 20:49:02','pending',0.00,NULL,1,2),(12,19,4,11.68,'2026-05-03 20:49:02','pending',0.00,NULL,1,2),(13,19,5,11.68,'2026-06-02 20:49:02','pending',0.00,NULL,1,2),(14,31,1,10.00,'2026-02-03 00:12:17','paid',10.00,'2026-01-12 11:49:19',1,2),(15,31,2,10.00,'2026-03-05 00:12:17','paid',10.00,'2026-01-12 11:50:39',1,2),(16,31,3,10.00,'2026-04-04 00:12:17','pending',0.00,NULL,1,2),(17,32,1,25.00,'2026-02-03 00:14:51','paid',25.00,'2026-01-04 03:20:36',1,2),(18,32,2,25.00,'2026-03-05 00:14:51','paid',25.00,'2026-01-12 11:51:08',1,2),(19,34,1,18.56,'2026-02-03 01:00:50','paid',18.56,'2026-01-08 11:08:02',1,2),(20,34,2,18.57,'2026-03-05 01:00:50','paid',18.57,'2026-01-12 11:52:19',1,2),(21,34,3,18.57,'2026-04-04 01:00:50','pending',0.00,NULL,1,2),(22,41,1,10.00,'2026-02-03 03:18:25','paid',10.00,'2026-01-12 11:49:54',1,2),(23,41,2,10.00,'2026-03-05 03:18:25','pending',0.00,NULL,1,2),(24,41,3,10.00,'2026-04-04 03:18:25','pending',0.00,NULL,1,2),(25,43,1,19.46,'2026-02-03 04:01:07','paid',19.46,'2026-01-12 11:27:06',1,2),(26,43,2,19.47,'2026-03-05 04:01:07','paid',19.47,'2026-01-12 11:45:02',1,2),(27,43,3,19.47,'2026-04-04 04:01:07','pending',0.00,NULL,1,2),(28,45,1,19.46,'2026-02-03 04:08:31','paid',19.46,'2026-02-06 15:27:51',1,2),(29,45,2,19.47,'2026-03-05 04:08:31','pending',0.00,NULL,1,2),(30,45,3,19.47,'2026-04-04 04:08:31','pending',0.00,NULL,1,2),(31,48,1,10.00,'2026-02-03 05:01:53','paid',10.00,'2026-01-12 11:45:52',1,2),(32,48,2,10.00,'2026-03-05 05:01:53','paid',10.00,'2026-02-02 02:45:36',1,2),(33,48,3,10.00,'2026-04-04 05:01:53','pending',0.00,NULL,1,2),(34,50,1,10.00,'2026-02-03 05:09:05','paid',10.00,'2026-01-19 12:20:16',1,2),(35,50,2,10.00,'2026-03-05 05:09:05','pending',0.00,NULL,1,2),(36,50,3,10.00,'2026-04-04 05:09:05','pending',0.00,NULL,1,2),(37,57,1,10.00,'2026-02-03 07:56:55','paid',10.00,'2026-01-12 01:47:27',1,2),(38,57,2,10.00,'2026-03-05 07:56:55','paid',10.00,'2026-01-12 01:49:08',1,2),(39,57,3,10.00,'2026-04-04 07:56:55','paid',10.00,'2026-01-12 11:38:05',1,2),(40,82,1,50.00,'2026-02-09 05:36:44','paid',50.00,'2026-01-12 01:58:14',1,2),(41,87,1,27.85,'2026-02-10 23:51:47','paid',27.85,'2026-01-12 11:26:18',1,2),(42,87,2,27.85,'2026-03-12 23:51:47','pending',0.00,NULL,1,2),(43,89,1,24.20,'2026-02-11 00:50:03','paid',24.20,'2026-01-12 11:50:19',1,2),(44,89,2,24.20,'2026-03-13 00:50:03','pending',0.00,NULL,1,2),(45,93,1,20.00,'2026-02-11 01:45:58','paid',20.00,'2026-02-07 15:18:15',1,2),(46,93,2,20.00,'2026-03-13 01:45:58','pending',0.00,NULL,1,2),(47,123,1,25.00,'2026-02-20 07:30:44','pending',0.00,NULL,1,2),(48,123,2,25.00,'2026-03-22 07:30:44','pending',0.00,NULL,1,2);
/*!40000 ALTER TABLE `saleinstallment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `saleitem`
--

DROP TABLE IF EXISTS `saleitem`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `saleitem` (
  `id` int NOT NULL AUTO_INCREMENT,
  `quantity` decimal(10,4) DEFAULT NULL,
  `unit_price` decimal(10,2) DEFAULT NULL,
  `subtotal` decimal(10,2) DEFAULT NULL,
  `product_name_snapshot` varchar(255) NOT NULL,
  `product_barcode_snapshot` varchar(255) NOT NULL,
  `sale_id` int NOT NULL,
  `product_id` int DEFAULT NULL,
  `product_category_snapshot` varchar(255) NOT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `product_variant_id` int DEFAULT NULL,
  `product_batch_id` int DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `sale_id` (`sale_id`),
  KEY `ix_saleitem_branch_id` (`branch_id`),
  KEY `ix_saleitem_company_id` (`company_id`),
  KEY `fk_saleitem_product_variant_id` (`product_variant_id`),
  KEY `fk_saleitem_product_batch_id` (`product_batch_id`),
  KEY `ix_saleitem_company_branch_product` (`company_id`,`branch_id`,`product_id`),
  KEY `ix_saleitem_company_branch_sale` (`company_id`,`branch_id`,`sale_id`),
  CONSTRAINT `fk_saleitem_product_batch_id` FOREIGN KEY (`product_batch_id`) REFERENCES `productbatch` (`id`),
  CONSTRAINT `fk_saleitem_product_variant_id` FOREIGN KEY (`product_variant_id`) REFERENCES `productvariant` (`id`),
  CONSTRAINT `saleitem_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `saleitem_ibfk_2` FOREIGN KEY (`sale_id`) REFERENCES `sale` (`id`),
  CONSTRAINT `saleitem_ibfk_3` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `saleitem_ibfk_4` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=387 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `saleitem`
--

LOCK TABLES `saleitem` WRITE;
/*!40000 ALTER TABLE `saleitem` DISABLE KEYS */;
INSERT INTO `saleitem` VALUES (1,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-02 00:00 - 2026-01-02 01:00)','1',1,NULL,'Servicios',1,2,NULL,NULL),(2,1.0000,2.70,2.70,'Coca Cola','7791720003862',2,1,'Bebidas',1,2,NULL,NULL),(3,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-02 00:00:00 - 2026-01-02 01:00:00)','1',2,NULL,'Servicios',1,2,NULL,NULL),(4,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-02 00:00 - 2026-01-02 01:00)','2',3,NULL,'Servicios',1,2,NULL,NULL),(5,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-02 00:00:00 - 2026-01-02 01:00:00)','2',4,NULL,'Servicios',1,2,NULL,NULL),(6,1.0000,2.70,2.70,'Coca Cola','7791720003862',5,1,'Bebidas',1,2,NULL,NULL),(7,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-02 01:00 - 2026-01-02 02:00)','3',6,NULL,'Servicios',1,2,NULL,NULL),(8,1.0000,2.70,2.70,'Coca Cola','7791720003862',7,1,'Bebidas',1,2,NULL,NULL),(9,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-02 01:00:00 - 2026-01-02 02:00:00)','3',7,NULL,'Servicios',1,2,NULL,NULL),(10,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-02 01:00 - 2026-01-02 02:00)','4',8,NULL,'Servicios',1,2,NULL,NULL),(11,1.0000,2.70,2.70,'Coca Cola','7791720003862',9,1,'Bebidas',1,2,NULL,NULL),(12,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-02 01:00:00 - 2026-01-02 02:00:00)','4',9,NULL,'Servicios',1,2,NULL,NULL),(13,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-02 02:00 - 2026-01-02 03:00)','5',10,NULL,'Servicios',1,2,NULL,NULL),(14,1.0000,2.70,2.70,'Coca Cola','7791720003862',11,1,'Bebidas',1,2,NULL,NULL),(15,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-02 02:00:00 - 2026-01-02 03:00:00)','5',11,NULL,'Servicios',1,2,NULL,NULL),(16,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-02 02:00 - 2026-01-02 03:00)','6',12,NULL,'Servicios',1,2,NULL,NULL),(17,1.0000,2.70,2.70,'Coca Cola','7791720003862',13,1,'Bebidas',1,2,NULL,NULL),(18,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-02 02:00:00 - 2026-01-02 03:00:00)','6',13,NULL,'Servicios',1,2,NULL,NULL),(19,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-03 00:00 - 2026-01-03 01:00)','7',14,NULL,'Servicios',1,2,NULL,NULL),(20,1.0000,2.70,2.70,'Coca Cola','7791720003862',15,1,'Bebidas',1,2,NULL,NULL),(21,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',15,2,'Bebidas',1,2,NULL,NULL),(22,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-03 00:00:00 - 2026-01-03 01:00:00)','7',15,NULL,'Servicios',1,2,NULL,NULL),(23,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-03 00:00 - 2026-01-03 01:00)','8',16,NULL,'Servicios',1,2,NULL,NULL),(24,1.0000,2.70,2.70,'Coca Cola','7791720003862',17,1,'Bebidas',1,2,NULL,NULL),(25,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',17,2,'Bebidas',1,2,NULL,NULL),(26,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-03 00:00:00 - 2026-01-03 01:00:00)','8',17,NULL,'Servicios',1,2,NULL,NULL),(27,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-03 01:00 - 2026-01-03 02:00)','9',18,NULL,'Servicios',1,2,NULL,NULL),(28,1.0000,2.70,2.70,'Coca Cola','7791720003862',19,1,'Bebidas',1,2,NULL,NULL),(29,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',19,2,'Bebidas',1,2,NULL,NULL),(30,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-03 01:00:00 - 2026-01-03 02:00:00)','9',19,NULL,'Servicios',1,2,NULL,NULL),(31,1.0000,2.70,2.70,'Coca Cola','7791720003862',20,1,'Bebidas',1,2,NULL,NULL),(32,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-03 01:00 - 2026-01-03 02:00)','10',21,NULL,'Servicios',1,2,NULL,NULL),(33,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',22,2,'Bebidas',1,2,NULL,NULL),(34,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-03 01:00:00 - 2026-01-03 02:00:00)','10',22,NULL,'Servicios',1,2,NULL,NULL),(35,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-03 02:00 - 2026-01-03 03:00)','11',23,NULL,'Servicios',1,2,NULL,NULL),(36,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',24,2,'Bebidas',1,2,NULL,NULL),(37,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-03 02:00:00 - 2026-01-03 03:00:00)','11',24,NULL,'Servicios',1,2,NULL,NULL),(38,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-03 03:00 - 2026-01-03 04:00)','12',25,NULL,'Servicios',1,2,NULL,NULL),(39,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',26,2,'Bebidas',1,2,NULL,NULL),(40,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-03 03:00:00 - 2026-01-03 04:00:00)','12',26,NULL,'Servicios',1,2,NULL,NULL),(41,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-03 02:00 - 2026-01-03 03:00)','13',27,NULL,'Servicios',1,2,NULL,NULL),(42,1.0000,2.70,2.70,'Coca Cola','7791720003862',28,1,'Bebidas',1,2,NULL,NULL),(43,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',28,2,'Bebidas',1,2,NULL,NULL),(44,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-03 02:00:00 - 2026-01-03 03:00:00)','13',28,NULL,'Servicios',1,2,NULL,NULL),(45,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-03 03:00 - 2026-01-03 04:00)','14',29,NULL,'Servicios',1,2,NULL,NULL),(46,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-03 04:00 - 2026-01-03 05:00)','15',30,NULL,'Servicios',1,2,NULL,NULL),(47,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-03 04:00:00 - 2026-01-03 05:00:00)','15',31,NULL,'Servicios',1,2,NULL,NULL),(48,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-03 03:00:00 - 2026-01-03 04:00:00)','14',32,NULL,'Servicios',1,2,NULL,NULL),(49,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-04 00:00 - 2026-01-04 01:00)','16',33,NULL,'Servicios',1,2,NULL,NULL),(50,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',34,2,'Bebidas',1,2,NULL,NULL),(51,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-04 00:00:00 - 2026-01-04 01:00:00)','16',34,NULL,'Servicios',1,2,NULL,NULL),(52,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',35,2,'Bebidas',1,2,NULL,NULL),(53,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-04 00:00 - 2026-01-04 01:00)','17',36,NULL,'Servicios',1,2,NULL,NULL),(54,1.0000,2.70,2.70,'Coca Cola','7791720003862',37,1,'Bebidas',1,2,NULL,NULL),(55,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-04 00:00:00 - 2026-01-04 01:00:00)','17',37,NULL,'Servicios',1,2,NULL,NULL),(56,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-04 01:00 - 2026-01-04 02:00)','18',38,NULL,'Servicios',1,2,NULL,NULL),(57,1.0000,2.70,2.70,'Coca Cola','7791720003862',39,1,'Bebidas',1,2,NULL,NULL),(58,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',39,2,'Bebidas',1,2,NULL,NULL),(59,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-04 01:00:00 - 2026-01-04 02:00:00)','18',39,NULL,'Servicios',1,2,NULL,NULL),(60,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-04 01:00 - 2026-01-04 02:00)','19',40,NULL,'Servicios',1,2,NULL,NULL),(61,1.0000,2.70,2.70,'Coca Cola','7791720003862',41,1,'Bebidas',1,2,NULL,NULL),(62,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',41,2,'Bebidas',1,2,NULL,NULL),(63,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-04 01:00:00 - 2026-01-04 02:00:00)','19',41,NULL,'Servicios',1,2,NULL,NULL),(64,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-04 02:00 - 2026-01-04 03:00)','20',42,NULL,'Servicios',1,2,NULL,NULL),(65,1.0000,2.70,2.70,'Coca Cola','7791720003862',43,1,'Bebidas',1,2,NULL,NULL),(66,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',43,2,'Bebidas',1,2,NULL,NULL),(67,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-04 02:00:00 - 2026-01-04 03:00:00)','20',43,NULL,'Servicios',1,2,NULL,NULL),(68,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-04 02:00 - 2026-01-04 03:00)','21',44,NULL,'Servicios',1,2,NULL,NULL),(69,1.0000,2.70,2.70,'Coca Cola','7791720003862',45,1,'Bebidas',1,2,NULL,NULL),(70,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',45,2,'Bebidas',1,2,NULL,NULL),(71,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-04 02:00:00 - 2026-01-04 03:00:00)','21',45,NULL,'Servicios',1,2,NULL,NULL),(72,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-04 03:00 - 2026-01-04 04:00)','22',46,NULL,'Servicios',1,2,NULL,NULL),(73,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-04 03:00 - 2026-01-04 04:00)','23',47,NULL,'Servicios',1,2,NULL,NULL),(74,1.0000,2.70,2.70,'Coca Cola','7791720003862',48,1,'Bebidas',1,2,NULL,NULL),(75,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',48,2,'Bebidas',1,2,NULL,NULL),(76,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-04 03:00:00 - 2026-01-04 04:00:00)','23',48,NULL,'Servicios',1,2,NULL,NULL),(77,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-04 04:00 - 2026-01-04 05:00)','24',49,NULL,'Servicios',1,2,NULL,NULL),(78,1.0000,2.70,2.70,'Coca Cola','7791720003862',50,1,'Bebidas',1,2,NULL,NULL),(79,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',50,2,'Bebidas',1,2,NULL,NULL),(80,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-04 04:00:00 - 2026-01-04 05:00:00)','24',50,NULL,'Servicios',1,2,NULL,NULL),(81,1.0000,2.70,2.70,'Coca Cola','7791720003862',51,1,'Bebidas',1,2,NULL,NULL),(82,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',52,2,'Bebidas',1,2,NULL,NULL),(83,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',53,2,'Bebidas',1,2,NULL,NULL),(84,1.0000,2.70,2.70,'Coca Cola','7791720003862',54,1,'Bebidas',1,2,NULL,NULL),(85,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',54,2,'Bebidas',1,2,NULL,NULL),(86,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-04 04:00 - 2026-01-04 05:00)','25',55,NULL,'Servicios',1,2,NULL,NULL),(87,1.0000,2.70,2.70,'Coca Cola','7791720003862',56,1,'Bebidas',1,2,NULL,NULL),(88,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',56,2,'Bebidas',1,2,NULL,NULL),(89,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-04 03:00:00 - 2026-01-04 04:00:00)','22',56,NULL,'Servicios',1,2,NULL,NULL),(90,1.0000,2.70,2.70,'Coca Cola','7791720003862',57,1,'Bebidas',1,2,NULL,NULL),(91,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',57,2,'Bebidas',1,2,NULL,NULL),(92,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-04 04:00:00 - 2026-01-04 05:00:00)','25',57,NULL,'Servicios',1,2,NULL,NULL),(93,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-05 00:00 - 2026-01-05 01:00)','26',58,NULL,'Servicios',1,2,NULL,NULL),(94,1.0000,5.30,5.30,'Alcohol Medicinal','7790139003616',59,3,'Medicina',1,2,NULL,NULL),(95,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-05 00:00:00 - 2026-01-05 01:00:00)','26',59,NULL,'Servicios',1,2,NULL,NULL),(96,1.0000,5.30,5.30,'Alcohol Medicinal','7790139003616',60,3,'Medicina',1,2,NULL,NULL),(97,1.0000,5.30,5.30,'Alcohol Medicinal','7790139003616',60,3,'Medicina',1,2,NULL,NULL),(98,1.0000,5.30,5.30,'Alcohol Medicinal','7790139003616',60,3,'Medicina',1,2,NULL,NULL),(99,1.0000,5.30,5.30,'Alcohol Medicinal','7790139003616',61,3,'Medicina',1,2,NULL,NULL),(100,1.0000,5.30,5.30,'Alcohol Medicinal','7790139003616',62,3,'Medicina',1,2,NULL,NULL),(101,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-07 00:00 - 2026-01-07 01:00)','27',63,NULL,'Servicios',1,2,NULL,NULL),(102,2.0000,2.70,5.40,'Coca Cola','7791720003862',64,1,'Bebidas',1,2,NULL,NULL),(103,3.0000,5.20,15.60,'Agua mineral 1.5L','7798113301611',65,4,'Bebidas',1,2,NULL,NULL),(104,3.0000,5.70,17.10,'Gatorade 1.5l','7790895011221',66,2,'Bebidas',1,2,NULL,NULL),(105,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-07 00:00 - 2026-01-07 01:00)','28',67,NULL,'Servicios',1,2,NULL,NULL),(106,2.0000,5.70,11.40,'Gatorade 1.5l','7790895011221',68,2,'Bebidas',1,2,NULL,NULL),(107,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-07 00:00:00 - 2026-01-07 01:00:00)','28',68,NULL,'Servicios',1,2,NULL,NULL),(108,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-07 01:00 - 2026-01-07 02:00)','29',69,NULL,'Servicios',1,2,NULL,NULL),(109,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-07 01:00:00 - 2026-01-07 02:00:00)','29',70,NULL,'Servicios',1,2,NULL,NULL),(110,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-07 00:00:00 - 2026-01-07 01:00:00)','27',71,NULL,'Servicios',1,2,NULL,NULL),(111,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',72,2,'Bebidas',1,2,NULL,NULL),(112,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-08 00:00 - 2026-01-08 01:00)','30',73,NULL,'Servicios',1,2,NULL,NULL),(113,2.0000,5.70,11.40,'Gatorade 1.5l','7790895011221',74,2,'Bebidas',1,2,NULL,NULL),(114,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-08 00:00:00 - 2026-01-08 01:00:00)','30',74,NULL,'Servicios',1,2,NULL,NULL),(115,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-08 00:00 - 2026-01-08 01:00)','31',75,NULL,'Servicios',1,2,NULL,NULL),(116,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-08 00:00:00 - 2026-01-08 01:00:00)','31',76,NULL,'Servicios',1,2,NULL,NULL),(117,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-08 01:00 - 2026-01-08 02:00)','32',77,NULL,'Servicios',1,2,NULL,NULL),(118,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-08 01:00:00 - 2026-01-08 02:00:00)','32',78,NULL,'Servicios',1,2,NULL,NULL),(119,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',79,2,'Bebidas',1,2,NULL,NULL),(120,2.0000,2.70,5.40,'Coca Cola','7791720003862',80,1,'Bebidas',1,2,NULL,NULL),(121,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-09 00:00 - 2026-01-09 01:00)','33',81,NULL,'Servicios',1,2,NULL,NULL),(122,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-09 00:00:00 - 2026-01-09 01:00:00)','33',82,NULL,'Servicios',1,2,NULL,NULL),(123,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-10 06:00 - 2026-01-10 07:00)','34',83,NULL,'Servicios',1,2,NULL,NULL),(124,1.0000,2.70,2.70,'Coca Cola','7791720003862',84,1,'Bebidas',1,2,NULL,NULL),(125,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',85,2,'Bebidas',1,2,NULL,NULL),(126,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-10 06:00:00 - 2026-01-10 07:00:00)','34',85,NULL,'Servicios',1,2,NULL,NULL),(127,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-11 06:00 - 2026-01-11 07:00)','35',86,NULL,'Servicios',1,2,NULL,NULL),(128,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',87,2,'Bebidas',1,2,NULL,NULL),(129,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-11 06:00:00 - 2026-01-11 07:00:00)','35',87,NULL,'Servicios',1,2,NULL,NULL),(130,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-12 06:00 - 2026-01-12 07:00)','36',88,NULL,'Servicios',1,2,NULL,NULL),(131,1.0000,2.70,2.70,'Coca Cola','7791720003862',89,1,'Bebidas',1,2,NULL,NULL),(132,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',89,2,'Bebidas',1,2,NULL,NULL),(133,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-12 06:00:00 - 2026-01-12 07:00:00)','36',89,NULL,'Servicios',1,2,NULL,NULL),(134,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-12 06:00 - 2026-01-12 07:00)','37',90,NULL,'Servicios',1,2,NULL,NULL),(135,1.0000,2.70,2.70,'Coca Cola','7791720003862',91,1,'Bebidas',1,2,NULL,NULL),(136,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',91,2,'Bebidas',1,2,NULL,NULL),(137,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-12 06:00:00 - 2026-01-12 07:00:00)','37',91,NULL,'Servicios',1,2,NULL,NULL),(138,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-12 07:00 - 2026-01-12 08:00)','38',92,NULL,'Servicios',1,2,NULL,NULL),(139,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-12 07:00:00 - 2026-01-12 08:00:00)','38',93,NULL,'Servicios',1,2,NULL,NULL),(140,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-12 08:00 - 2026-01-12 09:00)','40',94,NULL,'Servicios',1,2,NULL,NULL),(141,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',95,2,'Bebidas',1,2,NULL,NULL),(142,1.0000,2.70,2.70,'Coca Cola','7791720003862',96,1,'Bebidas',1,2,NULL,NULL),(143,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',97,2,'Bebidas',1,2,NULL,NULL),(144,1.0000,70.00,70.00,'Alquiler Cancha 2 Noche (2026-01-12 07:00:00 - 2026-01-12 08:00:00)','39',98,NULL,'Servicios',1,2,NULL,NULL),(145,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',99,2,'Bebidas',1,2,NULL,NULL),(146,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-12 08:00:00 - 2026-01-12 09:00:00)','40',99,NULL,'Servicios',1,2,NULL,NULL),(147,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-18 06:00 - 2026-01-18 07:00)','41',100,NULL,'Servicios',1,2,NULL,NULL),(148,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',101,2,'Bebidas',1,2,NULL,NULL),(149,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-18 06:00:00 - 2026-01-18 07:00:00)','41',101,NULL,'Servicios',1,2,NULL,NULL),(150,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-18 06:00 - 2026-01-18 07:00)','42',102,NULL,'Servicios',1,2,NULL,NULL),(151,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-18 06:00:00 - 2026-01-18 07:00:00)','42',103,NULL,'Servicios',1,2,NULL,NULL),(152,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',104,2,'Bebidas',1,2,NULL,NULL),(153,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-19 06:00 - 2026-01-19 07:00)','43',105,NULL,'Servicios',1,2,NULL,NULL),(154,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',106,2,'Bebidas',1,2,NULL,NULL),(155,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-19 06:00:00 - 2026-01-19 07:00:00)','43',106,NULL,'Servicios',1,2,NULL,NULL),(156,1.0000,2.70,2.70,'Coca Cola','7791720003862',107,1,'Bebidas',1,2,NULL,NULL),(157,1.0000,2.70,2.70,'Coca Cola','7791720003862',108,1,'Bebidas',1,2,NULL,NULL),(158,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-19 06:00 - 2026-01-19 07:00)','44',109,NULL,'Servicios',1,2,NULL,NULL),(159,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-19 06:00:00 - 2026-01-19 07:00:00)','44',110,NULL,'Servicios',1,2,NULL,NULL),(160,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-19 07:00 - 2026-01-19 08:00)','45',111,NULL,'Servicios',1,2,NULL,NULL),(161,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',112,2,'Bebidas',1,2,NULL,NULL),(162,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-19 07:00:00 - 2026-01-19 08:00:00)','45',112,NULL,'Servicios',1,2,NULL,NULL),(163,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-19 07:00 - 2026-01-19 08:00)','46',113,NULL,'Servicios',1,2,NULL,NULL),(164,1.0000,2.70,2.70,'Coca Cola','7791720003862',114,1,'Bebidas',1,2,NULL,NULL),(165,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-19 07:00:00 - 2026-01-19 08:00:00)','46',114,NULL,'Servicios',1,2,NULL,NULL),(166,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-20 06:00 - 2026-01-20 07:00)','47',115,NULL,'Servicios',1,2,NULL,NULL),(167,1.0000,2.70,2.70,'Coca Cola','7791720003862',116,1,'Bebidas',1,2,NULL,NULL),(168,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',117,2,'Bebidas',1,2,NULL,NULL),(169,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-21 06:00 - 2026-01-21 07:00)','48',118,NULL,'Servicios',1,2,NULL,NULL),(170,1.0000,20.00,20.00,'Adelanto Cancha  Día2 (2026-01-21 06:00 - 2026-01-21 07:00)','49',119,NULL,'Servicios',1,2,NULL,NULL),(171,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-21 06:00:00 - 2026-01-21 07:00:00)','48',120,NULL,'Servicios',1,2,NULL,NULL),(172,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-20 06:00:00 - 2026-01-20 07:00:00)','47',121,NULL,'Servicios',1,2,NULL,NULL),(173,1.0000,2.70,2.70,'Coca Cola','7791720003862',122,1,'Bebidas',1,2,NULL,NULL),(174,1.0000,50.00,50.00,'Alquiler Cancha  Día2 (2026-01-21 06:00:00 - 2026-01-21 07:00:00)','49',122,NULL,'Servicios',1,2,NULL,NULL),(175,1.0000,70.00,70.00,'Alquiler Cancha 2 Noche (2026-01-21 07:00:00 - 2026-01-21 08:00:00)','50',123,NULL,'Servicios',1,2,NULL,NULL),(176,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',124,2,'Bebidas',1,2,NULL,NULL),(177,1.0000,2.90,2.90,'Coca Cola','7791720003862',125,1,'Bebidas',1,2,NULL,NULL),(178,1.0000,2.70,2.70,'Coca Cola','7791720003862',126,1,'Bebidas',1,2,NULL,NULL),(179,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-01-26 06:00 - 2026-01-26 07:00)','51',127,NULL,'Servicios',1,2,NULL,NULL),(180,1.0000,2.70,2.70,'Coca Cola','7791720003862',128,1,'Bebidas',1,2,NULL,NULL),(181,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',128,2,'Bebidas',1,2,NULL,NULL),(182,1.0000,5.20,5.20,'Agua mineral 1.5L','7798113301611',128,4,'Bebidas',1,2,NULL,NULL),(183,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-01-26 06:00:00 - 2026-01-26 07:00:00)','51',128,NULL,'Servicios',1,2,NULL,NULL),(184,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-01-27 06:00 - 2026-01-27 07:00)','52',129,NULL,'Servicios',1,2,NULL,NULL),(185,1.0000,5.70,5.70,'Gatorade 1.5l','7790895011221',130,2,'Bebidas',1,2,NULL,NULL),(186,1.0000,2.70,2.70,'Coca Cola','7791720003862',130,1,'Bebidas',1,2,NULL,NULL),(187,1.0000,5.20,5.20,'Agua mineral 1.5L','7798113301611',130,4,'Bebidas',1,2,NULL,NULL),(188,1.0000,3.50,3.50,'Pasta Dental Kolynos','7509546686509',130,5,'Medicina',1,2,NULL,NULL),(189,1.0000,5.30,5.30,'Alcohol Medicinal','7790139003616',130,3,'Medicina',1,2,NULL,NULL),(190,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-27 06:00:00 - 2026-01-27 07:00:00)','52',130,NULL,'Servicios',1,2,NULL,NULL),(191,1.0000,2.70,2.70,'Coca Cola','7791720003862',131,1,'Bebidas',1,2,NULL,NULL),(192,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-01-27 07:00:00 - 2026-01-27 08:00:00)','53',131,NULL,'Servicios',1,2,NULL,NULL),(193,1.0000,4.50,4.50,'COCA COLA 5ML','111222333444555',132,6,'BEBIDAS',1,3,NULL,NULL),(194,1.0000,20.00,20.00,'Adelanto Campo 1 Dia (2026-02-02 06:00 - 2026-02-02 07:00)','54',133,NULL,'Servicios',1,3,NULL,NULL),(195,1.0000,4.50,4.50,'COCA COLA 5ML','111222333444555',134,6,'BEBIDAS',1,3,NULL,NULL),(196,1.0000,30.00,30.00,'Alquiler Campo 1 Dia (2026-02-02 06:00:00 - 2026-02-02 07:00:00)','54',134,NULL,'Servicios',1,3,NULL,NULL),(197,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-02-02 06:00 - 2026-02-02 07:00)','55',135,NULL,'Servicios',1,2,NULL,NULL),(198,1.0000,50.00,50.00,'Zapatillas Deportivas Runner','123456789',136,15,'General',3,4,NULL,NULL),(199,1.0000,50.00,50.00,'Zapatillas Deportivas Runner','123456789',136,15,'General',3,4,NULL,NULL),(200,1.0000,200.00,200.00,'Zapatillas Deportivas Futbol','7790895650833',137,17,'Zapatillas Futbol',3,4,NULL,NULL),(201,1.0000,200.00,200.00,'Zapatillas Deportivas Futbol','7790895650833',137,17,'Zapatillas Futbol',3,4,NULL,NULL),(202,1.0000,200.00,200.00,'Zapatillas Deportivas Futbol','7790895650833',138,17,'Zapatillas Futbol',3,4,NULL,NULL),(203,1.0000,200.00,200.00,'Zapatillas Deportivas Futbol','7790895650833',138,17,'Zapatillas Futbol',3,4,NULL,NULL),(204,1.0000,200.00,200.00,'Zapatillas Deportivas Futbol (40 AZUL)','7791720033630',139,17,'Zapatillas Futbol',3,4,21,NULL),(205,1.0000,2.70,2.70,'Coca Cola 500ml','7791720003862',140,1,'Bebidas',1,2,NULL,NULL),(206,1.0000,5.20,5.20,'Agua mineral 1.5L','7798113301611',140,4,'Bebidas',1,2,NULL,NULL),(207,1.0000,5.30,5.30,'Alcohol Medicinal','7790139003616',140,3,'Medicina',1,2,NULL,NULL),(208,1.0000,5.00,5.00,'Gatorade 1.5l','7790895011221',140,2,'Bebidas',1,2,NULL,NULL),(209,1.0000,2.70,2.70,'Paracetamol 500mg','7790895650833',140,18,'Medicina',1,2,NULL,5),(210,1.0000,150.00,150.00,'Zapatillas Runner (39 Naranja)','7798420160116',140,20,'Zapatillas Runner',1,2,24,NULL),(211,1.0000,150.00,150.00,'Zapatillas de Futbol (39 Azul)','7791720033630',140,19,'Zapatillas de Futbol',1,2,22,NULL),(212,1.0000,150.00,150.00,'Zapatillas de Futbol (40 Verde)','7790580602000',140,19,'Zapatillas de Futbol',1,2,23,NULL),(213,1.0000,150.00,150.00,'Zapatillas Runner (40 Marron)','7798033337257',140,20,'Zapatillas Runner',1,2,25,NULL),(214,5.0000,7000.00,35000.00,'Pañuelitos','7790250000358',141,21,'Medicina',1,2,NULL,NULL),(215,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-02-04 06:00 - 2026-02-04 07:00)','57',142,NULL,'Servicios',1,2,NULL,NULL),(216,1.0000,2.70,2.70,'Coca Cola 500ml','7791720003862',143,1,'Bebidas',1,2,NULL,NULL),(217,1.0000,2.70,2.70,'Coca Cola 500ml','7791720003862',144,1,'Bebidas',1,2,NULL,NULL),(218,1.0000,2.70,2.70,'Coca Cola 500ml','7791720003862',145,1,'Bebidas',1,2,NULL,NULL),(219,1.0000,2.70,2.70,'Coca Cola 500ml','7791720003862',146,1,'Bebidas',1,2,NULL,NULL),(220,1.0000,5.20,5.20,'Agua mineral 1.5L','7798113301611',147,4,'Bebidas',1,2,NULL,NULL),(221,1.0000,5.30,5.30,'Alcohol Medicinal','7790139003616',147,3,'Medicina',1,2,NULL,NULL),(222,1.0000,5.00,5.00,'Gatorade 1.5l','7790895011221',147,2,'Bebidas',1,2,NULL,NULL),(223,1.0000,5.00,5.00,'Gatorade 1.25ml','7792170110551',147,16,'Bebidas',1,2,NULL,NULL),(224,1.0000,150.00,150.00,'Zapatillas de Futbol (40 Verde)','7790580602000',148,19,'Zapatillas de Futbol',1,2,23,NULL),(225,1.0000,150.00,150.00,'Zapatillas de Futbol (39 Azul)','7791720033630',148,19,'Zapatillas de Futbol',1,2,22,NULL),(226,1.0000,150.00,150.00,'Zapatillas Runner (40 Marron)','7798033337257',148,20,'Zapatillas Runner',1,2,25,NULL),(227,1.0000,150.00,150.00,'Zapatillas Runner (39 Naranja)','7798420160116',148,20,'Zapatillas Runner',1,2,24,NULL),(228,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-02-04 06:00:00 - 2026-02-04 07:00:00)','57',148,NULL,'Servicios',1,2,NULL,NULL),(229,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-02-05 06:00 - 2026-02-05 07:00)','58',149,NULL,'Servicios',1,2,NULL,NULL),(230,1.0000,5.30,5.30,'Alcohol Medicinal','7790139003616',150,3,'Medicina',1,2,NULL,NULL),(231,1.0000,5.20,5.20,'Agua mineral 1.5L','7798113301611',150,4,'Bebidas',1,2,NULL,NULL),(232,1.0000,5.00,5.00,'Gatorade 1.5l','7790895011221',150,2,'Bebidas',1,2,NULL,NULL),(233,1.0000,5.00,5.00,'Gatorade 1.25ml','7792170110551',150,16,'Bebidas',1,2,NULL,NULL),(234,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-02-05 06:00:00 - 2026-02-05 07:00:00)','58',150,NULL,'Servicios',1,2,NULL,NULL),(235,4.0000,5.00,20.00,'Gatorade 1.5l','7790895011221',151,2,'Bebidas',1,2,NULL,NULL),(236,1.0000,150.00,150.00,'Zapatillas Runner (39 Naranja)','7798420160116',152,20,'Zapatillas Runner',1,2,24,NULL),(237,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-02-06 06:00 - 2026-02-06 07:00)','59',153,NULL,'Servicios',1,2,NULL,NULL),(238,2.0000,5.00,10.00,'Gatorade 1.25ml','7792170110551',154,16,'Bebidas',1,2,NULL,NULL),(239,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-02-06 06:00:00 - 2026-02-06 07:00:00)','59',154,NULL,'Servicios',1,2,NULL,NULL),(240,5.0000,5.00,25.00,'Gatorade 1.5l','7790895011221',155,2,'Bebidas',1,2,NULL,NULL),(241,1.0000,20.00,20.00,'Adelanto Cancha 1 Día (2026-02-06 06:00 - 2026-02-06 07:00)','60',156,NULL,'Servicios',1,2,NULL,NULL),(242,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-02-02 06:00:00 - 2026-02-02 07:00:00)','55',157,NULL,'Servicios',1,2,NULL,NULL),(243,1.0000,30.00,30.00,'Alquiler Cancha 1 Día (2026-02-06 06:00:00 - 2026-02-06 07:00:00)','60',158,NULL,'Servicios',1,2,NULL,NULL),(244,5.0000,5.00,25.00,'Gatorade 1.5l','7790895011221',159,2,'Bebidas',1,2,NULL,NULL),(245,1.0000,150.00,150.00,'Zapatillas Runner (39 Naranja)','7798420160116',160,20,'Zapatillas Runner',1,2,24,NULL),(296,1.0000,5.30,5.30,'Alcohol Medicinal','7790139003616',211,3,'Medicina',1,2,NULL,NULL),(297,3.0000,150.00,450.00,'Zapatillas Runner (39 Naranja)','7798420160116',211,20,'Zapatillas Runner',1,2,24,NULL),(298,1.0000,20.00,20.00,'Adelanto Cancha 2 Noche (2026-02-07 09:00 - 2026-02-07 10:00)','62',212,NULL,'Servicios',1,2,NULL,NULL),(299,1.0000,50.00,50.00,'Alquiler Cancha 2 Noche (2026-02-07 09:00:00 - 2026-02-07 10:00:00)','62',213,NULL,'Servicios',1,2,NULL,NULL),(300,1.0000,4.00,4.00,'Leche evaporada','111222333444555',214,7,'Lacteos',1,2,NULL,NULL),(301,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',215,NULL,'Servicios',1,2,NULL,NULL),(302,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',216,NULL,'Servicios',1,2,NULL,NULL),(303,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',217,NULL,'Servicios',1,2,NULL,NULL),(304,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',218,NULL,'Servicios',1,2,NULL,NULL),(305,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',219,NULL,'Servicios',1,2,NULL,NULL),(306,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',220,NULL,'Servicios',1,2,NULL,NULL),(307,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',221,NULL,'Servicios',1,2,NULL,NULL),(308,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',222,NULL,'Servicios',1,2,NULL,NULL),(309,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',223,NULL,'Servicios',1,2,NULL,NULL),(310,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',224,NULL,'Servicios',1,2,NULL,NULL),(311,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',225,NULL,'Servicios',1,2,NULL,NULL),(312,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',226,NULL,'Servicios',1,2,NULL,NULL),(313,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',227,NULL,'Servicios',1,2,NULL,NULL),(314,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',228,NULL,'Servicios',1,2,NULL,NULL),(315,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',229,NULL,'Servicios',1,2,NULL,NULL),(316,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',230,NULL,'Servicios',1,2,NULL,NULL),(317,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',231,NULL,'Servicios',1,2,NULL,NULL),(318,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',232,NULL,'Servicios',1,2,NULL,NULL),(319,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',233,NULL,'Servicios',1,2,NULL,NULL),(320,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',234,NULL,'Servicios',1,2,NULL,NULL),(321,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',235,NULL,'Servicios',1,2,NULL,NULL),(322,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',236,NULL,'Servicios',1,2,NULL,NULL),(323,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',237,NULL,'Servicios',1,2,NULL,NULL),(324,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',238,NULL,'Servicios',1,2,NULL,NULL),(325,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',239,NULL,'Servicios',1,2,NULL,NULL),(326,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',240,NULL,'Servicios',1,2,NULL,NULL),(327,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',241,NULL,'Servicios',1,2,NULL,NULL),(328,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',242,NULL,'Servicios',1,2,NULL,NULL),(329,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',243,NULL,'Servicios',1,2,NULL,NULL),(330,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',244,NULL,'Servicios',1,2,NULL,NULL),(331,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',245,NULL,'Servicios',1,2,NULL,NULL),(332,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',246,NULL,'Servicios',1,2,NULL,NULL),(333,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',247,NULL,'Servicios',1,2,NULL,NULL),(334,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',248,NULL,'Servicios',1,2,NULL,NULL),(335,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',249,NULL,'Servicios',1,2,NULL,NULL),(336,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',250,NULL,'Servicios',1,2,NULL,NULL),(337,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',251,NULL,'Servicios',1,2,NULL,NULL),(338,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',252,NULL,'Servicios',1,2,NULL,NULL),(339,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',253,NULL,'Servicios',1,2,NULL,NULL),(340,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',254,NULL,'Servicios',1,2,NULL,NULL),(341,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',255,NULL,'Servicios',1,2,NULL,NULL),(342,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',256,NULL,'Servicios',1,2,NULL,NULL),(343,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',257,NULL,'Servicios',1,2,NULL,NULL),(344,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',258,NULL,'Servicios',1,2,NULL,NULL),(345,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',259,NULL,'Servicios',1,2,NULL,NULL),(346,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',260,NULL,'Servicios',1,2,NULL,NULL),(347,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',261,NULL,'Servicios',1,2,NULL,NULL),(348,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',262,NULL,'Servicios',1,2,NULL,NULL),(349,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha  Día2','RESERVA',263,NULL,'Servicios',1,2,NULL,NULL),(350,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',264,NULL,'Servicios',1,2,NULL,NULL),(351,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',265,NULL,'Servicios',1,2,NULL,NULL),(352,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',266,NULL,'Servicios',1,2,NULL,NULL),(353,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',267,NULL,'Servicios',1,2,NULL,NULL),(354,1.0000,50.00,50.00,'Reserva histórica reserva: Campo 1 Dia','RESERVA',268,NULL,'Servicios',1,3,NULL,NULL),(355,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',269,NULL,'Servicios',1,2,NULL,NULL),(356,1.0000,20.00,20.00,'Adelanto histórica reserva: Campo 1 Dia','RESERVA',270,NULL,'Servicios',1,3,NULL,NULL),(357,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',271,NULL,'Servicios',1,2,NULL,NULL),(358,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',272,NULL,'Servicios',1,2,NULL,NULL),(359,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',273,NULL,'Servicios',1,2,NULL,NULL),(360,1.0000,50.00,50.00,'Reserva histórica reserva: Cancha 1 Día','RESERVA',274,NULL,'Servicios',1,2,NULL,NULL),(361,1.0000,70.00,70.00,'Reserva histórica reserva: Cancha 2 Noche','RESERVA',275,NULL,'Servicios',1,2,NULL,NULL),(362,1.0000,100.00,100.00,'Pago reserva: Cancha Smoke 1','RESERVA',276,NULL,'Servicios',11,17,NULL,NULL),(363,2.0000,15.00,30.00,'Producto Smoke 20260208212125','SMK-PROD-20260208212125',277,24,'Smoke',11,17,NULL,NULL),(364,1.0000,80.00,80.00,'Alquiler Cancha Smoke 2 (2026-02-09 01:21:00 - 2026-02-09 02:21:00)','64',278,NULL,'Servicios',11,17,NULL,NULL),(365,1.0000,15.00,15.00,'Producto Smoke 20260208212125','SMK-PROD-20260208212125',279,24,'Smoke',11,17,NULL,NULL),(366,1.0000,50.00,50.00,'Alquiler Cancha Smoke 3 (2026-02-09 03:21:00 - 2026-02-09 04:21:00)','65',279,NULL,'Servicios',11,17,NULL,NULL),(367,1.0000,100.00,100.00,'Pago reserva: Cancha Smoke 1','RESERVA',280,NULL,'Servicios',13,19,NULL,NULL),(368,2.0000,15.00,30.00,'Producto Smoke 20260208212311','SMK-PROD-20260208212311',281,25,'Smoke',13,19,NULL,NULL),(369,1.0000,80.00,80.00,'Alquiler Cancha Smoke 2 (2026-02-09 01:23:00 - 2026-02-09 02:23:00)','67',282,NULL,'Servicios',13,19,NULL,NULL),(370,1.0000,15.00,15.00,'Producto Smoke 20260208212311','SMK-PROD-20260208212311',283,25,'Smoke',13,19,NULL,NULL),(371,1.0000,50.00,50.00,'Alquiler Cancha Smoke 3 (2026-02-09 03:23:00 - 2026-02-09 04:23:00)','68',283,NULL,'Servicios',13,19,NULL,NULL),(372,1.0000,100.00,100.00,'Pago reserva: Cancha Smoke 1','RESERVA',284,NULL,'Servicios',15,21,NULL,NULL),(373,2.0000,15.00,30.00,'Producto Smoke 20260208212332','SMK-PROD-20260208212332',285,26,'Smoke',15,21,NULL,NULL),(374,1.0000,80.00,80.00,'Alquiler Cancha Smoke 2 (2026-02-09 01:23:00 - 2026-02-09 02:23:00)','70',286,NULL,'Servicios',15,21,NULL,NULL),(375,1.0000,15.00,15.00,'Producto Smoke 20260208212332','SMK-PROD-20260208212332',287,26,'Smoke',15,21,NULL,NULL),(376,1.0000,50.00,50.00,'Alquiler Cancha Smoke 3 (2026-02-09 03:23:00 - 2026-02-09 04:23:00)','71',287,NULL,'Servicios',15,21,NULL,NULL),(377,1.0000,100.00,100.00,'Pago reserva: Cancha Smoke 1','RESERVA',288,NULL,'Servicios',17,23,NULL,NULL),(378,2.0000,15.00,30.00,'Producto Smoke 20260208212351','SMK-PROD-20260208212351',289,27,'Smoke',17,23,NULL,NULL),(379,1.0000,80.00,80.00,'Alquiler Cancha Smoke 2 (2026-02-09 01:23:00 - 2026-02-09 02:23:00)','73',290,NULL,'Servicios',17,23,NULL,NULL),(380,1.0000,15.00,15.00,'Producto Smoke 20260208212351','SMK-PROD-20260208212351',291,27,'Smoke',17,23,NULL,NULL),(381,1.0000,50.00,50.00,'Alquiler Cancha Smoke 3 (2026-02-09 03:23:00 - 2026-02-09 04:23:00)','74',291,NULL,'Servicios',17,23,NULL,NULL),(382,1.0000,100.00,100.00,'Pago reserva: Cancha Smoke 1','RESERVA',292,NULL,'Servicios',19,25,NULL,NULL),(383,2.0000,15.00,30.00,'Producto Smoke 20260208212537','SMK-PROD-20260208212537',293,28,'Smoke',19,25,NULL,NULL),(384,1.0000,80.00,80.00,'Alquiler Cancha Smoke 2 (2026-02-09 01:25:00 - 2026-02-09 02:25:00)','76',294,NULL,'Servicios',19,25,NULL,NULL),(385,1.0000,15.00,15.00,'Producto Smoke 20260208212537','SMK-PROD-20260208212537',295,28,'Smoke',19,25,NULL,NULL),(386,1.0000,50.00,50.00,'Alquiler Cancha Smoke 3 (2026-02-09 03:25:00 - 2026-02-09 04:25:00)','77',295,NULL,'Servicios',19,25,NULL,NULL);
/*!40000 ALTER TABLE `saleitem` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `salepayment`
--

DROP TABLE IF EXISTS `salepayment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `salepayment` (
  `id` int NOT NULL AUTO_INCREMENT,
  `sale_id` int NOT NULL,
  `amount` decimal(10,2) DEFAULT NULL,
  `method_type` enum('cash','debit','credit','yape','plin','transfer','mixed','other','card','wallet') NOT NULL,
  `reference_code` varchar(255) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `payment_method_id` int DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sale_id` (`sale_id`),
  KEY `payment_method_id` (`payment_method_id`),
  KEY `ix_salepayment_branch_id` (`branch_id`),
  KEY `ix_salepayment_company_id` (`company_id`),
  CONSTRAINT `salepayment_ibfk_1` FOREIGN KEY (`sale_id`) REFERENCES `sale` (`id`),
  CONSTRAINT `salepayment_ibfk_2` FOREIGN KEY (`payment_method_id`) REFERENCES `paymentmethod` (`id`),
  CONSTRAINT `salepayment_ibfk_3` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `salepayment_ibfk_4` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=295 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `salepayment`
--

LOCK TABLES `salepayment` WRITE;
/*!40000 ALTER TABLE `salepayment` DISABLE KEYS */;
INSERT INTO `salepayment` VALUES (1,1,20.00,'cash',NULL,'2026-01-02 01:10:25',NULL,1,2),(2,2,12.70,'yape',NULL,'2026-01-02 01:14:17',NULL,1,2),(3,2,20.00,'cash',NULL,'2026-01-02 01:14:17',NULL,1,2),(4,3,20.00,'cash',NULL,'2026-01-02 01:30:15',NULL,1,2),(5,4,30.00,'yape',NULL,'2026-01-02 01:30:28',NULL,1,2),(6,5,2.70,'plin',NULL,'2026-01-02 01:30:53',NULL,1,2),(7,6,20.00,'cash',NULL,'2026-01-02 13:51:15',NULL,1,2),(8,7,32.70,'plin',NULL,'2026-01-02 13:51:47',NULL,1,2),(9,8,20.00,'cash',NULL,'2026-01-02 15:47:22',NULL,1,2),(10,9,32.70,'yape',NULL,'2026-01-02 15:47:57',NULL,1,2),(11,10,20.00,'cash',NULL,'2026-01-02 16:41:41',NULL,1,2),(12,11,22.70,'plin',NULL,'2026-01-02 16:52:48',NULL,1,2),(13,11,30.00,'cash',NULL,'2026-01-02 16:52:48',NULL,1,2),(14,12,20.00,'cash',NULL,'2026-01-02 16:53:49',NULL,1,2),(15,13,12.70,'yape',NULL,'2026-01-02 16:54:08',NULL,1,2),(16,13,40.00,'cash',NULL,'2026-01-02 16:54:08',NULL,1,2),(17,14,20.00,'cash',NULL,'2026-01-03 19:37:56',NULL,1,2),(18,16,20.00,'cash',NULL,'2026-01-03 20:44:50',NULL,1,2),(19,18,20.00,'cash',NULL,'2026-01-03 20:47:52',NULL,1,2),(20,20,2.70,'cash',NULL,'2026-01-03 22:15:46',NULL,1,2),(21,21,20.00,'cash',NULL,'2026-01-03 22:16:27',NULL,1,2),(22,22,35.70,'yape',NULL,'2026-01-03 22:17:14',NULL,1,2),(23,23,20.00,'cash',NULL,'2026-01-03 22:19:25',NULL,1,2),(24,24,15.70,'plin',NULL,'2026-01-03 22:20:40',NULL,1,2),(25,24,20.00,'cash',NULL,'2026-01-03 22:20:40',NULL,1,2),(26,25,20.00,'cash',NULL,'2026-01-03 22:25:02',NULL,1,2),(27,26,55.70,'debit',NULL,'2026-01-03 22:25:28',NULL,1,2),(28,27,20.00,'cash',NULL,'2026-01-04 00:03:35',NULL,1,2),(29,28,58.40,'yape',NULL,'2026-01-04 00:04:24',NULL,1,2),(30,29,20.00,'cash',NULL,'2026-01-04 00:06:46',NULL,1,2),(31,30,20.00,'cash',NULL,'2026-01-04 00:08:11',NULL,1,2),(32,33,20.00,'cash',NULL,'2026-01-04 00:59:57',NULL,1,2),(33,35,5.70,'cash',NULL,'2026-01-04 03:04:39',NULL,1,2),(34,36,20.00,'cash',NULL,'2026-01-04 03:08:37',NULL,1,2),(35,37,52.70,'plin',NULL,'2026-01-04 03:09:59',NULL,1,2),(36,38,20.00,'cash',NULL,'2026-01-04 03:12:48',NULL,1,2),(37,39,38.40,'transfer',NULL,'2026-01-04 03:13:41',NULL,1,2),(38,39,20.00,'cash',NULL,'2026-01-04 03:13:41',NULL,1,2),(39,40,20.00,'cash',NULL,'2026-01-04 03:15:54',NULL,1,2),(40,41,28.40,'transfer',NULL,'2026-01-04 03:18:25',NULL,1,2),(41,42,20.00,'cash',NULL,'2026-01-04 03:59:05',NULL,1,2),(42,44,20.00,'cash',NULL,'2026-01-04 04:05:39',NULL,1,2),(43,46,20.00,'cash',NULL,'2026-01-04 04:10:25',NULL,1,2),(44,47,20.00,'cash',NULL,'2026-01-04 05:00:14',NULL,1,2),(45,48,28.40,'cash',NULL,'2026-01-04 05:01:53',NULL,1,2),(46,49,20.00,'cash',NULL,'2026-01-04 05:07:45',NULL,1,2),(47,50,28.40,'cash',NULL,'2026-01-04 05:09:05',NULL,1,2),(48,51,2.70,'plin',NULL,'2026-01-04 07:49:42',12,1,2),(49,52,5.70,'yape',NULL,'2026-01-04 07:50:42',11,1,2),(50,53,5.70,'yape',NULL,'2026-01-04 07:51:07',11,1,2),(51,54,8.40,'credit',NULL,'2026-01-04 07:51:29',NULL,1,2),(52,55,20.00,'cash',NULL,'2026-01-04 07:52:02',NULL,1,2),(53,56,38.40,'plin',NULL,'2026-01-04 07:53:43',12,1,2),(54,56,20.00,'cash',NULL,'2026-01-04 07:53:43',8,1,2),(55,57,28.40,'plin',NULL,'2026-01-04 07:56:55',12,1,2),(56,58,20.00,'cash',NULL,'2026-01-05 00:56:02',NULL,1,2),(57,59,35.30,'plin',NULL,'2026-01-05 00:58:18',12,1,2),(58,59,20.00,'cash',NULL,'2026-01-05 00:58:18',8,1,2),(59,60,15.90,'plin',NULL,'2026-01-05 01:00:44',12,1,2),(60,61,5.30,'cash',NULL,'2026-01-05 02:44:52',8,1,2),(61,62,5.30,'cash',NULL,'2026-01-05 02:45:38',8,1,2),(62,63,20.00,'cash',NULL,'2026-01-07 11:24:37',NULL,1,2),(63,64,5.40,'cash',NULL,'2026-01-07 12:42:05',8,1,2),(64,65,15.60,'yape',NULL,'2026-01-07 12:44:55',11,1,2),(65,66,17.10,'plin',NULL,'2026-01-08 10:34:30',12,1,2),(66,67,20.00,'cash',NULL,'2026-01-08 10:37:12',NULL,1,2),(67,68,41.40,'cash',NULL,'2026-01-08 10:37:57',8,1,2),(68,69,20.00,'cash',NULL,'2026-01-08 10:40:48',NULL,1,2),(69,70,30.00,'plin',NULL,'2026-01-08 10:41:01',12,1,2),(70,71,30.00,'yape',NULL,'2026-01-08 10:41:36',11,1,2),(71,72,5.70,'cash',NULL,'2026-01-08 11:03:10',8,1,2),(72,73,20.00,'cash',NULL,'2026-01-08 11:03:39',NULL,1,2),(73,74,61.40,'plin',NULL,'2026-01-08 11:03:53',12,1,2),(74,75,20.00,'cash',NULL,'2026-01-08 11:04:38',NULL,1,2),(75,76,30.00,'plin',NULL,'2026-01-08 11:04:48',12,1,2),(76,77,20.00,'cash',NULL,'2026-01-08 11:06:07',NULL,1,2),(77,78,30.00,'yape',NULL,'2026-01-08 11:06:21',11,1,2),(78,79,5.70,'transfer',NULL,'2026-01-08 11:08:40',13,1,2),(79,80,5.40,'transfer',NULL,'2026-01-08 11:10:32',13,1,2),(80,81,20.00,'cash',NULL,'2026-01-09 16:12:50',NULL,1,2),(81,83,20.00,'cash',NULL,'2026-01-11 20:23:54',NULL,1,2),(82,84,2.70,'yape',NULL,'2026-01-11 23:41:05',11,1,2),(83,85,55.70,'cash',NULL,'2026-01-11 23:47:57',8,1,2),(84,86,20.00,'cash',NULL,'2026-01-11 23:48:26',NULL,1,2),(85,88,20.00,'cash',NULL,'2026-01-12 00:48:46',NULL,1,2),(86,89,10.00,'cash',NULL,'2026-01-12 00:50:03',8,1,2),(87,90,20.00,'cash',NULL,'2026-01-12 01:41:58',NULL,1,2),(88,91,58.40,'plin',NULL,'2026-01-12 01:42:52',12,1,2),(89,92,20.00,'cash',NULL,'2026-01-12 01:44:58',NULL,1,2),(90,93,10.00,'cash',NULL,'2026-01-12 01:45:58',8,1,2),(91,94,20.00,'cash',NULL,'2026-01-12 12:04:38',NULL,1,2),(92,95,5.70,'yape',NULL,'2026-01-12 14:39:55',11,1,2),(93,96,2.70,'cash',NULL,'2026-01-13 01:53:12',8,1,2),(94,97,5.70,'cash',NULL,'2026-01-13 01:53:27',8,1,2),(95,98,70.00,'cash',NULL,'2026-01-16 16:01:04',8,1,2),(96,99,55.70,'yape',NULL,'2026-01-16 16:01:33',11,1,2),(97,100,20.00,'cash',NULL,'2026-01-18 21:53:18',NULL,1,2),(98,101,55.70,'cash',NULL,'2026-01-18 21:54:16',8,1,2),(99,102,20.00,'cash',NULL,'2026-01-18 21:54:41',NULL,1,2),(100,103,30.00,'yape',NULL,'2026-01-18 21:54:51',11,1,2),(101,104,5.70,'plin',NULL,'2026-01-18 21:55:10',12,1,2),(102,105,20.00,'cash',NULL,'2026-01-19 10:48:05',NULL,1,2),(103,106,35.70,'cash',NULL,'2026-01-19 10:48:28',8,1,2),(104,107,2.70,'yape',NULL,'2026-01-19 10:48:44',11,1,2),(105,108,2.70,'plin',NULL,'2026-01-19 10:48:54',12,1,2),(106,109,20.00,'cash',NULL,'2026-01-19 10:49:18',NULL,1,2),(107,110,50.00,'debit',NULL,'2026-01-19 10:49:31',NULL,1,2),(108,111,20.00,'cash',NULL,'2026-01-19 11:56:40',NULL,1,2),(109,112,35.70,'yape',NULL,'2026-01-19 11:58:12',11,1,2),(110,112,20.00,'cash',NULL,'2026-01-19 11:58:12',8,1,2),(111,113,20.00,'cash',NULL,'2026-01-19 12:02:29',NULL,1,2),(112,114,32.70,'plin',NULL,'2026-01-19 12:02:59',12,1,2),(113,114,20.00,'cash',NULL,'2026-01-19 12:02:59',8,1,2),(114,115,20.00,'cash',NULL,'2026-01-20 13:23:20',NULL,1,2),(115,116,2.70,'plin',NULL,'2026-01-21 02:21:32',12,1,2),(116,117,5.70,'credit',NULL,'2026-01-21 06:45:50',10,1,2),(117,118,20.00,'cash',NULL,'2026-01-21 07:22:19',NULL,1,2),(118,119,20.00,'yape',NULL,'2026-01-21 07:23:13',NULL,1,2),(119,120,30.00,'debit',NULL,'2026-01-21 07:24:01',9,1,2),(120,121,50.00,'plin',NULL,'2026-01-21 07:24:23',12,1,2),(121,122,52.70,'credit',NULL,'2026-01-21 07:24:49',10,1,2),(122,123,20.00,'cash',NULL,'2026-01-21 07:30:44',8,1,2),(123,124,5.70,'yape',NULL,'2026-01-22 18:20:27',11,1,2),(124,125,2.90,'cash',NULL,'2026-01-23 20:47:10',8,1,2),(125,126,2.70,'cash',NULL,'2026-01-23 20:57:13',8,1,2),(126,127,20.00,'cash',NULL,'2026-01-26 11:11:46',NULL,1,2),(127,128,63.60,'plin',NULL,'2026-01-26 12:22:55',12,1,2),(128,129,20.00,'plin',NULL,'2026-01-27 04:18:04',NULL,1,2),(129,130,52.40,'yape',NULL,'2026-01-27 04:19:13',11,1,2),(130,131,32.70,'cash',NULL,'2026-01-27 20:06:58',8,1,2),(131,132,4.50,'cash',NULL,'2026-02-02 02:30:59',23,1,3),(132,133,20.00,'cash',NULL,'2026-02-02 02:35:19',NULL,1,3),(133,134,34.50,'yape',NULL,'2026-02-02 02:36:09',28,1,3),(134,135,20.00,'plin',NULL,'2026-02-02 03:22:02',NULL,1,2),(135,136,100.00,'cash',NULL,'2026-02-02 19:05:32',31,3,4),(136,137,400.00,'yape',NULL,'2026-02-03 04:47:07',36,3,4),(137,138,400.00,'yape',NULL,'2026-02-03 04:59:16',36,3,4),(138,139,200.00,'plin',NULL,'2026-02-03 05:12:13',37,3,4),(139,140,620.90,'debit',NULL,'2026-02-03 12:15:08',9,1,2),(140,141,35000.00,'cash',NULL,'2026-02-03 18:16:59',8,1,2),(141,142,20.00,'cash',NULL,'2026-02-04 20:01:01',NULL,1,2),(142,143,2.70,'cash',NULL,'2026-02-05 13:12:21',8,1,2),(143,144,2.70,'yape',NULL,'2026-02-05 13:22:29',11,1,2),(144,145,2.70,'plin',NULL,'2026-02-05 18:53:57',12,1,2),(145,146,2.70,'plin',NULL,'2026-02-05 19:00:44',12,1,2),(146,147,20.50,'yape',NULL,'2026-02-05 19:01:30',11,1,2),(147,148,650.00,'cash',NULL,'2026-02-05 19:03:49',8,1,2),(148,149,20.00,'cash',NULL,'2026-02-05 19:11:02',NULL,1,2),(149,150,70.50,'yape',NULL,'2026-02-05 19:21:57',11,1,2),(150,151,20.00,'debit',NULL,'2026-02-05 19:41:12',9,1,2),(151,152,150.00,'transfer',NULL,'2026-02-06 19:21:51',13,1,2),(152,153,20.00,'plin',NULL,'2026-02-06 19:23:55',NULL,1,2),(153,154,60.00,'yape',NULL,'2026-02-06 19:25:13',11,1,2),(154,155,25.00,'yape',NULL,'2026-02-06 20:09:03',11,1,2),(155,156,20.00,'yape',NULL,'2026-02-06 20:12:29',NULL,1,2),(156,157,30.00,'yape',NULL,'2026-02-06 20:13:35',11,1,2),(157,158,30.00,'yape',NULL,'2026-02-06 20:15:11',11,1,2),(158,159,25.00,'transfer',NULL,'2026-02-06 20:33:00',13,1,2),(159,160,150.00,'transfer',NULL,'2026-02-07 00:36:33',13,1,2),(210,211,455.30,'transfer',NULL,'2026-02-07 15:10:13',13,1,2),(211,212,20.00,'transfer',NULL,'2026-02-07 15:41:23',NULL,1,2),(212,213,50.00,'yape',NULL,'2026-02-07 15:42:00',11,1,2),(213,214,4.00,'debit',NULL,'2026-02-07 17:14:36',9,1,2),(214,215,50.00,'cash','Reserva 1','2026-01-02 01:10:25',NULL,1,2),(215,216,50.00,'cash','Reserva 2','2026-01-02 01:30:15',NULL,1,2),(216,217,50.00,'cash','Reserva 3','2026-01-02 13:51:15',NULL,1,2),(217,218,50.00,'cash','Reserva 4','2026-01-02 15:47:22',NULL,1,2),(218,219,70.00,'cash','Reserva 5','2026-01-02 16:41:41',NULL,1,2),(219,220,70.00,'cash','Reserva 6','2026-01-02 16:53:49',NULL,1,2),(220,221,50.00,'cash','Reserva 7','2026-01-03 19:37:56',NULL,1,2),(221,222,70.00,'cash','Reserva 8','2026-01-03 20:44:50',NULL,1,2),(222,223,70.00,'cash','Reserva 9','2026-01-03 20:47:52',NULL,1,2),(223,224,50.00,'cash','Reserva 10','2026-01-03 22:16:27',NULL,1,2),(224,225,50.00,'cash','Reserva 11','2026-01-03 22:19:25',NULL,1,2),(225,226,70.00,'cash','Reserva 12','2026-01-03 22:25:01',NULL,1,2),(226,227,70.00,'cash','Reserva 13','2026-01-04 00:03:35',NULL,1,2),(227,228,70.00,'cash','Reserva 14','2026-01-04 00:06:46',NULL,1,2),(228,229,50.00,'cash','Reserva 15','2026-01-04 00:08:11',NULL,1,2),(229,230,70.00,'cash','Reserva 16','2026-01-04 00:59:57',NULL,1,2),(230,231,70.00,'cash','Reserva 17','2026-01-04 03:08:37',NULL,1,2),(231,232,70.00,'cash','Reserva 18','2026-01-04 03:12:48',NULL,1,2),(232,233,70.00,'cash','Reserva 19','2026-01-04 03:15:54',NULL,1,2),(233,234,70.00,'cash','Reserva 20','2026-01-04 03:59:05',NULL,1,2),(234,235,70.00,'cash','Reserva 21','2026-01-04 04:05:39',NULL,1,2),(235,236,70.00,'cash','Reserva 22','2026-01-04 04:10:25',NULL,1,2),(236,237,70.00,'cash','Reserva 23','2026-01-04 05:00:14',NULL,1,2),(237,238,70.00,'cash','Reserva 24','2026-01-04 05:07:45',NULL,1,2),(238,239,70.00,'cash','Reserva 25','2026-01-04 07:52:02',NULL,1,2),(239,240,70.00,'cash','Reserva 26','2026-01-05 00:56:02',NULL,1,2),(240,241,50.00,'cash','Reserva 27','2026-01-07 11:24:37',NULL,1,2),(241,242,50.00,'cash','Reserva 28','2026-01-08 10:37:12',NULL,1,2),(242,243,50.00,'cash','Reserva 29','2026-01-08 10:40:48',NULL,1,2),(243,244,70.00,'cash','Reserva 30','2026-01-08 11:03:39',NULL,1,2),(244,245,50.00,'cash','Reserva 31','2026-01-08 11:04:38',NULL,1,2),(245,246,50.00,'cash','Reserva 32','2026-01-08 11:06:07',NULL,1,2),(246,247,70.00,'cash','Reserva 33','2026-01-09 16:12:50',NULL,1,2),(247,248,70.00,'cash','Reserva 34','2026-01-11 20:23:46',NULL,1,2),(248,249,70.00,'cash','Reserva 35','2026-01-11 23:48:26',NULL,1,2),(249,250,70.00,'cash','Reserva 36','2026-01-12 00:48:46',NULL,1,2),(250,251,70.00,'cash','Reserva 37','2026-01-12 01:41:58',NULL,1,2),(251,252,70.00,'cash','Reserva 38','2026-01-12 01:44:58',NULL,1,2),(252,253,70.00,'cash','Reserva 39','2026-01-12 11:59:52',NULL,1,2),(253,254,70.00,'cash','Reserva 40','2026-01-12 12:04:38',NULL,1,2),(254,255,70.00,'cash','Reserva 41','2026-01-18 21:53:18',NULL,1,2),(255,256,50.00,'cash','Reserva 42','2026-01-18 21:54:41',NULL,1,2),(256,257,50.00,'cash','Reserva 43','2026-01-19 10:48:05',NULL,1,2),(257,258,70.00,'cash','Reserva 44','2026-01-19 10:49:18',NULL,1,2),(258,259,70.00,'cash','Reserva 45','2026-01-19 11:56:40',NULL,1,2),(259,260,70.00,'cash','Reserva 46','2026-01-19 12:02:29',NULL,1,2),(260,261,70.00,'cash','Reserva 47','2026-01-20 13:23:20',NULL,1,2),(261,262,50.00,'cash','Reserva 48','2026-01-21 07:22:19',NULL,1,2),(262,263,70.00,'cash','Reserva 49','2026-01-21 07:23:13',NULL,1,2),(263,264,70.00,'cash','Reserva 50','2026-01-21 07:29:36',NULL,1,2),(264,265,70.00,'cash','Reserva 51','2026-01-26 11:11:46',NULL,1,2),(265,266,50.00,'cash','Reserva 52','2026-01-27 04:18:04',NULL,1,2),(266,267,50.00,'cash','Reserva 53','2026-01-27 20:05:44',NULL,1,2),(267,268,50.00,'cash','Reserva 54','2026-02-02 02:35:19',NULL,1,3),(268,269,50.00,'cash','Reserva 55','2026-02-02 03:22:02',NULL,1,2),(269,270,20.00,'cash','Reserva 56','2026-02-02 03:23:19',NULL,1,3),(270,271,70.00,'cash','Reserva 57','2026-02-04 20:01:01',NULL,1,2),(271,272,70.00,'cash','Reserva 58','2026-02-05 19:11:02',NULL,1,2),(272,273,70.00,'cash','Reserva 59','2026-02-06 19:23:55',NULL,1,2),(273,274,50.00,'cash','Reserva 60','2026-02-06 20:12:29',NULL,1,2),(274,275,70.00,'cash','Reserva 62','2026-02-07 15:41:23',NULL,1,2),(275,276,100.00,'cash','Reserva 63','2026-02-08 21:21:28',NULL,11,17),(276,277,30.00,'cash',NULL,'2026-02-08 21:21:28',105,11,17),(277,278,80.00,'cash',NULL,'2026-02-08 21:21:28',105,11,17),(278,279,65.00,'cash',NULL,'2026-02-08 21:21:28',105,11,17),(279,280,100.00,'cash','Reserva 66','2026-02-08 21:23:14',NULL,13,19),(280,281,30.00,'cash',NULL,'2026-02-08 21:23:14',108,13,19),(281,282,80.00,'cash',NULL,'2026-02-08 21:23:14',108,13,19),(282,283,65.00,'cash',NULL,'2026-02-08 21:23:14',108,13,19),(283,284,100.00,'cash','Reserva 69','2026-02-08 21:23:35',NULL,15,21),(284,285,30.00,'cash',NULL,'2026-02-08 21:23:35',111,15,21),(285,286,80.00,'cash',NULL,'2026-02-08 21:23:35',111,15,21),(286,287,65.00,'cash',NULL,'2026-02-08 21:23:35',111,15,21),(287,288,100.00,'cash','Reserva 72','2026-02-08 21:23:54',NULL,17,23),(288,289,30.00,'cash',NULL,'2026-02-08 21:23:54',114,17,23),(289,290,80.00,'cash',NULL,'2026-02-08 21:23:54',114,17,23),(290,291,65.00,'cash',NULL,'2026-02-08 21:23:54',114,17,23),(291,292,100.00,'cash','Reserva 75','2026-02-08 21:25:40',NULL,19,25),(292,293,30.00,'cash',NULL,'2026-02-08 21:25:40',117,19,25),(293,294,80.00,'cash',NULL,'2026-02-08 21:25:40',117,19,25),(294,295,65.00,'cash',NULL,'2026-02-08 21:25:40',117,19,25);
/*!40000 ALTER TABLE `salepayment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `stockmovement`
--

DROP TABLE IF EXISTS `stockmovement`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `stockmovement` (
  `id` int NOT NULL AUTO_INCREMENT,
  `timestamp` datetime DEFAULT NULL,
  `type` varchar(255) NOT NULL,
  `quantity` decimal(10,4) DEFAULT NULL,
  `description` varchar(255) NOT NULL,
  `product_id` int DEFAULT NULL,
  `user_id` int DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `product_id` (`product_id`),
  KEY `user_id` (`user_id`),
  KEY `ix_stockmovement_branch_id` (`branch_id`),
  KEY `ix_stockmovement_company_id` (`company_id`),
  CONSTRAINT `stockmovement_ibfk_1` FOREIGN KEY (`product_id`) REFERENCES `product` (`id`),
  CONSTRAINT `stockmovement_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`),
  CONSTRAINT `stockmovement_ibfk_3` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `stockmovement_ibfk_4` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=35 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `stockmovement`
--

LOCK TABLES `stockmovement` WRITE;
/*!40000 ALTER TABLE `stockmovement` DISABLE KEYS */;
INSERT INTO `stockmovement` VALUES (1,'2026-01-01 23:01:37','Ingreso',15.0000,'Ingreso (Nuevo): Coca Cola',1,1,1,2),(2,'2026-01-03 01:00:03','Ingreso',15.0000,'Ingreso (Nuevo): Gatorade 1.5l',2,1,1,2),(3,'2026-01-05 00:55:19','Ingreso',12.0000,'Ingreso (Nuevo): Alcohol Medicinal',3,1,1,2),(4,'2026-01-07 12:43:31','Ingreso',12.0000,'Ingreso (Nuevo): Agua mineral 1.5L',4,1,1,2),(5,'2026-01-09 20:43:06','Ingreso',24.0000,'Ingreso (Nuevo): Pasta Dental Kolynos',5,1,1,2),(6,'2026-01-22 18:20:04','Ingreso',1.0000,'Ingreso: Gatorade 1.5l',2,1,1,2),(7,'2026-01-22 18:26:29','Ingreso',50.0000,'Ingreso: Gatorade 1.5l',2,1,1,2),(8,'2026-01-25 21:37:03','Ingreso',12.0000,'Ingreso: Coca Cola',1,1,1,2),(9,'2026-01-26 08:20:16','Ingreso',5.0000,'Ingreso: Coca Cola',1,1,1,2),(10,'2026-01-26 08:20:16','Ingreso',5.0000,'Ingreso: Gatorade 1.5l',2,1,1,2),(11,'2026-01-26 08:20:16','Ingreso',5.0000,'Ingreso: Agua mineral 1.5L',4,1,1,2),(12,'2026-01-26 08:21:13','Ingreso',6.0000,'Ingreso: Agua mineral 1.5L',4,1,1,2),(13,'2026-01-26 09:34:13','Anulacion Ingreso',-12.0000,'Anulación compra BOLETA S-00001',1,1,1,2),(14,'2026-01-26 09:36:01','Ingreso',2.0000,'Ingreso: Coca Cola',1,1,1,2),(15,'2026-01-26 09:36:22','Anulacion Ingreso',-2.0000,'Anulación compra BOLETA B001-00005',1,1,1,2),(16,'2026-01-31 15:54:19','Ingreso',12.0000,'Ingreso (Nuevo): COCA COLA 5ML',6,1,1,3),(17,'2026-02-02 02:19:37','Ingreso',12.0000,'Ingreso (Nuevo): Leche evaporada',7,1,1,2),(18,'2026-02-02 02:27:40','Re Ajuste Inventario',-2.0000,'Dañado | Inventario del día  02/02/2025',1,1,1,2),(19,'2026-02-02 02:29:03','Re Ajuste Inventario',-2.0000,'Dañados',7,1,1,2),(20,'2026-02-02 19:17:21','Ingreso',1.0000,'Ingreso: Gatorade 1.25L',2,1,1,2),(21,'2026-02-02 19:37:58','Ingreso',2.0000,'Ingreso (Nuevo): Gatorade 1.25ml',16,1,1,2),(22,'2026-02-03 04:44:24','Ingreso',50.0000,'Ingreso (Nuevo): Zapatillas Deportivas Futbol',17,11,3,4),(23,'2026-02-03 05:42:01','Re Ajuste Inventario',-1.0000,'Vino dañada de fabrica | Inventario 03/02/2026',17,11,3,4),(24,'2026-02-03 12:03:45','Ingreso',24.0000,'Ingreso (Nuevo): Paracetamol 500mg',18,1,1,2),(25,'2026-02-03 12:09:53','Ingreso',50.0000,'Ingreso: Zapatillas de Futbol',19,1,1,2),(26,'2026-02-03 12:09:53','Ingreso',50.0000,'Ingreso: Zapatillas Runner',20,1,1,2),(27,'2026-02-03 18:13:04','Ingreso',20.0000,'Ingreso (Nuevo): Pañuelitos',21,1,1,2),(28,'2026-02-03 19:56:31','Devolucion Venta',5.0000,'Venta anulada #141: Venta equivocada por el monto ingresado',21,1,1,2),(29,'2026-02-05 03:11:58','Ingreso',1.0000,'Ingreso: Zapatillas de Futbol',19,1,1,2),(30,'2026-02-05 03:11:58','Ingreso',1.0000,'Ingreso: Zapatillas Runner',20,1,1,2),(31,'2026-02-06 15:32:24','Ingreso',1.0000,'Ingreso: Zapatillas Runner',20,1,1,2),(32,'2026-02-06 18:27:28','Ingreso',2.0000,'Ingreso: Zapatillas Runner',20,1,1,2),(33,'2026-02-06 19:17:55','Ingreso',3.0000,'Ingreso: Zapatillas Runner',20,1,1,2),(34,'2026-02-07 15:09:03','Ingreso',2.0000,'Ingreso: Zapatillas Runner',20,1,1,2);
/*!40000 ALTER TABLE `stockmovement` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `supplier`
--

DROP TABLE IF EXISTS `supplier`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `supplier` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `tax_id` varchar(255) NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL,
  `created_at` datetime DEFAULT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_supplier_company_branch_tax_id` (`company_id`,`branch_id`,`tax_id`),
  KEY `ix_supplier_name` (`name`),
  KEY `ix_supplier_branch_id` (`branch_id`),
  KEY `ix_supplier_company_id` (`company_id`),
  KEY `ix_supplier_tax_id` (`tax_id`),
  CONSTRAINT `supplier_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `supplier_ibfk_2` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `supplier`
--

LOCK TABLES `supplier` WRITE;
/*!40000 ALTER TABLE `supplier` DISABLE KEYS */;
INSERT INTO `supplier` VALUES (1,'VISION GAMES CORPORATION','20492144305',NULL,NULL,'AVENIDA ALFREDO MENDIOLA 3503',1,'2026-01-25 21:35:55',1,2),(2,'VISION GAMES CORPORATION SAC','204921305','visiongames@gmail.com',NULL,'Alfredo Mendiola 3503',1,'2026-01-31 15:52:28',1,3),(3,'VISION GAMES CORPORATION SAC','20492144305',NULL,NULL,'AVENIDA ALFREDO MENDIOLA 3503',1,'2026-02-03 02:06:28',3,4),(4,'SUN INVERSIONES SAC','204921445037',NULL,NULL,'AVENIDA ALFONSO UGARTE 1212',1,'2026-02-03 04:07:02',3,4);
/*!40000 ALTER TABLE `supplier` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `unit`
--

DROP TABLE IF EXISTS `unit`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `unit` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `allows_decimal` tinyint(1) NOT NULL,
  `company_id` int NOT NULL,
  `branch_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_unit_company_branch_name` (`company_id`,`branch_id`,`name`),
  KEY `ix_unit_company_id` (`company_id`),
  KEY `ix_unit_name` (`name`),
  KEY `ix_unit_branch_id` (`branch_id`),
  CONSTRAINT `fk_unit_company_id` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `unit_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=70 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `unit`
--

LOCK TABLES `unit` WRITE;
/*!40000 ALTER TABLE `unit` DISABLE KEYS */;
INSERT INTO `unit` VALUES (1,'unidad',0,1,2),(2,'pieza',0,1,2),(3,'kg',1,1,2),(4,'g',1,1,2),(5,'l',1,1,2),(6,'ml',1,1,2),(7,'m',1,1,2),(8,'cm',1,1,2),(9,'paquete',0,1,2),(10,'caja',0,1,2),(11,'docena',0,1,2),(12,'bolsa',0,1,2),(13,'botella',0,1,2),(14,'lata',0,1,2),(15,'unidad',0,2,1),(16,'kg',1,2,1),(17,'g',1,2,1),(18,'l',1,2,1),(19,'ml',1,2,1),(20,'unidad',0,1,3),(21,'kg',1,1,3),(22,'g',1,1,3),(23,'l',1,1,3),(24,'ml',1,1,3),(25,'unidad',0,3,4),(26,'kg',1,3,4),(27,'g',1,3,4),(28,'l',1,3,4),(29,'ml',1,3,4),(30,'unidad',0,4,5),(31,'kg',1,4,5),(32,'g',1,4,5),(33,'l',1,4,5),(34,'ml',1,4,5),(35,'unidad',0,1,6),(36,'kg',1,1,6),(37,'g',1,1,6),(38,'l',1,1,6),(39,'ml',1,1,6),(40,'unidad',0,1,7),(41,'kg',1,1,7),(42,'g',1,1,7),(43,'l',1,1,7),(44,'ml',1,1,7),(45,'unidad',0,1,8),(46,'kg',1,1,8),(47,'g',1,1,8),(48,'l',1,1,8),(49,'ml',1,1,8),(50,'unidad',0,1,9),(51,'kg',1,1,9),(52,'g',1,1,9),(53,'l',1,1,9),(54,'ml',1,1,9),(55,'unidad',0,5,10),(56,'kg',1,5,10),(57,'g',1,5,10),(58,'l',1,5,10),(59,'ml',1,5,10),(60,'unidad',0,1,16),(61,'kg',1,1,16),(62,'g',1,1,16),(63,'l',1,1,16),(64,'ml',1,1,16),(65,'Unidad',0,11,17),(66,'Unidad',0,13,19),(67,'Unidad',0,15,21),(68,'Unidad',0,17,23),(69,'Unidad',0,19,25);
/*!40000 ALTER TABLE `unit` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(255) NOT NULL,
  `password_hash` varchar(255) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `role_id` int NOT NULL,
  `must_change_password` tinyint(1) NOT NULL,
  `token_version` int NOT NULL,
  `company_id` int NOT NULL,
  `email` varchar(255) DEFAULT NULL,
  `branch_id` int,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_company_username` (`company_id`,`username`),
  UNIQUE KEY `ix_user_email` (`email`),
  KEY `role_id` (`role_id`),
  KEY `ix_user_company_id` (`company_id`),
  KEY `ix_user_branch_id` (`branch_id`),
  KEY `ix_user_username` (`username`),
  CONSTRAINT `fk_user_branch_id` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `fk_user_company_id` FOREIGN KEY (`company_id`) REFERENCES `company` (`id`),
  CONSTRAINT `user_ibfk_1` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=25 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'admin','$2b$12$0vs77hDKYqKvwZnorblbmOoExFOUnapTpak6NINLwwW23USwNh92C',1,6,0,0,1,'admin@tuwaykiapp.local',NULL),(8,'cajero 1','$2b$12$fXgep6QTFdB26Zuqt5w3aeohLKkEFFO/m6IxB/mF4ahR5z1daknM6',1,11,0,0,1,'cajero1@tuwaykiapp.local',NULL),(9,'admin','$2b$12$srxaoRMOfIxRCVuAaOz8y.zuGFTt56RSci/KGloVHlQtxDZW1HDg.',1,7,0,0,2,'alpha@test.com',1),(11,'admin','$2b$12$m5GxhRi9sel4q0rp1c.QMebAGTaG3mD98IoR5nEy1qS.39l3QznvK',1,8,0,0,3,'beta@test.com',4),(12,'admin','$2b$12$aXa8b6geHQ5fep8wRaa2ZuQ0MvCInd.TAS8tvf3eWv37PiTDZLGma',1,9,0,0,4,'omega@test.com',5),(13,'admin','$2b$12$IYiuj3LVYBg1hXNQZd2vQ.b.UTYu0gQAmgIQ1JrofJaz.3c3Dxl1.',1,10,0,0,5,'prueba1@mogul.com',10),(14,'supervisor','$2b$12$O/YjGt62aySyAeAoDy7SLu8hWtO.3/sr88JipaC.RMURJ8AXe67.2',1,12,0,0,1,'supervisor@tuwaykiapp.local',2),(15,'smoke_admin_a_20260208212125','$2b$12$5e432HrFvdi8e/2alfCCKOks3zuf9FQue2ufDjrhTpNkBlIdunU.W',1,13,0,0,11,'smoke_a_20260208212125@local.test',17),(16,'smoke_admin_b_20260208212125','$2b$12$MPg.MD3tkeoU3eWWfdedXuUQGngnXDu.6.NYyNOKj4cKZksKHPjne',1,17,0,0,12,'smoke_b_20260208212125@local.test',18),(17,'smoke_admin_a_20260208212311','$2b$12$MEP6kadepGjwFNXC878ecemPFZ7p.U1u7E96szBMntIRNNS4lVB02',1,22,0,0,13,'smoke_a_20260208212311@local.test',19),(18,'smoke_admin_b_20260208212311','$2b$12$3Atb5.fmofBn75uzcohfJ.kVTKXbV1Z3ISvqyBvS60PVUq7G3u.iC',1,26,0,0,14,'smoke_b_20260208212311@local.test',20),(19,'smoke_admin_a_20260208212332','$2b$12$pXU1/7v/olWWPwNbf692qOt880h5nU3m/9UvyOp5ZwWR/8wUiDgEC',1,31,0,0,15,'smoke_a_20260208212332@local.test',21),(20,'smoke_admin_b_20260208212332','$2b$12$jkl7qK.mR6VPzpGEqiu/yO6/4Wz/BAWEe3RmFGCARntXvBPIlSOdq',1,35,0,0,16,'smoke_b_20260208212332@local.test',22),(21,'smoke_admin_a_20260208212351','$2b$12$eTSasaqUHCtZR7y8XV3pU.4RfvyRnVXVMZdpTqW9//3fQc7yC7tn6',1,40,0,0,17,'smoke_a_20260208212351@local.test',23),(22,'smoke_admin_b_20260208212351','$2b$12$vDM8O4y89KebLwX6xSoqP.g.A9NeG/IvEfoRH1z5kdDiDLdkrwVFS',1,44,0,0,18,'smoke_b_20260208212351@local.test',24),(23,'smoke_admin_a_20260208212537','$2b$12$OmB59wrh1Z1M.Wd4P1rOn.UyhxIJY9lUW4FZHZAaYeBT9OPsi7hYO',1,49,0,0,19,'smoke_a_20260208212537@local.test',25),(24,'smoke_admin_b_20260208212537','$2b$12$iLAbHk2zwywh7.xQAXOnYeAvSt2jl5U1oYkGVbfZ1M3K4siA0ff1W',1,53,0,0,20,'smoke_b_20260208212537@local.test',26);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `userbranch`
--

DROP TABLE IF EXISTS `userbranch`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `userbranch` (
  `user_id` int NOT NULL,
  `branch_id` int NOT NULL,
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`),
  UNIQUE KEY `uq_user_branch` (`user_id`,`branch_id`),
  KEY `branch_id` (`branch_id`),
  CONSTRAINT `userbranch_ibfk_1` FOREIGN KEY (`branch_id`) REFERENCES `branch` (`id`),
  CONSTRAINT `userbranch_ibfk_2` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `userbranch`
--

LOCK TABLES `userbranch` WRITE;
/*!40000 ALTER TABLE `userbranch` DISABLE KEYS */;
INSERT INTO `userbranch` VALUES (1,2,2),(1,3,10),(1,6,14),(1,7,15),(1,8,16),(1,9,17),(1,16,20),(8,2,13),(8,3,9),(9,1,8),(11,4,7),(12,5,12),(13,10,18),(14,2,19),(15,17,21),(16,18,22),(17,19,23),(18,20,24),(19,21,25),(20,22,26),(21,23,27),(22,24,28),(23,25,29),(24,26,30);
/*!40000 ALTER TABLE `userbranch` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping routines for database 'sistema_ventas'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-08 22:23:05
